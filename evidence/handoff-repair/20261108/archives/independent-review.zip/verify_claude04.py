import pathlib,json,hashlib,subprocess,re,collections
R=pathlib.Path(r'C:\github\pixel-lab-agent'); W=R/'build/handoff-repair-forward-20261107T224225830'; N=R/'evidence/handoff-repair/20261108/native/claude-04'; P=N/'project'; G=W/'native-grades/claude-04';G.mkdir(exist_ok=True)
J=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
S=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,d): (G/name).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def ref(p):return {'path':str(p),'sha256':S(p)}
record=J(N/'record.json');identity=J(N/'identity.json');result=J(P/'HANDOFF-RESULT.json');K=P/'.agents/skills/pixl-kit'
checks=[]
for field,base in [('artifacts',P),('recorded_files',N)]:
 for rel,h in record[field].items():
  p=base/rel;checks.append({'path':str(p),'expected':h,'observed':S(p) if p.exists() else None,'valid':p.is_file() and S(p)==h})
kit=[{'path':f,'expected':h,'observed':S(K/f) if (K/f).is_file() else None} for f,h in identity['package_files'].items()]
changed=[]
for rel,h in identity['inputs'].items():
 p=P/rel
 if not p.is_file() or S(p)!=h:changed.append({'path':rel,'old_sha256':h,'new_sha256':S(p) if p.is_file() else None})
# All evaluation subprocesses are read-only; outputs go only into this independent directory.
commands={
 'fresh-selected-plar.json':[str(R/'.venv/Scripts/python.exe'),'-B',str(K/'scripts/pixl.py'),'plar','read','--asset','queue.ready','--root',str(P)],
 'fresh-request-review.json':[str(R/'.venv/Scripts/python.exe'),'-B',str(K/'scripts/pixl.py'),'request-review','work/queue.ready-reassessment/request-review.json','--asset','queue.ready','--root',str(P)],
 'node-integration.json':['node','verify-integration.mjs','assets/ready-confirmed.png']}
for name,args in commands.items():
 cp=subprocess.run(args,cwd=P,capture_output=True,text=True,encoding='utf-8');(G/name).write_text(cp.stdout,encoding='utf-8');save(name+'.execution.json',{'argv':args,'cwd':str(P),'exit_code':cp.returncode,'stderr':cp.stderr});assert cp.returncode==0,(args,cp.stderr)
plar=J(G/'fresh-selected-plar.json');report=J(G/'fresh-request-review.json');handoff=J(P/result['handoff']['path'])
links=[]
def walk(d,where):
 if isinstance(d,dict):
  if isinstance(d.get('path'),str) and re.fullmatch('[0-9a-f]{64}',str(d.get('sha256',''))):
   p=(P/d['path']).resolve();inside=p.is_relative_to(P)
   links.append({'where':where,'path':d['path'],'inside_project':inside,'valid':p.is_file() and S(p)==d['sha256'],'expected_sha256':d['sha256'],'observed_sha256':S(p) if p.is_file() else None})
  for k,v in d.items():walk(v,where+'.'+k)
 elif isinstance(d,list):
  for i,v in enumerate(d):walk(v,where+f'[{i}]')
for f in ['HANDOFF-RESULT.json',result['handoff']['path']]+[str(p.relative_to(P)) for p in sorted((P/'work/queue.ready-reassessment').glob('*.json')) if not p.name.startswith('plar-') and p.name!='request-review-report.json']:
 walk(J(P/f),f)
source_checks=[]
for e in report['source_evidence']:
 p=P/e['path'];ls=p.read_bytes().decode('utf-8-sig').splitlines(keepends=True)
 row={'path':e['path'],'status':e['status'],'source_sha256_exact':S(p)==e['observed_sha256'],'excerpts':[]}
 for x in e.get('excerpts',[]):
  a,b=x['lines'];row['excerpts'].append({'lines':[a,b],'bounds_valid':1<=a<=b<=len(ls),'text_exact':''.join(ls[a-1:b])==x['text']})
 source_checks.append(row)
# Public tool-use / tool-result only. Thinking blocks are never retained or interpreted.
ops=[];returns={};events=[]
for line,raw in enumerate((N/'stdout.jsonl').read_text(encoding='utf-8-sig').splitlines(),1):
 d=json.loads(raw)
 if d.get('type') not in ['assistant','user']:continue
 content=d.get('message',{}).get('content',[])
 for b in content if isinstance(content,list) else []:
  if b.get('type')=='tool_use':ops.append({'line':line,'name':b['name'],'id':b['id'],'parent_tool_use_id':d.get('parent_tool_use_id'),'input':b.get('input',{})})
  elif b.get('type')=='tool_result':returns[b['tool_use_id']]={'line':line,'is_error':b.get('is_error',False),'content':b.get('content','')}
# Store only public inputs; returned images/private process details are not copied wholesale.
save('public-operations.json',ops)
def textcontent(c):
 if isinstance(c,str):return c
 if isinstance(c,list):return '\n'.join(x.get('text','') for x in c if isinstance(x,dict) and x.get('type')=='text')
 return ''
reads=[]
for o in ops:
 inp=o['input']; target=inp.get('file_path','')
 if o['name']=='Read' and target.endswith('/request-review.md') or o['name']=='Read' and target.endswith('\\request-review.md'):
  r=returns.get(o['id'],{});t=textcontent(r.get('content',''));reads.append({'line':o['line'],'return_line':r.get('line'),'tool_use_id':o['id'],'parent_tool_use_id':o['parent_tool_use_id'],'input':inp,'is_error':r.get('is_error'),'returned_chars':len(t),'header_present':'Request and criteria handoff' in t,'caller_section_present':'Caller: inspect before adopting' in t,'truncation_marker':'truncated' in t.lower()})
launch=J(N/'launch.json');cmd=launch['command'];availability={f:cmd[cmd.index(f)+1] for f in ['--tools','--allowedTools']}
agent_ops=[]
for o in ops:
 if o['name']=='Agent':
  r=returns.get(o['id'],{});t=textcontent(r.get('content',''));agent_ops.append({**o,'return_line':r.get('line'),'return_is_error':r.get('is_error'),'agent_ids':re.findall(r'agentId:\s*([^\s]+)',t)})
cons={'request_review_sha256':S(K/'skills/pixl/references/request-review.md'),'observed_reads':reads,'native_tool_counts':dict(collections.Counter(o['name'] for o in ops)),'agent_assignments':agent_ops,'send_message_calls':[o for o in ops if o['name']=='SendMessage'],'tool_whitelist':availability,'boundary':'Completed public tool-use and tool-result metadata only. Retrieval does not prove comprehension. SendMessage availability does not prove use or same-instance continuation.'}
save('procedure-consumption.json',cons)
# Compare complete PLAR semantics, not only counts. Historical snapshot file preserves original bytes.
before=J(N/'input-project/plar.txt');after=J(P/'plar.txt')
def diff(a,b,where=''):
 if type(a)!=type(b):return [where]
 if isinstance(a,dict):return [z for k in sorted(set(a)|set(b)) for z in ([where+'.'+k] if k not in a or k not in b else diff(a[k],b[k],where+'.'+k))]
 if isinstance(a,list):
  if len(a)!=len(b):return [where+f' (length {len(a)} -> {len(b)})']
  return [z for i,(x,y) in enumerate(zip(a,b)) for z in diff(x,y,where+f'[{i}]')]
 return [] if a==b else [where]
oldhash=identity['inputs']['plar.txt'];history=P/'.pixl/plar-history'/f'{oldhash}.json';snapshot=P/'.pixl/plar-history'/f"{handoff['selection']['hash']}.json"
# Fresh helper schemas remain inspectable; derive exact selected continuation from actual output.
prod=plar['production']
v={'record_sha256':S(N/'record.json'),'record_files_checked':len(checks),'record_hash_mismatches':[x for x in checks if not x['valid']],'frozen_kit_entries':len(kit),'kit_hash_mismatches':[x for x in kit if x['expected']!=x['observed']],'input_baseline_files':len(identity['inputs']),'baseline_changed_files':changed,'plar_delta':diff(before,after),'original_plar_history_exact':history.exists() and S(history)==oldhash,'handoff_selection_snapshot_exact':snapshot.exists() and S(snapshot)==handoff['selection']['hash'],'handoff_sha256':S(P/result['handoff']['path']),'handoff_hash_valid':S(P/result['handoff']['path'])==result['handoff']['sha256'],'full_resume_exact':handoff['resume']==prod['continuation'],'next_exact':handoff['next']==prod['next_action'],'selection_hash_exact':handoff['selection']['hash']==S(P/'plar.txt'),'selection_hash_at_handoff':handoff['selection']['hash'],'current_plar_sha256':S(P/'plar.txt'),'selection_hash_difference_scope':'Caller evidence/next-only CAS save after specialist handoff, truthfully disclosed in HANDOFF-RESULT; exact intermediate PLAR history retained; whole resume and state/requirements checked independently.','state_hash':prod['hash'],'requirements_hash':handoff['requirements_hash'],'linked_identity_checks':links,'source_report_diagnostics':report['diagnostics'],'source_evidence_count':len(report['source_evidence']),'source_evidence_resolved':sum(e['status']=='resolved' for e in report['source_evidence']),'source_excerpt_checks':source_checks,'node_exit':0,'phase_same_as_native01':S(P/'PHASE.md')==S(R/'evidence/handoff-repair/20261108/native/claude-01/project/PHASE.md'),'frozen_kit_manifest_sha256':S(K/'bundle-manifest.json')}
save('verification.json',v)
print(json.dumps({k:v[k] for k in ['record_files_checked','record_hash_mismatches','frozen_kit_entries','kit_hash_mismatches','input_baseline_files','baseline_changed_files','plar_delta','full_resume_exact','next_exact','selection_hash_exact','source_evidence_count','source_evidence_resolved']}))
print('links',len(links),'bad',[x for x in links if not x['valid']]);print('public_reads',json.dumps(reads));print('agents',[(a['line'],a['return_line'],a['agent_ids']) for a in agent_ops]);print('sendmessages',len(cons['send_message_calls']));print('tools',cons['native_tool_counts'])
