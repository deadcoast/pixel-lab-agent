This is the explicit CF-03/TM-04 native artistic revision evaluation.
Follow ARTISTIC-REVISION.md; earlier assignments remain preserved history.
The current installed kit is .agents/skills/artistic-revision-kit; start at .agents/skills/artistic-revision-kit/skills/pixl/SKILL.md.
Consumer root: C:/github/pixel-lab-agent/build/artistic-revision-consumer-01. Selected Python: C:/github/pixel-lab-agent/.venv/Scripts/python.exe.
New reports belong under work/artistic-revision. Existing state and authoring-plar.txt may advance
through public operations; old immutable evidence and records must survive.
Only new src/queue-view-artistic.ts and renderer-artistic/ implement the successor.
Use the actual named PIXL child; caller owns independent verification.
No provider execution, package installs, global configuration or memory edits.
