# Complete the corrected artistic successor

This is the explicit CF-03/TM-04 evaluation. You are a fresh calling agent; select
the native registered pixl role with agent_type="pixl", fork_turns="none". Delegate
the actual specialist work and paths, retain the returned identity, independently
review its work, and use the SAME child for concrete corrections as needed. If the
host cannot invoke that role, retain the exact failure; a generic child is not a
substitute. Do not edit the role, installed kit, host settings or persistent memory.

This consumer is the exact original Claude focused-authoring output, whose 20
original criteria and proposed 29-criterion successor were reconciled in
work/continuation/SPECIALIST-ROUND2.json and PHASE2-CALLER.json. The comparison is
complete; actual successor adoption, rendering and acceptance remain unfinished.
Do not substitute the later accepted Codex 23-criterion family, repeat comparison
alone, or treat the preserved unavailable evidence as a pass.

For this evaluation the caller explicitly chooses P1: hold frame zero of the
existing Working sheet under reduced motion, using the proposed `still` descriptor
extension. Record these as current SCOPED EVALUATION CALLER CHOICES, not historical
owner requirements. Review the held symbol alone and beside its label. Failure to
read as Working is a real failure to retain, not permission to assert acceptance.
Use the original broad adopted aesthetic in FAMILY-RESULT.json: perceptible
cool-blue accent, compact readable silhouettes, deliberate clusters and steps,
transparent exterior, distinct state meaning. Ready is the exact style baseline;
Start is the preserved vector control and color relationship reference. Do not
import a different historical Claude consumer's narrower aesthetic adoption.

1. Read the current installed shared skill/profile and focused public context for
   .pixl/assets/queue.ready/state.px, focus authoring-01.plan, view authoring,
   authoring-plar.txt / queue.working. Save exports under work/artistic-revision.
   Read large JSON programmatically. The original byte snapshots, inventory and
   contract inputs are under work/artistic-revision-inputs. Preserve every old
   assignment, report, proposal, asset, source and renderer. The only existing
   production files allowed to advance are state.px and authoring-plar.txt through
   public operations; old immutable store/history files and records must survive.
   Add new artifacts, reports, history and handoffs in the normal public locations.
2. Resolve obsolete prepared/undispatched authoring-01.working.join-01 through its
   supported failed-observation route with evidenced LOCAL ABANDONMENT. Preserve
   the exact old request and job lineage; do not invent a remote ID/provider
   failure or mutate immutable intent. Then author the connected successor through
   pixl_production_plan with exact current selection.replaces for linked Working,
   Retry and Paused assets. Use current expected hashes and public pixl_commit
   where required for source/contract/destination/candidate records. Do not delete
   production links, rename the asset, bypass pending protection or edit state
   bytes directly. Check actual allocations, not merely a saved plan graph.
3. Preserve all 20 original Q IDs/record hashes and all 29 corrected outcomes.
   Create work/artistic-revision/adopted-criteria.json with original_20 entries
   {id,record_sha256} and corrected_29 entries {source_id,record_id,check,
   authority_label_for_record,clauses,expert_clauses,carries,sources_added,
   evidence_route}. source_id is the round-two criterion ID; record_id is the
   actual new Q. Use corrected_check literally, or original_check when marked
   '(unchanged)'. Retain per-clause authority in this companion mapping. Explicitly
   record any path/fixture-description rederivation: the permitted destination
   changes are src/queue-view-successor.ts to src/queue-view-artistic.ts and
   renderer-successor/ to renderer-artistic/. New actual fixture behavior may
   change descriptive clauses only with exact source/evidence and caller review;
   do not silently weaken an outcome, invent an owner constraint or omit a row.
   Measurements remain observations; seed rotation and held-cell choice remain
   scoped proposals/choices. Alpha diagnostics do not decide visual matte review;
   partial alpha and in-cell margins remain allowed, 100ms owner timing stays
   distinct from expert pacing, and shared-consumer Start distinction is inference.
4. Implement the actual successor in NEW src/queue-view-artistic.ts and
   renderer-artistic/, adapting the retained proposed successor. Keep both older
   modules and renderer directories byte-identical. Re-derive source bindings and
   authoring PLAR destination honestly. Use the same backend state machine and
   both statusCell and compactStatus. Add actual LIVE 1x and 3x cells; the old
   fixture's 1x matrix is static and cannot prove 1x playback. Preserve selective
   AA/full alpha and pixel filtering. Reuse exact accepted art as new candidates
   with provenance; previous acceptance never transfers to the new criteria.
5. Review TM-04 inputs in work/artistic-revision-inputs/contracts, including current
   typed tool declarations and the actual workbench describe edits response.
   Compare affected prepared/proposed arguments and cached preparation schemas to
   current contracts; retain explicit supported/unsupported differences. These
   typed projections are not raw tools/list. No provider execution is assigned to
   this local reuse trial. If P1 requires new art, save the exact useful supported
   request for the connected outer host and retain the failed visual evidence.
   Do not invent REST endpoints, remote observations or paid generation success.
6. Actually run the new isolated browser capture and its checker using the existing
   supported headless route. Adapt and inspect the copied capture.mjs/check.py;
   discover local installed browser tooling without package installs. Capture both
   consumers and scales, all states, normal -> reduced -> normal in the same live
   session, and a separate initially-reduced run. Retain actual timestamps, sampled
   frame indices, observed changes/wraps and rendered pixels. A deterministic
   synthetic timeline is not observed playback; report wall-clock cadence only at
   its measured scope. Prefer report.playback rows {consumer,state:'running',scale,
   elapsed,frame,image:{path,sha256}}, sampled from actual live canvas exposures and
   measured clock values, with relative image paths. Keep synthetic timelines
   separate; a requested timeout duration is not a measured exposure timestamp.
   Verify non-Working states stay unchanged when preference changes. Criteria for
   Retry/Paused consumers require actual live state pixels under both preferences;
   inspect the fixture/checker's coverage and retain any missing evidence honestly.
   Inspect actual output images at native/enlarged scale with available
   image tools, plus live temporal evidence. Retain failed attempts unchanged.
7. Publish fresh candidate/inspection verdicts, completion, collective review and
   public PLAR handoff only where actual mechanical, visual and destination
   evidence supports every required criterion. The parent independently checks
   the specialist's actual files/images, the 20 -> corrected29 mapping, request
   and source authority, renderer results, and original record/byte preservation.
   Send concrete findings to the same child; preserve both initial and corrected
   reports. No self-reported pass substitutes for observed artifacts.

Write work/artistic-revision/SPECIALIST-RESULT.json and CALLER-REVIEW.json, then
CALLER-RESULT.json with native_child, plan_id, state_path, plar_path, candidate_ids,
review_ids, comparison_path, criteria_mapping, specialist_result, renderer_evidence
(list of {path,sha256} for actual render.json captures), handoff ({path,sha256}),
unresolved and next_action. Paths are relative to this consumer; reference exact
large exports rather than repeating them. Include source/requirement identities,
scoped caller choice, actual public operations, retained failures, fresh acceptance
limits and original-history preservation. A partial result must say what remains
and the concrete next operation. M1/M2, broader generated quality and general host
reliability remain open; this trial concerns the actual reused-art successor.
