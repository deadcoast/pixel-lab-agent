---
name: plar
description: Load the installed PLAR production workflow.
---

Read [the shared skill](../artistic-revision-kit/skills/plar/SKILL.md), resolving links from that file.
