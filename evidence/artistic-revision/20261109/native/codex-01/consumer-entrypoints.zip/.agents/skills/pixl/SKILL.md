---
name: pixl
description: Load the installed PIXL production workflow.
---

Read [the shared skill](../artistic-revision-kit/skills/pixl/SKILL.md), resolving links from that file.
