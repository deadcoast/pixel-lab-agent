import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
const project = pathToFileURL(resolve(process.argv[2]) + '/');
const { stateAfter } = await import(new URL('src/queue.ts', project));
const { statusVisuals, statusCell, compactStatus, display } = await import(new URL('src/queue-view.ts', project));

const capture = pathToFileURL(resolve(process.argv[3]) + '/');
const outputPath = pathToFileURL(resolve(process.argv[4]));
const report = JSON.parse(await readFile(new URL('render.json', capture), 'utf8'));
const checks = [];
const check = (name, actual, expected) => checks.push({ name, actual, expected, pass: JSON.stringify(actual) === JSON.stringify(expected) });
check('Source display descriptor', report.display, display);
check('Every mapped state has both consumers at 1x and 3x', report.views.map(v => [v.state, v.consumer, v.scale]),
  Object.keys(statusVisuals).flatMap(state => ['statusCell', 'compactStatus'].flatMap(consumer => [1, display.scale].map(scale => [state, consumer, scale]))));
check('Transition event coverage', report.transitions.map(t => t.event), ['idle', 'started', 'pause', 'ok', 'error']);
const consumers = { statusCell, compactStatus };
for (const transition of report.transitions) {
  const expectedState = transition.event === 'idle' ? 'idle' : stateAfter(transition.event);
  check(`${transition.event} actual backend state`, transition.state, expectedState);
  for (const cell of transition.consumers) check(`${transition.event} ${cell.consumer} source mapping`, cell.descriptor, consumers[cell.consumer](expectedState));
}
for (const view of report.views) check(`${view.consumer} ${view.state} ${view.scale} descriptor`, view.descriptor, consumers[view.consumer](view.state));
check('Reported viewport', report.viewport, {width:1280, height:1000, clientWidth:1280});
check('CDP layout viewport', [report.capture_layout.cssLayoutViewport.clientWidth, report.capture_layout.cssLayoutViewport.clientHeight], [1280,1000]);
check('DPR', report.devicePixelRatio, 1);
check('Missing file identities', report.missing, ['assets/working.png', 'assets/paused.png', 'assets/error-retry.png']);
const commands = JSON.parse(await readFile(new URL('capture-commands.json', capture), 'utf8'));
const metrics = commands.findIndex(c => c.method === 'Emulation.setDeviceMetricsOverride');
const navigate = commands.findIndex(c => c.method === 'Page.navigate');
const screenshot = commands.findIndex(c => c.method === 'Page.captureScreenshot');
check('Metrics precede navigation which precedes screenshot', metrics >= 0 && navigate > metrics && screenshot > navigate, true);
check('Metrics and screenshot use same page session', commands[metrics].sessionId, commands[screenshot].sessionId);
const reportBytes = await readFile(new URL('render.json', capture));
const output = {version:1, status:checks.every(c=>c.pass)?'pass':'fail', renderer_capture_sha256: report.renderer_files['capture.mjs'],
  report_sha256:createHash('sha256').update(reportBytes).digest('hex'), checks,
  scope:'Independent execution of unchanged actual consumer modules compared to retained browser transitions/descriptors, complete view inventory, viewport/layout and capture command sequence. Existing pixel checker separately checks actual screenshot and decoded PNG pixels. Does not accept nonexistent family members or establish upstream quality.'};
await writeFile(outputPath, JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({status:output.status,checks:checks.length,path:fileURLToPath(outputPath)}));
