"""Review completed saved public artifacts; no private reasoning is emitted/read as evidence."""
import json
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
native = REPO / 'evidence/style-family-rendering/20261108/native/codex-render-recheck-01'
project = native / 'project'
out = HERE / 'codex-render-recheck-01'
def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
def save(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')

result = load(project/'RENDER-RECHECK-RESULT.json')
fresh = load(out/'plar-ready.json')
handoff = load(project/result['handoff']['path'])
checks = []
def check(name, value):
    checks.append({'check': name, 'pass': bool(value)})
check('handoff resume exactly fresh focused continuation', handoff['resume'] == fresh['production']['continuation'])
check('handoff next exactly fresh focused next action', handoff['next'] == fresh['production']['next_action'])
check('handoff selection hash current', handoff['selection']['hash'] == fresh['hash'])
check('handoff requirements current', handoff['requirements_hash'] == fresh['requirements_hash'])
check('handoff state current', handoff['resume']['state_hash'] == fresh['production']['hash'])
check('provider state unchanged from original Codex run', digest(native/'provider-state.json') == digest(native.parent/'codex-01/provider-state.json'))
check('original FAMILY-RESULT byte preserved', digest(project/'FAMILY-RESULT.json') == digest(native/'input-project/FAMILY-RESULT.json'))
original_fresh = load(REPO/'build/style-family-review-independent-20261108/codex-01/plar-ready.json')
check('Ready requirements restored exactly to prior scope', fresh['requirements_hash'] == original_fresh['requirements_hash'])
check('selection drift remains explicit', fresh['production']['selection_current'] is False and fresh['production']['next_action'] == 'review_contract' and fresh['production']['new_request_allowed'] is False)
old = {r['id']:r for r in load(out/'decoded-before.json')['records']}
new = {r['id']:r for r in load(out/'decoded-after.json')['records']}
check('all 121 predecessor records remain identical', len(old) == 121 and all(new.get(k)==v for k,v in old.items()))
added = [v for k,v in new.items() if k not in old]
check('four additive records without family verdict', len(added)==4 and {r['kind'] for r in added}=={'D','N','E','S'})
for r in added:
    f=r['fields']
    if 'ur' in f and 'dg' in f:
        check(r['id']+' binds actual findings', digest(project/f['ur']) == f['dg'])

public=[]
seen=set()
for lp in sorted(native.glob('native-*.jsonl')):
    for line_no, line in enumerate(lp.read_text(encoding='utf-8').splitlines(),1):
        e=json.loads(line)
        if e.get('type')!='response_item':
            continue
        p=e.get('payload',{})
        kind=p.get('type')
        if kind in ('function_call','custom_tool_call'):
            call_id=p.get('call_id')
            if call_id in seen:
                continue
            seen.add(call_id)
            entry={'log':lp.name, 'line':line_no, 'type':p.get('name'), 'call_id':call_id}
            if kind=='custom_tool_call' and p.get('name')=='exec':
                source=p.get('input','')
                markers=[s for s in ('view_image','check.py','capture.mjs','comparison.json','handoff','RENDER-RECHECK-RESULT','specialist-result') if s in source]
                if not markers:
                    continue
                entry['public_tool_evidence']=markers
            else:
                entry['arguments_inspected']=False
            public.append(entry)
        elif kind=='message' and p.get('role')=='assistant' and p.get('channel')=='final':
            public.append({'log':lp.name,'line':line_no,'type':'public_final','text':''.join(c.get('text','') for c in p.get('content',[]) if c.get('type')=='output_text')})
save('handoff-and-public-evidence.json', {'version':1,'checks':checks,'all_checks_pass':all(c['pass'] for c in checks),'added_records':added,'public_evidence':public,'scope':'Public tool calls and saved artifacts only; function-call argument payloads and private reasoning not inspected or decoded.'})
paths=[native/'record.json',project/'RENDER-RECHECK-RESULT.json',project/'FAMILY-RESULT.json',project/result['handoff']['path'],project/'plar.txt',project/'.pixl/assets/queue.ready/state.px',project/'renderer-recheck/capture.mjs',project/'renderer/capture.mjs']
paths += sorted((project/'work/pixl-render-recheck-01').glob('*'))
paths += sorted((project/'work/caller-render-recheck-01').glob('*'))
save('checked-hashes.json', [{'path':str(p.relative_to(REPO)), 'sha256':digest(p),'bytes':p.stat().st_size} for p in paths if p.is_file()])
print(json.dumps({'checks':len(checks),'all_pass':all(c['pass'] for c in checks),'public_observations':len(public)}))
