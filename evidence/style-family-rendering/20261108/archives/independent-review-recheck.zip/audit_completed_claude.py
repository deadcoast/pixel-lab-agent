"""Independent checks against completed public Claude recovery artifacts."""
import json
import math
from collections import Counter
from hashlib import sha256
from pathlib import Path
from PIL import Image, ImageChops

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
native = REPO/'evidence/style-family-rendering/20261108/native/claude-render-recheck-01'
project = native/'project'
out = HERE/'claude-render-recheck-01'
def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
def save(n,v):
    (out/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')

result=load(project/'RENDER-RECHECK-RESULT.json')
fresh=load(out/'plar-ready.json')
handoff=load(project/result['handoff']['path'])
checks=[]
def check(name,value):
    checks.append({'check':name,'pass':bool(value)})
check('handoff resume exactly fresh focused continuation',handoff['resume']==fresh['production']['continuation'])
check('handoff next exactly fresh focused next action',handoff['next']==fresh['production']['next_action'])
check('handoff selection hash current',handoff['selection']['hash']==fresh['hash'])
check('handoff requirements current',handoff['requirements_hash']==fresh['requirements_hash'])
check('handoff state current',handoff['resume']['state_hash']==fresh['production']['hash'])
check('provider state unchanged from original Claude run',digest(native/'provider-state.json')==digest(native.parent/'claude-01/provider-state.json'))
check('Ready production state byte unchanged',digest(project/'.pixl/assets/queue.ready/state.px')==digest(native/'input-project/.pixl/assets/queue.ready/state.px'))
check('selection drift explicit',fresh['production']['selection_current'] is False and fresh['production']['next_action']=='review_contract' and fresh['production']['new_request_allowed'] is False)
refs=[]
def walk(v,loc):
    if isinstance(v,dict):
        h=v.get('sha256',v.get('hash'))
        if isinstance(v.get('path'),str) and isinstance(h,str) and len(h)==64:
            p=project/v['path'];refs.append({'location':loc,'path':v['path'],'expected':h,'actual':digest(p) if p.is_file() else None,'pass':p.is_file() and digest(p)==h})
        for k,c in v.items():walk(c,loc+'.'+k)
    elif isinstance(v,list):
        for i,c in enumerate(v):walk(c,loc+'['+str(i)+']')
for name in ['FAMILY-RESULT.json','RENDER-RECHECK-RESULT.json']:
    walk(load(project/name),name)
check('both final result path hash references match',all(r['pass'] for r in refs))
save('handoff-and-results-check.json',{'checks':checks,'all_checks_pass':all(c['pass'] for c in checks),'references':refs})

cap=project/'work/render-recheck-pixl-01'
edges=[]
for name in ['view-000.png','view-001.png','view-002.png','view-003.png']:
    im=Image.open(cap/name).convert('RGBA');colors=Counter(im.getdata());intermediate={str(c):n for c,n in colors.items() if c not in [(23,35,54,255),(112,185,237,255)]}
    edges.append({'path':str((cap/name).relative_to(REPO)),'sha256':digest(cap/name),'size':im.size,'distinct_colors':len(colors),'intermediate_total':sum(intermediate.values()),'intermediate_colors':intermediate})
old=Image.open(project/'work/render-pixl-01/destination.png').convert('RGB')
new=Image.open(cap/'destination.png').convert('RGB');diff=ImageChops.difference(old,new)
vectors=[[2,4],[6,-8]]
ready=Image.open(project/'assets/ready-confirmed.png').convert('RGBA')
save('numerical-recheck.json',{'start_edges':edges,'old_new_screenshot_difference':{'bbox':diff.getbbox(),'different_pixels':sum(p!=(0,0,0) for p in diff.getdata()),'max_channel':max(max(p) for p in diff.getdata())},'ready':{'opaque_pixels':sum(p[3]==255 for p in ready.getdata()),'transparent_pixels':sum(p[3]==0 for p in ready.getdata()),'visible_bbox_exclusive':ready.getbbox(),'x_partition_counts':{str(x):sum(ready.getpixel((a,b))[3]>0 for b in range(16) for a in range(16) if (a<6 if x=='left' else a==6 if x=='vertex_column' else a>6)) for x in ['left','vertex_column','right']}},'old_quoted_axis_claim':{'points':[[4,8],[6,12],[12,4]],'vectors':vectors,'absolute_angles_degrees':[math.degrees(math.atan2(abs(y),abs(x))) for x,y in vectors],'lengths':[math.hypot(x,y) for x,y in vectors],'long_over_short_length':math.hypot(*vectors[1])/math.hypot(*vectors[0]),'finding':'Quoted endpoints do not define 45 degree axes or 1:2 axis lengths. Four/eight are vertical extents, not lengths along those quoted vectors. Interior staircase segments can be 45 degrees; this does not reject the artwork.'}})

public_path=out/'public-lifecycle-evidence.json'
public=load(public_path)
lines=(native/'stdout.jsonl').read_text(encoding='utf-8').splitlines()
for item in public['evidence']:
    event=json.loads(lines[item['line']-1]);item['parent_tool_use_id']=event.get('parent_tool_use_id')
    if event.get('type')=='result':item['subagent_stats']=event.get('subagent_stats')
save(public_path.name,public)
paths=[native/'record.json',native/'stdout.jsonl',project/'FAMILY-RESULT.json',project/'RENDER-RECHECK-RESULT.json',project/result['handoff']['path'],project/'plar.txt',project/'.pixl/assets/queue.ready/state.px',project/'renderer/capture.mjs',project/'renderer-recheck/capture.mjs',project/'work/render-stage-pixl/render-review.json',project/'work/queue.ready-reassessment/art-assessment.json']
for d in ['work/render-recheck-review','work/render-recheck-pixl','work/render-recheck-caller-01','work/render-recheck-pixl-01']:
    paths+=sorted((project/d).glob('*'))
save('checked-hashes.json',[{'path':str(p.relative_to(REPO)),'sha256':digest(p),'bytes':p.stat().st_size} for p in paths if p.is_file()])
print(json.dumps({'checks':len(checks),'all_pass':all(c['pass'] for c in checks),'result_references':len(refs),'edge_totals':[e['intermediate_total'] for e in edges]}))
