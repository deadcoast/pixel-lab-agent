"""Audit completed native artifact identities without inspecting private reasoning."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("host", choices=["claude-measurement-correction-01"])
args = parser.parse_args()
native = REPO / "evidence/style-family-rendering/20261108/native" / args.host
assert (native / "record.json").is_file(), "Host must finish before inspection"
project = native / "project"
out = HERE / args.host
out.mkdir(exist_ok=True)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


record = load(native / "record.json")
artifact_checks = [{"path": name, "expected": expected, "exists": (project/name).is_file(),
                    "actual": digest(project/name) if (project/name).is_file() else None}
                   for name, expected in record["artifacts"].items()]
for item in artifact_checks:
    item["pass"] = item["expected"] == item["actual"]
input_root = native / "input-project"
preservation = [{"path": p.relative_to(input_root).as_posix(), "before": digest(p),
                 "after": digest(project/p.relative_to(input_root)) if (project/p.relative_to(input_root)).is_file() else None}
                for p in input_root.rglob("*") if p.is_file()]
for item in preservation:
    item["unchanged"] = item["before"] == item["after"]
result_path = project/"REVIEW-CORRECTION-RESULT.json"
result_exists = result_path.is_file()
result = load(result_path) if result_exists else {}
refs = []


def walk(value, location="$"):
    if isinstance(value, dict):
        expected = value.get("sha256", value.get("hash"))
        if isinstance(value.get("path"), str) and isinstance(expected, str) and len(expected) == 64:
            p = project/value["path"]
            refs.append({"location": location, "path": value["path"], "expected": expected,
                         "actual": digest(p) if p.is_file() else None,
                         "pass": p.is_file() and digest(p) == expected})
        for key, child in value.items():
            walk(child, location+"."+key)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            walk(child, f"{location}[{i}]")


walk(result)
save("artifact-checks.json", {"native_record": {"path": str(native/"record.json"), "sha256": digest(native/"record.json")}, "required_result_exists": result_exists,
     "artifact_count": len(artifact_checks), "all_record_artifacts_match": all(x["pass"] for x in artifact_checks),
     "artifacts": artifact_checks, "result_references": refs,
     "all_result_references_match": all(x["pass"] for x in refs),
     "input_count": len(preservation), "input_changed": [x for x in preservation if not x["unchanged"]],
     "preservation": preservation})

runner = project/".agents/skills/pixl-kit/scripts/pixl.py"
if not runner.is_file():
    runner = REPO/"plugins/pixl/scripts/pixl.py"
state = project/".pixl/assets/queue.ready/state.px"
commands = {"validate": ["validate", str(state), "--root", str(project)],
            "family": ["family", str(state), "--root", str(project)],
            "workflow": ["workflow", str(state), "--root", str(project)],
            "jobs": ["jobs", str(state), "--root", str(project)],
            "plar-ready": ["plar", "read", "--asset", "queue.ready", "--root", str(project)],
            "plar-working": ["plar", "read", "--asset", "queue.working", "--root", str(project)],
            "decoded-before": ["decode", str(input_root/".pixl/assets/queue.ready/state.px")],
            "decoded-after": ["decode", str(state)]}
results = []
for name, argv in commands.items():
    run = subprocess.run([sys.executable, str(runner), *argv], capture_output=True, text=True, encoding="utf-8")
    (out/(name+".json")).write_text(run.stdout, encoding="utf-8")
    results.append({"name": name, "command": [str(runner), *argv], "returncode": run.returncode,
                    "stderr": run.stderr, "sha256": digest(out/(name+".json"))})
save("runtime-results.json", results)
before = load(out/"decoded-before.json")
after = load(out/"decoded-after.json")
old = {x["id"]: x for x in before["records"]}
new = {x["id"]: x for x in after["records"]}
save("state-record-comparison.json", {"before_revision":before["revision"], "after_revision":after["revision"],
     "old_count":len(old), "new_count":len(new), "removed":sorted(set(old)-set(new)),
     "added":sorted(set(new)-set(old)), "changed_existing":{key:{"before":value,"after":new.get(key)} for key,value in old.items() if new.get(key)!=value}})
print(json.dumps({"host":args.host,"artifact_count":len(artifact_checks),"artifacts_ok":all(x["pass"] for x in artifact_checks),
                  "reference_count":len(refs),"references_ok":all(x["pass"] for x in refs),
                  "input_count":len(preservation),"changed_inputs":[x["path"] for x in preservation if not x["unchanged"]],
                  "runtime_returncodes":{x["name"]:x["returncode"] for x in results},
                  "old_records":len(old),"new_records":len(new),"changed_records":[key for key,value in old.items() if new.get(key)!=value]}))
