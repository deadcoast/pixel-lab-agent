"""Independent arithmetic, saved-state and public-evidence check for completed correction."""
import json
import math
import subprocess
import sys
from hashlib import sha256
from pathlib import Path
from PIL import Image

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
NATIVE=REPO/'evidence/style-family-rendering/20261108/native/claude-measurement-correction-01'
P=NATIVE/'project'
O=HERE/'claude-measurement-correction-01'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p): return sha256(p.read_bytes()).hexdigest()
def save(n,v): (O/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
checks=[]
def check(n,a,e): checks.append({'name':n,'actual':a,'expected':e,'pass':a==e})
def near(n,a,e,t=0.001): checks.append({'name':n,'actual':a,'expected':e,'tolerance':t,'pass':abs(a-e)<=t})

r=read(P/'REVIEW-CORRECTION-RESULT.json')
im=Image.open(P/'assets/ready-confirmed.png').convert('RGBA')
pts={(x,y) for y in range(im.height) for x in range(im.width) if im.getpixel((x,y))[3]}
pixelmap=[''.join('#' if (x,y) in pts else '.' for x in range(16)) for y in range(16)]
rows={y:sorted(x for x,yy in pts if yy==y) for y in range(16)}
check('exact retained PNG hash',digest(P/'assets/ready-confirmed.png'),'fc5e43ae9db53c12cdb419794b36ef09a8ae8cf2be996954ae7390396a268ac5')
check('opaque count',len(pts),29)
check('transparent count',256-len(pts),227)
check('exclusive bbox',list(im.getbbox()),[3,4,14,13])
check('pixel map agrees caller',pixelmap,read(P/'work/measurement-correction-caller/caller-endpoints-output.json')['pixel_map'])
check('pixel map agrees specialist',pixelmap,read(P/'work/measurement-correction-pixl/measurement-correction.json')['pixel_map'])
for point in [(4,8),(6,12),(12,4)]:
    check(f'quoted point {point} is actual opaque cap',point in pts and (point[0]-1,point[1]) not in pts and (point[0]+1,point[1]) not in pts,True)
poly=r['findings']['quoted_polyline']
calculated=[]
for name,a,b in [('left_segment',(4,8),(6,12)),('right_segment',(6,12),(12,4))]:
    dx,dy=b[0]-a[0],b[1]-a[1]
    value={'from':a,'to':b,'delta':[dx,dy],'length':math.hypot(dx,dy),'signed_screen_angle_deg':math.degrees(math.atan2(dy,dx))}
    calculated.append(value)
    check(name+' delta',poly[name]['delta'],value['delta'])
    near(name+' length',poly[name]['length'],value['length'])
    near(name+' angle magnitude',poly[name]['angle_from_horizontal_deg'],abs(value['signed_screen_angle_deg']))
    check(name+' not 45 degrees',poly[name]['is_45_degree'],False)
near('quoted length ratio',poly['length_ratio_right_over_left'],math.sqrt(5))
near('interior angle',poly['interior_angle_at_vertex_deg'],math.degrees(math.acos(1/math.sqrt(5))))
check('row spans are separate',r['findings']['row_spans'],{'left':4,'right':8,'ratio':2.0})
check('column spans are separate',r['findings']['col_spans'],{'left':2,'right':6,'ratio':3.0})
partition=[sum(x<6 for x,y in pts),sum(x==6 for x,y in pts),sum(x>6 for x,y in pts)]
check('column partition',r['findings']['partition_counts'],partition)
check('left cap above adjacent run centre',rows[9][:3],[3,4,5])
check('right cap above adjacent run centre',rows[5],[11,12,13])
check('bottom cap below adjacent run centre',rows[11],[5,6,7])
check('merged row ten',rows[10],[4,5,6,7,8])
alts=r['findings']['alternative_centrelines']
near('alternate run-centre ratio',alts['run_centres_excluding_caps']['length_ratio_right_over_left'],3)
near('alternate outer-contour ratio',alts['outer_contours']['length_ratio_right_over_left'],7/3)
pca=[]
for part in [[(x,y) for x,y in pts if x<6],[(x,y) for x,y in pts if x>6]]:
    mx=sum(x for x,y in part)/len(part);my=sum(y for x,y in part)/len(part)
    xx=sum((x-mx)**2 for x,y in part)/len(part);yy=sum((y-my)**2 for x,y in part)/len(part);xy=sum((x-mx)*(y-my) for x,y in part)/len(part)
    theta=math.atan2(2*xy,xx-yy)/2
    projected=[(x-mx)*math.cos(theta)+(y-my)*math.sin(theta) for x,y in part]
    pca.append({'angle':math.degrees(theta),'extent':max(projected)-min(projected)})
spec=read(P/'work/measurement-correction-pixl/measurement-correction.json')
pc=spec['alternative_centreline_estimates']['C_principal_axis_per_partition']
for name,actual in zip(['left_partition','right_partition'],pca):
    near(name+' alternate PCA angle',pc[name]['angle_from_horizontal_deg_screen'],actual['angle'])
    near(name+' alternate PCA extent',pc[name]['projected_extent_px'],actual['extent'])
near('alternate PCA extent ratio',pc['extent_ratio_right_over_left'],pca[1]['extent']/pca[0]['extent'],0.005)
save('independent-numerical-check.json',{'checks':checks.copy(),'all_pass':all(c['pass'] for c in checks),'pixel_map':pixelmap,'quoted_calculation_full_precision':calculated,'alternate_PCA':pca,'scope':'Numerical measurements and actual decoded pixel coordinates. Alternatives stay separate from quoted endpoint axes; no new aesthetic rejection condition.'})

old=read(NATIVE/'input-project/plar.txt');new=read(P/'plar.txt')
delta=[]
def diff(a,b,loc='$'):
    if type(a)!=type(b):delta.append({'path':loc,'before':a,'after':b})
    elif isinstance(a,dict):
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:delta.append({'path':loc+'.'+k,'before':a.get(k),'after':b.get(k)})
            else:diff(a[k],b[k],loc+'.'+k)
    elif isinstance(a,list):
        for i in range(max(len(a),len(b))):
            if i>=len(a) or i>=len(b):delta.append({'path':f'{loc}[{i}]','before':a[i] if i<len(a) else None,'after':b[i] if i<len(b) else None})
            else:diff(a[i],b[i],f'{loc}[{i}]')
    elif a!=b:delta.append({'path':loc,'before':a,'after':b})
diff(old,new)
check('only declared PLAR changes',sorted(x['path'] for x in delta),['$.assets[0].evidence[33]','$.assets[0].next','$.assets[1].next','$.assets[2].next','$.assets[4].next'])
runner=P/'.agents/skills/pixl-kit/scripts/pixl.py'
row_hashes={}
for asset in [a['id'] for a in new['assets']]:
    pair=[]
    for label,root in [('before',NATIVE/'input-project'),('after',P)]:
        cp=subprocess.run([sys.executable,str(runner),'plar','read','--root',str(root),'--asset',asset],capture_output=True,text=True,encoding='utf-8',check=True)
        value=json.loads(cp.stdout);pair.append(value['requirements_hash'])
    row_hashes[asset]={'before':pair[0],'after':pair[1]}
    check(asset+' requirements unchanged',pair[1],pair[0])
    check(asset+' result requirement hash',r['plar']['requirements_hash_by_row'][asset],pair[1])
for a in new['assets']:
    if a['id']!='queue.start':check(a['id']+' next records plan before production','before' in a['next'].lower() and 'plan' in a['next'].lower(),True)
fresh=read(O/'plar-ready.json');h=read(P/r['handoff']['path'])
check('whole handoff resume exactly equals fresh continuation',h['resume'],fresh['production']['continuation'])
check('handoff next exactly equals fresh next action',h['next'],fresh['production']['next_action'])
check('handoff selection current file identity',h['selection']['hash'],fresh['hash'])
check('handoff requirements identity',h['requirements_hash'],fresh['requirements_hash'])
check('handoff state identity',h['resume']['state_hash'],fresh['production']['hash'])
check('changed selection remains explicit',fresh['production']['selection_current'],False)
check('current request remains disallowed',fresh['production']['new_request_allowed'],False)
check('provider state preserved',digest(NATIVE/'provider-state.json'),digest(NATIVE.parent/'claude-render-recheck-01/provider-state.json'))
check('prior PLAR exactly retained',digest(P/'.pixl/plar-history'/f"{digest(NATIVE/'input-project/plar.txt')}.json"),digest(NATIVE/'input-project/plar.txt'))
refs=[]
def walk(v,loc):
    if isinstance(v,dict):
        expected=v.get('sha256')
        if isinstance(v.get('path'),str) and isinstance(expected,str) and len(expected)==64:
            path=P/v['path'];refs.append({'location':loc,'path':v['path'],'expected':expected,'actual':digest(path) if path.is_file() else None,'pass':path.is_file() and digest(path)==expected})
        for k,c in v.items():walk(c,loc+'.'+k)
    elif isinstance(v,list):
        for i,c in enumerate(v):walk(c,loc+f'[{i}]')
walk(h,'handoff');walk(read(P/'work/measurement-correction-caller/caller-comparison.json'),'caller-comparison')
check('nested handoff/caller artifact identities',all(x['pass'] for x in refs),True)
save('independent-state-handoff-check.json',{'all_pass':all(c['pass'] for c in checks),'checks':checks,'PLAR_delta':delta,'requirements_hashes':row_hashes,'nested_references':refs})

public=[]
for line_no,line in enumerate((NATIVE/'stdout.jsonl').read_text(encoding='utf-8').splitlines(),1):
    e=json.loads(line);typ=e.get('type')
    if typ=='assistant':
        for b in e.get('message',{}).get('content',[]):
            if b.get('type')!='tool_use':continue
            name=b.get('name','');inp=b.get('input',{})
            item={'line':line_no,'name':name,'tool_id':b.get('id'),'parent_tool_use_id':e.get('parent_tool_use_id')}
            if name=='Agent':item['foreground']=inp.get('run_in_background') is False
            elif name in ['Bash','Read','Write']:
                val=json.dumps(inp);markers=[m for m in ['caller-endpoints','measure-endpoints','measurement-correction.json','caller-comparison.json','ready-confirmed.png','plar save','handoff','REVIEW-CORRECTION-RESULT'] if m in val]
                if not markers:continue
                item['markers']=markers
            elif not any(m in name for m in ['plar','workflow','family','validate','jobs','pixellab']):continue
            public.append(item)
    elif typ=='result':public.append({'line':line_no,'type':'result','is_error':e.get('is_error'),'subagent_stats':e.get('subagent_stats'),'result':e.get('result')})
save('public-lifecycle-evidence.json',{'scope':'Only public tool metadata and final text used. Private reasoning and wire payloads not inspected as evidence.','log':str((NATIVE/'stdout.jsonl').relative_to(REPO)),'evidence':public})
paths=[NATIVE/'record.json',NATIVE/'stdout.jsonl',P/'REVIEW-CORRECTION-RESULT.json',P/r['handoff']['path'],P/'plar.txt',P/'.pixl/assets/queue.ready/state.px']
for directory in ['work/measurement-correction-pixl','work/measurement-correction-caller']:paths+=list((P/directory).glob('*'))
save('checked-hashes.json',[{'path':str(p.relative_to(REPO)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in paths if p.is_file()])
print(json.dumps({'checks':len(checks),'all_pass':all(c['pass'] for c in checks),'failed':[c['name'] for c in checks if not c['pass']],'nested_refs':len(refs),'PLAR_delta_paths':[d['path'] for d in delta]}))
