"""Independent review evidence; never changes production sources or native runs."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import math

from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROJECT = HERE / "input-project"


def identity(path):
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size,
            "sha256": sha256(path.read_bytes()).hexdigest()}


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


checked = []
for name in ("AGENTS.md", "TODO.md", "docs/PROJECT-REVIEW.md", ".agents/PROFILE.md",
             "plugins/pixl/skills/pixl/SKILL.md", "plugins/pixl/skills/pixl/references/family-delivery.md",
             "plugins/pixl/skills/pixl/references/request-review.md", "tests/test_queue_renderer.py"):
    checked.append(identity(ROOT / name))
for folder in (ROOT / "examples/plar-project/renderer", PROJECT / "renderer"):
    checked.extend(identity(folder / name) for name in ("capture.mjs", "check.py", "server.mjs", "view.mjs", "index.html"))
for name in ("BRIEF.md", "RENDER-STAGE.md", "src/queue.ts", "src/queue-view.ts", "assets/start.svg",
             "assets/ready-confirmed.png", "work/queue.ready-reassessment/art-assessment.json"):
    checked.append(identity(PROJECT / name))

captures = []
for name in ("capture-independent", "capture-independent-host", "capture-independent-host-repeat"):
    capture = HERE / name
    for file in sorted(capture.iterdir()):
        if file.is_file():
            checked.append(identity(file))
    if not (capture / "render.json").is_file():
        captures.append({"path": capture.relative_to(ROOT).as_posix(), "status": "browser_launch_failed",
                         "scope": "Restricted sandbox crashpad failure; not render evidence."})
        continue
    report = json.loads((capture / "render.json").read_text(encoding="utf-8"))
    checks = json.loads((capture / "checks.json").read_text(encoding="utf-8-sig"))
    with Image.open(capture / "destination.png") as screen:
        screen_size = list(screen.size)
    captures.append({"path": capture.relative_to(ROOT).as_posix(), "status": checks["status"],
                     "viewport": report["viewport"], "screenshot_size": screen_size,
                     "first_canvas_bounds": report["views"][0]["bounds"], "failures": checks["failures"],
                     "renderer_files": report["renderer_files"], "user_agent": report["userAgent"]})

with Image.open(PROJECT / "assets/ready-confirmed.png") as source:
    ready = source.convert("RGBA")
    visible = [(x, y) for y in range(ready.height) for x in range(ready.width) if ready.getpixel((x, y))[3]]
    measured = {"identity": identity(PROJECT / "assets/ready-confirmed.png"), "size": list(ready.size),
                "rgba_counts": {str(key): value for key, value in Counter(ready.getdata()).items()},
                "visible_bbox_exclusive": list(ready.getbbox()),
                "pixel_edge_mass_centroid": [sum(x + .5 for x, y in visible)/len(visible), sum(y + .5 for x, y in visible)/len(visible)],
                "pixel_map": ["".join("#" if ready.getpixel((x, y))[3] else "." for x in range(ready.width)) for y in range(ready.height)],
                "historical_endpoint_claim": {"left_tip": [4, 8], "vertex": [6, 12], "right_tip": [12, 4]},
                "straight_line_tip_to_vertex_vectors": {"left": [2, 4], "right": [6, -8]},
                "absolute_angles_from_horizontal_degrees": {"left": math.degrees(math.atan2(4, 2)), "right": math.degrees(math.atan2(8, 6))},
                "scope": "These tip-to-vertex vectors are not an exclusive aesthetic or centreline rule. They show the historical endpoint-based 45-degree description is internally inconsistent; interior staircase construction can still include 45-degree segments."}

save("renderer-findings.json", {"version": 1, "reviewer": "independent development evaluator", "native_reviews": "pending completion notice",
     "findings": [{"id": "renderer-viewport-race", "priority": 1, "status": "confirmed_reproduced_twice",
                   "title": "Capture report and screenshot can describe different layouts",
                   "source_locations": ["examples/plar-project/renderer/capture.mjs:26", "examples/plar-project/renderer/view.mjs:127"],
                   "observed": "Unmodified renderer records 1262x904 DOM viewport and first canvas x=238, then saves 1280x1000 screenshot with first glyph at x=247. Checker fails viewport and all eight available screenshot/canvas correspondences in two fresh isolated captures.",
                   "cause": "Inferred report/screenshot timing race: the module posts capture immediately while CLI screenshot occurs later, without a common established viewport/layout boundary.",
                   "impact": "Fresh native destination evidence can fail nondeterministically even when artwork and consumer modules are unchanged.",
                   "recommendation": "Establish the browser viewport and stable layout explicitly before collecting report and screenshot; retain failed runs and verify new captures."}],
     "captures": captures,
     "limits": ["No active native producer outputs or logs inspected.", "No source or original evidence modified.", "Current findings do not supply a family artwork or upstream PixelLab quality verdict."]})
save("independent-ready-measurements.json", measured)
save("checked-hashes.json", {"version": 1, "scope": "Files used in the independent pre-native review, identities checked at time of review.", "files": checked})
