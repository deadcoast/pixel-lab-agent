# Matching drone approach

Prepared 2026-09-14 from `small-separated.png`, `old-assessment.md`, `SESSION.md`, and the project’s packaged PIXL resources.

Keep the 16 × 16 canvas, thick two-pixel dark frame around the teal body, and two detached antenna islands. The supplied drone accommodates those choices: its frame leaves a 6 × 4 interior, with two light details clear of the contour. This supports a matching sample at the chosen size; it does not guarantee a future candidate’s quality. The main visual uncertainty is dark antenna visibility against the eventual background. Explore color values within the chosen aesthetic if needed; a fixed palette is unnecessary for the proposed first sample.

This deliverable is a bounded Markdown plan. Only this file is created. No project PX2 state is initialized or amended, no production art is created, and no provider is called. Reference previews were composed in memory for inspection. No production or engine acceptance is claimed.

## Authority carried into the approach

| Property / value | Status and authority | Exact source | Applicable scope |
| --- | --- | --- | --- |
| 16 × 16 canvas | User requirement | Current brief: “a 16 by 16 canvas” and “Keep those choices.” | Matching drone, future sample instructions and size check |
| Thick two-pixel dark frame around teal body | User requirement | Current brief: “a thick two-pixel dark frame around the teal body” | Sample design and mechanical/visual frame review |
| Two detached antenna islands | User requirement | Current brief: “two detached antenna islands” | Preserve both antennas and their separation from each other and the body; no cleanup that joins or deletes them |
| Match supplied reference | User requirement; degree of matching remains a visual judgment | Current brief: “review the supplied small-separated.png reference and prepare a matching drone approach” | Compare proportions, landmarks and color relationships |
| Exact RGB palette | Unapproved; no membership restriction | Current brief: “I have not approved a fixed palette.” | All proposed instructions and checks omit exact palette membership and a color-count cap |
| Body footprint, antenna sizes/gaps, light-detail positions, binary alpha and three observed colors | Reference observations, not independently adopted requirements | `small-separated.png`, measurements below | Starting recipe for a labeled sample proposal; no automatic rejection for changing an observed coordinate, gap, alpha level or color |
| Preserve the blocky front-facing arrangement, two light details and transparent surround in the first sample | Agent proposal, informed by inspection | Reference geometry below; current request to match it | First representative experiment only; front-facing/eye interpretation is not a confirmed projection or gameplay role |
| Native and integer-nearest previews on light/dark backgrounds | Proposed inspection method, not an engine contract | PIXL `silhouette-readability`; reference review below | Diagnose this sample’s readability; no invented contrast threshold |
| 32-pixel minimum, one component for all sprites, three-color lock | Unapproved prior-agent proposals, not project rules | `old-assessment.md`, lines 1–3; current brief: “not approved by me” | Historical diagnostic only; excluded from instructions and rejection criteria |
| Markdown only, isolated project, no state/art/provider actions | User requirement | Current brief’s evaluation scope; `SESSION.md`, line 1 | This session’s work |

## What was inspected and measured

Opened the original 16 × 16 PNG through the host viewer. Also viewed in-memory native-size composites and 16× nearest-neighbor enlargements on white (`#FFFFFF`) and dark blue-gray (`#202838`). The prepared sheets were 160 × 64 and 576 × 288 respectively. Actual device-pixel delivery by the host is unknown, so native display fidelity and final gameplay readability remain unverified. These backgrounds are diagnostics, not supplied game backgrounds.

PIXL `pixl_asset_check`, with only `width=16` and `height=16`, reported one frame, 88 visible pixels, three visible colors, no fractional-alpha pixels, and three components under four-neighbor connectivity at alpha > 0. Size checks passed; the tool explicitly left visual quality and engine import unverified. No palette or binary-alpha constraint was supplied.

Direct Pillow inspection confirmed the following. Coordinates are zero-based; ranges here include both endpoints.

| Feature | Measured geometry / pixels | Interpretation |
| --- | --- | --- |
| Framed body | x=3–12, y=6–13; 10 × 8, 80 visible pixels | Broad rectangular body |
| Dark frame | Two rows/columns on all four sides; 56 pixels | Requested thick treatment is present |
| Interior | x=5–10, y=8–11; 6 × 4 | 22 teal pixels plus two light pixels |
| Light details | (6,9) and (9,9) | Read as a pair of eyes/sensors; two teal pixels between them, with teal separating both from the frame |
| Antennas | x=5–6 and x=9–10, both y=2–3 | Two 2 × 2 dark islands; rows 4–5 are transparent between antennas and body |
| Occupancy connectivity | Component sizes 80, 4, 4 under both four- and eight-neighbor rules | Body and two intended antenna islands; not accidental fragmentation |
| Visible colors | `#25354A`: 64 pixels; `#56B5BC`: 22; `#F4DDA2`: 2 | Observed dark/teal/warm-light relationship; optional starting swatches only |
| Transparency | 168 fully transparent pixels; 88 fully opaque pixels | Observed reference treatment, not a mandatory alpha policy |

The enlarged reference clearly separates the light details from the thick frame. The body and antennas are distinct on white. On the dark diagnostic background, the frame and antennas have weak separation from the background, especially at the prepared native size. This is a background-specific visual concern, not a reason to enlarge the canvas, thin the frame, connect antennas, or establish a universal contrast rule.

The old assessment reports a different 32-pixel robot reduced by nearest-neighbor, whose eyes then met its inset border at 16 pixels. That reported result applies to that robot and transformation. Its tested image and measurements were not supplied here. This drone’s inspected geometry does not exhibit that contact. The earlier result cannot establish a universal minimum size, prohibit intentional islands, or adopt a palette for this project. The old file remains preserved.

## PIXL method selection and limits

Selected `semantic-clusters` to keep intentional features distinct from raw connectivity. Its prerequisite is a declared neighbor rule and semantic masks. For this reference, both four/eight-neighbor occupancy measurements were performed, and the body, antenna and light-detail regions are identified above. A future candidate needs its own feature labels; measured three-component occupancy is not a generic pass/fail rule. The user’s two detached antennas are the actual requirement. Same-color components and multi-color semantic features should be reviewed separately.

Selected `silhouette-readability` for a future comparison of body shape, antenna gaps and landmark visibility at intended size and on relevant backgrounds. Current inspection covers reference geometry and two diagnostic backgrounds. Intended display scale, actual game backgrounds and a new candidate remain unavailable. Flat-mask review can check silhouette/gaps; the colored view is needed for the teal interior and light details.

Source discovery verified the installed corpus bytes. Complete read-only context packets were retrieved from `resources/knowledge/library.px` for `k.semantic-clusters` and `k.silhouette-readability`. Exact cited text was retrieved with matching hashes:

| Installed source, relative to `.agents/skills/pixl-kit/resources/` | Exact lines | Transfer to this drone |
| --- | --- | --- |
| `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md` | 1402–1445 | Supports labeling connected or semantically related features such as silhouette, outline and eyes |
| Same source | 857–867 | Conditional cluster constraints protect identity and intentionally permitted details. Its “approved ramp” condition does not apply when no ramp is approved. Animation/flicker conditions do not apply to this static planning task |
| Same source | 1563–1573 | Discusses semantic classes of animation changes; limited relevance to a static drone, no size or connectivity mandate |
| `training/original-docs/PIXEL-ART-ASSETS.md` | 11–15 | A different project’s interaction-key UI brief; illustrates contextual clarity/consistency, but supplies no authority over this drone’s design |

The bundled `evidence/art-methods/poc-report.json`, dated `2026-09-14T13:05:30.131009+00:00`, reports passing offline checks for `cluster-connectivity` and `key-silhouette-landmarks`. The former checks connectivity differences and explicitly cannot determine semantic importance. The latter checks key-hole/shaft/teeth geometry; its receipt explicitly leaves visual recognition, background readability and artistic acceptance to inspection. Neither fixture proves this drone’s quality, a minimum size, provider reliability or engine behavior. They were read, not rerun or adopted as project acceptance. The next project-specific proof is the proposed sample below.

## Proposed first sample and review

When a later task includes art creation, author one static drone directly on the 16 × 16 logical canvas. Start with the reference’s 10 × 8 body footprint, two-pixel dark frame, 6 × 4 interior, two small light sensors and two detached 2 × 2 antennas. These exact placements are a convenient experiment, not additional binding rules. Direct native-grid authoring is proposed because the 256-pixel canvas makes controlled spacing practical. The earlier resized robot is unnecessary as a template.

Suggested authoring brief:

> Match `small-separated.png` on a 16 × 16 canvas. Retain a thick two-pixel dark frame enclosing the teal body and two detached antenna islands. Start with the reference’s blocky proportions, separated light sensor pair and transparent surround. Keep the dark-frame/teal-body/light-detail relationship readable. Exact colors may vary; no fixed palette or three-color cap is imposed. Review antenna separation and sensor clearance at native size and enlarged scale.

If the initial sample’s dark islands become difficult to see against the actual target background, propose a second color-value version using the same geometry. Adjust the dark frame/antenna value while retaining its dark relationship to the teal body. Compare both on that background before choosing. Reference swatches are optional; this experiment carries no guaranteed improvement or palette adoption.

Record the following criteria before evaluating that future sample:

| Review | Requirement or proposed experiment | Evidence and consequence |
| --- | --- | --- |
| Canvas | Required 16 × 16 | Measure dimensions; revise a mismatched sample within the requested canvas |
| Frame/body | Required two-pixel dark frame around teal body | Inspect thickness on the actual contour and visually confirm dark/teal relationship; simplify interior detail if crowded while retaining the frame |
| Antennas | Required two detached antenna islands | Label both and verify separation from body and each other. Connectivity is diagnostic; do not join/delete them to satisfy a count |
| Matching/readability | Requested reference match; proposed sensor arrangement and diagnostic backgrounds | Compare original and sample at native size and integer zoom; judge proportions, visible teal interior, distinct sensors and antenna gaps. Record observed differences and uncertainty separately from mechanical passes |
| Color trial | Optional proposal | Compare visibility while preserving the chosen aesthetic; no exact RGB membership check, color cap or numerical contrast cutoff |

Keep any failed trial available and revise only the affected feature. A production candidate, provider performance and engine import are all untested this session. Future engine review belongs to the actual destination and does not gate this Markdown deliverable.

No further aesthetic decision is needed to complete this approach. The next production operation is one representative sample retaining all three chosen features. Before claiming in-game readability or choosing a background-driven color adjustment, obtain the intended game background and display scale. Palette locking is not a prerequisite.

## Evidence identities

SHA-256 values for resumption:

- `small-separated.png`: `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`
- `old-assessment.md`: `4f7db791ae8d97869b169c76bcfce93c6101e5497b1b682d649730a695e70521`
- `SESSION.md`: `c3f0c861a8821df069ab330416a0fd69ab9262bc07b94025cfddf8934eb623ea`
- `PIXEL-ART-DEEP-RESEARCH.md`: `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`
- `PIXEL-ART-ASSETS.md`: `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`
- Bundled `evidence/art-methods/poc-report.json`: `a3b77eae4ab97843829efab67b8773086498d67d91672350520194059f586d81`

Final authority audit: the enforced artistic restrictions are the user’s canvas, frame/body treatment, detached antennas and reference-matching goal. Exact swatches, pixel counts, coordinates, gaps, alpha levels, component totals and background tests retain their observation/proposal status throughout this approach.
