# Production approach — matching drone sprite

Scope: bounded planning only. No PX2 state was created or amended, no production art was
generated, and no provider was called. This document is the deliverable.

Inputs inspected this session:

- `small-separated.png` — supplied reference, sha256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`
- `inspection-reference-x24.png` — nearest-neighbor 24x enlargement of the reference, produced
  locally for viewing only (not an asset, not a candidate)
- `old-assessment.md` — prior agent text, explicitly unapproved by the project owner

Both the native file and the 24x enlargement were viewed, plus an exact per-pixel grid dump.

---

## 1. Authority table

Every enforced restriction downstream must appear here. Status is the controlling fact.

| Property | Value | Status | Source | Scope |
| --- | --- | --- | --- | --- |
| Canvas | 16 x 16 px | **Requirement** | User instruction this session | All drone sprites in this project |
| Frame | Dark frame, 2 px thick, surrounding the teal body | **Requirement** | User instruction this session | All drone sprites in this project |
| Antennae | Two antenna islands, detached from the body | **Requirement** | User instruction this session | All drone sprites in this project |
| Opaque component count | Exactly 3 (body + 2 antenna islands) | **Requirement, derived** | Derived from the two rows above: one framed body mass + two detached islands | This drone family; derivation assumes the frame is a single closed mass |
| Connectivity rule | 4-connectivity, nonzero alpha | **Declared measurement convention** | `pixl_asset_check` default; method `semantic-clusters` ("declare a 4- or 8-neighbor rule") | Measurement only, carries no aesthetic verdict |
| Palette | Not fixed | **Unresolved — user has not approved a palette** | User instruction this session | Blocks any exact-color rejection rule |
| Frame color `#25354A`, body `#56B5BC`, eyes `#F4DDA2` | 64 / 22 / 2 px | *Observation* | Measured from `small-separated.png` | Reference only; not adopted |
| Reference body block | x 3..12, y 6..13 (10 x 8) | *Observation* | Measured | Reference only |
| Reference teal interior | x 5..10, y 8..11 (6 x 4 = 24 px) | *Observation* | Measured | Reference only |
| Reference antennae | Two 2x2 blocks at x 5..6 and x 9..10, y 2..3 | *Observation* | Measured | Reference only; size/pitch not adopted |
| Reference gaps | 2 transparent rows body-to-antenna; 2 px between the antennae | *Observation* | Measured | Reference only; exact gap not adopted |
| Reference eyes | 1 px each at (6,9) and (9,9); 1 px clear of the teal edge, 3 px clear of the outer contour | *Observation* | Measured | Reference only |
| Alpha | 0 fractional-alpha pixels (fully binary) | *Observation* | `pixl_asset_check`: `fractional_alpha_pixels: 0` | Reference only; see open decision 2 |
| Margins | 3 px left/right, 2 px top/bottom; bbox `[3,2,13,14]` | *Observation* | `pixl_asset_check` | Reference only |
| Visual quality | Not established | *Unverified* | `visual_quality_verified: false` | Measurement cannot supply artistic acceptance |
| Engine import | Not established | *Unverified* | `engine_import_verified: false`; no target project supplied | Remains unavailable until a destination exists |
| Provider reliability at 16 px | Unknown | *Untested expectation* | No generation attempted this session | See section 5 |

---

## 2. What the reference actually contains

```
   0123456789012345
 0 ................
 1 ................
 2 .....00..00.....     0 = #25354A  (dark)   64 px
 3 .....00..00.....     1 = #56B5BC  (teal)   22 px
 4 ................     2 = #F4DDA2  (cream)   2 px
 5 ................     . = alpha 0
 6 ...0000000000...
 7 ...0000000000...
 8 ...0011111100...
 9 ...0012112100...
10 ...0011111100...
11 ...0011111100...
12 ...0000000000...
13 ...0000000000...
14 ................
15 ................
```

Measured: 16 x 16, 88 visible pixels, 3 visible colors, 3 opaque components, bbox `[3,2,13,14]`,
0 fractional-alpha pixels.

The reference is consistent with all three of your stated choices: the canvas is 16 x 16, the dark
frame is exactly 2 px on all four sides of the teal region, and the two antenna blocks are separate
opaque components. Nothing in the brief conflicts with the supplied pixels.

**Interior budget (the one real design consequence).** A 2 px frame on a 10 x 8 body leaves a 6 x 4
teal interior — 24 pixels, 30% of the body block. The reference spends 2 of those on eyes and
leaves 22 flat. Any "matching drone" with more facial or panel detail has to fit inside those 24
pixels, or move the body block wider within the 16 x 16 canvas (the reference leaves 3 px of unused
margin on each side, so a 12 px or 14 px wide body is available). This is a budget to plan around,
not a defect.

---

## 3. Disposition of `old-assessment.md`

That file records an unapproved diagnostic on a *different* robot, produced by nearest-neighbor
downscaling a 32 px source. Its three proposals are not carried into this approach:

1. **"32 px minimum for thick outlines"** — not adopted. It was measured on a different sprite via a
   resized fixture, and the supplied reference is a direct counter-example at 16 px: the 2 px frame
   leaves a usable 6 x 4 interior and the eyes sit 3 px clear of the outer contour, not touching it.
   A diagnostic stays attached to its tested artifact, method and scale.
2. **"One connected component for all sprites"** — not adopted; it directly contradicts your
   requirement for two detached antenna islands. A component count is a measurement, never an
   automatic aesthetic failure (`semantic-clusters`: deleting every isolated pixel destroys
   legitimate detail — here, the eyes are legal singletons and the antennae are legal islands).
3. **"Lock all props to the observed three colors"** — not adopted. You have not approved a palette,
   so the three measured colors remain observations. `palette-contract` requires "an approved RGBA
   palette" before membership validation is meaningful, and notes that a fixed small palette is
   optional art direction, not a definition of pixel art.

None of the three has owner adoption, a measurement on this drone, or an engine test. They are
recorded here as superseded context, not deleted.

---

## 4. Plan: one representative sample before any batch

**Sample (F1):** a single 16 x 16 drone sprite, front-facing, matching the reference aesthetic.
Smallest useful unit; nothing else is produced until it is accepted.

**Proposed sample subject** (proposal, see open decision 1): a *sibling* drone rather than a redraw
of the reference — same 16 x 16 canvas, same 2 px dark frame, same two detached antenna islands,
with a different interior face inside the 6 x 4 teal region and a different antenna pitch. Retained
alternative: an exact-style reproduction of the same drone unit. Both are viable; the choice changes
the prompt and the "matches the reference" criterion, so it is not being silently picked.

**Prompt content that must survive into the provider request and the review, verbatim in intent:**

- 16 x 16 pixel canvas, no upscaling
- a thick 2-pixel dark outline forming a closed frame around a teal body block
- two small antenna blocks floating above the body, fully separated from it by transparent pixels
- readable face detail confined to the enclosed teal area
- transparent background outside the silhouette

Color is described by hue family only ("dark desaturated blue-navy frame", "teal body", "warm pale
accent") until a palette is approved. Exact hex values are not to be placed in the prompt as a
constraint while the palette is unresolved.

---

## 5. Provider path

No PixelLab MCP tools are connected in this session; only the local `pixl-local` tools are present.
The dated documentation inventory (retrieved 2026-09-11, `live_discovery: false`) lists
`create_image_pixflux` / `create_image_pixen` / `create_image_pro` (required: `description`, poll
via `get_image`) and `create_map_object` as the plausible candidates for a single small object.
**This is documentation, not discovery.** Before any request: discover the actual tools and schemas
in the harness, then `pixl_job_prepare` the exact arguments against the task and output plan, then
`pixl_job_dispatch` to claim the single dispatch, then the host performs the call.

Whether a generator will hit an exact 2 px frame thickness and cleanly detached islands at 16 x 16
is an **untested expectation**. Plan for it rather than assuming it:

- Treat the first return as a candidate to measure, not an asset.
- If the frame lands at 1 px or 3 px, or the antennae fuse to the body, the realistic recovery is
  authored pixel correction of the returned candidate (the structure is 88 pixels; hand-placement is
  cheap here), or `correct_pixelart` / `inpaint_image` if those are actually available.
- A fully authored sprite, with the generator used only for exploration, is a legitimate fallback
  and should not be treated as a failure of the plan.

---

## 6. Acceptance criteria for the sample

Separated by evidence mode. Mechanical measurement does **not** satisfy visual or engine criteria.

**Q-mech — mechanical (evidence: `pixl_asset_check` on the saved candidate file)**

- Canvas is exactly 16 x 16. *(Requirement)*
- Exactly 3 opaque components under 4-connectivity, nonzero alpha. *(Requirement, derived)*
- Exactly 2 of those components are disjoint from the body mass and lie above it, separated by at
  least one fully transparent row. *(Requirement)*
- On every side, exactly 2 dark pixels lie between the outer body contour and the enclosed body
  color. *(Requirement)*

**Q-vis — visual (evidence: host viewing of the actual candidate at native scale and enlarged,
against light, dark and busy backgrounds; method `silhouette-readability`)**

- The frame reads as a single thick dark border and the interior reads as a teal body — the two
  colors separate at native size. *(Requirement, judged by eye because no palette is approved)*
- The two antenna islands read as attached-in-intent antennae, not as stray noise, and the gap
  stays open at native scale on all three backgrounds. *(Requirement)*
- Interior face detail is legible within the enclosed area and does not collide with the frame.
  *(Proposal-level; reflects the reference's 1 px eye clearance, which is an observation)*
- The sprite reads as a sibling of `small-separated.png`. *(Requirement of "matching"; judged by
  side-by-side viewing of the two files, not by any numeric metric)*

**Q-engine — engine import (evidence: actual import into the destination project)**

- **Currently unavailable.** No target engine or project has been supplied. This is recorded as
  unavailable with that reason — not as a pass, and not as an artistic failure.

**Explicitly NOT rejection rules** (each would exceed present authority):

- exact color membership / a 3-color lock — palette unresolved
- a 32 px minimum canvas — unapproved, and refuted for this design at 16 px
- single-connected-component — contradicts the brief
- the reference's specific bbox, 3 px side margins, 2 px gaps, 2 x 2 antenna size, or eye
  coordinates — all observations
- binary alpha — observed in the reference, not yet stated by you (see open decision 2)

---

## 7. Sequence

1. Resolve open decisions 1 and 2 below.
2. `pixl_intake` a PX2 project; record canvas / frame / islands as **confirmed** choices, palette as
   **unresolved** (or confirmed, per decision 1), reference measurements as **observations**, and the
   sibling-vs-reproduction choice as confirmed. Save Q-mech / Q-vis / Q-engine *before* generating.
3. Discover real provider tools and schemas; `pixl_job_prepare` + `pixl_job_dispatch`; host executes.
4. `pixl_job_import` the return as a candidate; run `pixl_asset_check`.
5. `pixl_inspection_prepare` native + enlarged views; **view them**; `pixl_inspection_review` with
   explicit per-criterion verdicts. Record Q-engine as unavailable with its reason.
6. On failure, retain the failed candidate, evidence and verdict; revise and re-nominate. Only after
   Q-mech and Q-vis pass does the family operation open, with this sprite as the baseline.

---

## 8. Open decisions for the project owner

**Decision 1 — palette status.** Until you answer, production checks omit exact color membership
entirely and the prompt names hue families only.

- (a) Adopt `#25354A` frame / `#56B5BC` body / `#F4DDA2` accent as the confirmed project palette.
  Unlocks an exact membership check and exact hex in the prompt. Constrains every future prop.
- (b) Keep the palette open. Color is reviewed by eye against the reference; no color rejection rule.
  An optional labeled palette experiment can run later without committing you.
- (c) Confirm frame + body only, leave the accent open for per-unit variation.

**Decision 2 — alpha (small, can ride along).** The reference is fully binary alpha. Confirm binary
alpha as a project requirement, or leave it open and allow soft edges on the antennae?

**Also needed, and currently a proposal, not a decision I should make for you:** is the sample a
*sibling* drone (my proposal — different face and antenna pitch, same treatment) or a *reproduction*
of the same drone unit? This changes both the prompt and what "matching" means at review.
