# Production approach — small lantern prop matching `translucent-reference.png`

Scope of this document: a planning approach only. No PX2 state was created or amended, no art
was produced, and no provider was called. Nothing below is an acceptance record.

## 1. What the reference actually contains

Measured with `pixl asset-check` and an exact RGBA histogram, then viewed at native scale and at
12× over white, mid-gray and black.

| Measurement | Value |
| --- | --- |
| File | `translucent-reference.png`, sha256 `bda5c9b1…b17132` |
| Canvas / frames | 32 × 32, 1 frame, RGBA PNG |
| Visible pixels | 420 of 1024 |
| Visible bbox | x 6–25, y 3–27 (20 wide × 25 tall) |
| Opaque colors | 3 — `#56B5BC` teal (186 px), `#25354A` navy (180 px), `#F4DDA2` cream (24 px) |
| Fractional-alpha pixels | 30, all `#56B5BC` — 15 at α=96 (37.6%), 15 at α=160 (62.7%) |
| Opaque components | 1 (4-connectivity) |

Structure, read off the pixel map: a navy chassis with two upright posts and a notch between them
(y 3–8), a solid navy band (y 9–10), a teal panel inset inside navy side rails (y 11–25), two
cream rectangles inside the teal (x 11–13 and x 18–20, y 14–17), and a navy base band (y 26–27).
The fractional-alpha pixels are two single-pixel vertical columns *outboard* of the chassis —
x = 6 at α=96 and x = 25 at α=160 — each spanning exactly the teal panel's rows, y 11–25.

Two consequences matter for the plan:

- Every opaque boundary in the reference is hard. There are no intermediate opaque colors between
  neighbors, no softened corners, and no AA on the chassis silhouette.
- The translucent columns are the same teal RGB at reduced alpha, placed outside the opaque form
  rather than inside an existing edge. They extend the silhouette; they do not smooth one.

## 2. Reported uncertainty: what "selective anti-aliasing" refers to

The brief states the reference uses intentional partial transparency **and** selective
anti-aliasing, and that both are to be kept. Partial transparency is directly confirmed by the
30 fractional-alpha pixels. Selective anti-aliasing is **not** confirmed in the classical sense
described by method `selective-edge-aa` ("choose intermediate colors from the approved ramp inside
the selected boundary region") — the image contains no such intermediate opaque colors.

The only mechanism in the file that can carry the term is the pair of alpha columns, which can be
read as **alpha-based** edge softening applied to selected edges only: the two vertical outer edges
of the glass panel, with top, bottom, corners, posts and the cream inserts left deliberately hard.
That reading is selective and is an edge treatment, so it satisfies the brief's terminology under an
alpha mechanism rather than a color mechanism.

This is a reported difference between my reading of the pixels and the brief's wording, not a
licence to drop or replace either treatment. Both partial transparency and selective
anti-aliasing are carried into the sample plan, the provider instruction and the review criteria in
sections 4–6 below. An alternative reading of those columns — "glow", "light spill", "translucent
side panes" — would describe the same pixels, but adopting any of them as *the* interpretation is
the user's call, and none of them may be substituted for the requested treatment. Question Q1 in
section 8 resolves which mechanism the new prop must author; the answer changes the acceptance check
and the prompt wording, so it is worth one round trip.

## 3. Authority table

Every enforced restriction in this document traces to a row here.

| Property / value | Authority & status | Exact source | Applies to |
| --- | --- | --- | --- |
| Partial transparency is retained in the new props | **Requirement** | User brief: "uses intentional partial transparency … Keep that treatment in the new props" | All new props |
| Selective anti-aliasing is retained in the new props | **Requirement** | Same brief sentence | All new props |
| No fixed palette is imposed | **Requirement (negative)** | User brief: "I have not imposed a fixed palette" | All production checks |
| Subject is a small lantern prop matching the reference | **Requirement** | User brief | This family |
| Deliverable is this Markdown only; no PX2 state, no art, no provider call | **Requirement** | Evaluation instruction | This session |
| Canvas 32 × 32 | **Observation** of the reference → **Proposal** for the prop | `asset-check` width/height | Proposal, unconfirmed |
| Content bbox 20 × 25 within the canvas | Observation | `asset-check` `visible_bbox [6,3,26,28]` | Reference only |
| Opaque colors `#56B5BC`, `#25354A`, `#F4DDA2` | Observation → optional starting ramp | RGBA histogram | Reference only; not a membership rule |
| Alpha levels 96 and 160, teal only | Observation | RGBA histogram | Reference only; not a required level |
| 30 fractional-alpha px in two 1-px columns, x 6 and x 25, y 11–25 | Observation | Pixel map | Reference only |
| All opaque boundaries hard; zero intermediate opaque colors | Observation | Pixel map, 3 opaque colors | Reference only |
| `opaque_components = 1` | Observation | `asset-check` | Reference only; not a rejection threshold |
| Straight (non-premultiplied) alpha, declared explicitly | **Proposal** | Method `alpha-contract`: "Keep alpha policy separate from RGB palette membership" | All props |
| α=96 left vs α=160 right means light from the right | **Interpretation, untested** | My reading of the histogram | Not a rule |
| Selective AA in the reference is alpha-based, not color-based | **Interpretation, untested** | Section 2 | Not a rule until Q1 is answered |
| PixelLab provider tools present in this session | **Observed absent** | Session tool list contains only `pixl-local` tools | Blocks any generation step |
| Documented tool inventory (`create_1_direction_object`, etc.) | **Dated documentation, not live discovery** | `pixl_capabilities`, `retrieved_at` 2026-09-11, `live_discovery: false` | Candidate surfaces only |
| A provider tool returns and preserves fractional alpha | **Untested expectation** | None | POC-1, section 5 |

## 4. Style contract proposed for the prop

Confirmed requirements first, then proposals. Nothing marked *proposal* is a rejection rule.

**Required (from the brief)**

1. The prop authors intentional partial transparency: a declared region carries fractional alpha,
   chosen by the artist, not produced as a resampling by-product.
2. The prop authors selective anti-aliasing: an explicit edge mask receives the treatment, and every
   edge outside that mask stays hard.
3. No palette membership is enforced. Color choice is open.

**Proposed (open, to be settled by the sample)**

4. Canvas 32 × 32, straight-alpha RGBA PNG, single frame — matching the reference so the prop can sit
   next to it without rescaling.
5. Form: a hanging lantern — a navy top bail/hook and cap, a translucent teal glass body, a warm
   cream flame cluster inside the glass, a navy base. This mirrors the reference's material
   vocabulary (dark chassis / teal glass / cream light source) rather than copying its geometry.
6. Starting ramp seeded from the reference's three opaque colors, with a fourth darker navy allowed
   for the cap shadow if the sample needs it. This is a starting point, not a contract — an exact
   palette check is explicitly excluded by the brief.
7. Translucency region: the outer edge of the glass body, the mechanism per Q1.
8. Alpha levels: two levels, values chosen for the new form. The reference's 96/160 are a useful
   starting pair and an asymmetric pair is worth trying, but neither is required.
9. Protected hard edges: the bail, cap silhouette, base silhouette, and the flame cluster's own
   boundary remain hard, per `selective-edge-aa` ("preserve required hard edges and avoid universal
   outlines of intermediate color").

## 5. Proof of concept before any batch

One uncertainty governs everything downstream, and it is untested.

| Field | Content |
| --- | --- |
| **Question** | Can the selected authoring surface produce a sprite that carries authored fractional alpha confined to a chosen edge mask, with all other edges hard — and does that alpha survive any downstream correction/palette-reduction step? |
| **Method** | A PixelLab image or object tool seeded with `translucent-reference.png` as a style image (`create_1_direction_object` requires `description` + `style_images` and is the documented surface that accepts them). Surface and schema must be discovered live before use; the inventory above is dated documentation. |
| **Smallest artifact** | One 32 × 32 lantern sprite. Not a set, not an animation. |
| **Acceptance (stated before results)** | (a) `asset-check --alpha full` reports `fractional_alpha_pixels > 0`; (b) those pixels fall inside the declared edge mask and nowhere else; (c) protected hard edges contain no unintended intermediate pixels; (d) at 8× on a light and a dark background, the translucent region reads as deliberate and does not read as a fringe or halo against either. |
| **Consequence** | Pass → proceed to the prop family under the confirmed contract. Fail on (a) → the provider cannot author the treatment; the alpha edge becomes a separate authored post-pass over the returned opaque sprite, and the provider's role narrows to silhouette and color. Fail on (b) or (c) → the treatment is uncontrolled; tighten the prompt or move the treatment entirely to the post-pass. Fail on (d) → re-choose alpha levels against the actual target background. |

A second, optional experiment — not a gate: seed the same prompt with and without an explicit color
list to see whether a constrained ramp improves family consistency. Since no palette is imposed,
this stays a labeled experiment and produces no rejection rule either way.

Neither the method recipes nor a prompt copied from the reference can guarantee the outcome of
POC-1. The expectation that a generator preserves fractional alpha is untested here; method
`material-channel-budget` states the general form of this trap directly — "an image generator
returning a map does not establish that an engine consumes it correctly."

## 6. Review criteria for the sample

Declared before any candidate exists, with evidence mode separated per
`intake-sample.md` §"Preserve intake and plan before execution".

| ID | Criterion | Evidence mode | Basis |
| --- | --- | --- | --- |
| Q-mech-alpha | `fractional_alpha_pixels > 0`, and every fractional pixel lies inside the declared edge mask | Mechanical — `asset-check --alpha full`, plus a mask comparison | Requirement (transparency) |
| Q-mech-hard | Edges outside the mask contain no unintended intermediate or fractional pixels | Mechanical — pixel diff against the authored mask | Requirement (selective AA) |
| Q-mech-size | Matches the confirmed canvas once Q2/§8 settles; single frame; straight-alpha RGBA | Mechanical — `asset-check --width/--height` | Proposal until confirmed |
| Q-vis-treat | The translucent edge and the selective AA read as intentional at native scale and at 8×, on a light and a dark background | Visual — host views the prepared packet | Requirement (both treatments) |
| Q-vis-match | The prop reads as the same material vocabulary and lighting family as the reference when placed beside it | Visual — side-by-side at native and 8× | Requirement (matching) |
| Q-vis-silhouette | Bail, glass body and flame remain separable at 32 px against light, dark and busy backgrounds | Visual — per `silhouette-readability` | Proposal |
| Q-engine | Import sampling, alpha edges and pixel scale behave correctly in the destination | **Unavailable** — no destination engine has been named | Recorded as unavailable, not as a pass or a failure |

Deliberately **not** criteria: exact palette membership (excluded by the brief); the reference's
exact alpha values 96/160; the reference's exact bbox; `opaque_components == 1`. Each of those is an
observation in section 3 and none of them is an adopted rule.

Review mechanics when the sample exists: `inspection-prepare` with the reference registered as an S,
`scale: 8`, and backgrounds covering at least one light and one dark value, then actual host viewing
of the prepared views before any verdict. Method `alpha-contract` requires exactly this —
"inspect edges against light and dark backgrounds after round-trip import" — because a
background-tuned translucent edge can halo on a different background. Preparing the packet is not
reviewing it; a verdict requires that the views were opened.

## 7. Provider status

No PixelLab tools are present in this session — the only MCP tools available are the local `pixl-*`
tools, none of which submits, polls or generates. `pixl_capabilities` returns a documentation
inventory dated 2026-09-11 with `live_discovery: false`, so the tool names in section 5 are
candidates to verify, not confirmed availability.

The precise missing capability: **a connected PixelLab MCP surface with credentials, plus live
schema discovery for the chosen generation tool.** Until that exists, the plan, the POC design and
the criteria are usable, but no sprite can be generated. When it is wired, the sequence is
`job-prepare` (save the exact request against its task and output plan) → `job-dispatch` (claim the
single dispatch) → one host call → `job-observe` → `job-import`, then inspection. That sequencing is
out of scope for this document and requires PX2 state, which this evaluation excludes.

## 8. Open decisions

**Q1 — AA mechanism.** For the new prop, should selective anti-aliasing be authored as
(a) alpha-based softening on selected edges, matching what the reference's columns appear to do, or
(b) intermediate opaque colors on selected edges, the classical form, which the reference does not
contain and which adds colors to the ramp? Answer sets Q-mech-hard's exact test and the prompt wording.

**Q2 — Destination and target background.** Which engine and what background will the prop sit on?
Without it, Q-engine stays unavailable and the alpha levels in §4.8 cannot be validated against the
real compositing context — only against generic light/dark proxies.

Canvas is proposed at 32 × 32 (§4.4) and needs no answer unless it is wrong.

## 9. Provenance

Derived from `translucent-reference.png` supplied by the user in this project, sha256
`bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`. The plan reuses the reference's
measured material vocabulary and edge practice as observations and redraws the prop's geometry as an
original form; no reference pixels are copied into the deliverable. Per method `asset-provenance`,
reuse basis for redistributing the reference itself is unrecorded and remains to be resolved if the
reference ships with the prop.

## 10. Methods consulted

`alpha-contract`, `selective-edge-aa`, `palette-contract`, `silhouette-readability`,
`asset-provenance`, `material-channel-budget` — retrieved from the bundled knowledge library.
Each carries a bounded POC receipt for its own fixture; none of those receipts is evidence about
this lantern prop.
