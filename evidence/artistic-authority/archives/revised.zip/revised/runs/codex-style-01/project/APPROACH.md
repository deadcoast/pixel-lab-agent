# Matching lantern production approach

Prepare a compact, frontal lantern with dark structural framing, a cool turquoise body and a small warm light. Preserve the reference's intentional partial transparency and selective anti-aliasing through authored pixels and an RGBA workflow. Color choices remain flexible. A 32 × 32 first trial is a useful proposal because it permits direct comparison with the reference; the final canvas depends on the intended display size.

This document completes the bounded planning evaluation. Only the supplied reference and local documentation were inspected. No project PX2 state was initialized or amended, no production art was created, and no provider was called. The future trial below has not been executed or accepted.

**Reference evidence**

Inspected `translucent-reference.png` directly with the host image viewer, then inspected an in-memory 8× nearest-neighbor enlargement composited over white, dark slate (`#202838`), middle gray (`#808080`) and a gray checkerboard. The enlargement was a 512 × 512 inspection sheet containing four 256 × 256 panels; no image derivative was saved. Physical screen scaling is unknown, so these views establish reference observations, not target-display acceptance.

The image presents a flat, frontal arrangement of dark navy framing, two upper uprights, a turquoise rectangular panel and two pale warm rectangular accents. Large flat clusters and hard horizontal/vertical boundaries dominate. Narrow cyan strips soften the sides selectively. Against slate, the dark frame becomes less prominent; against white, the side transparency is particularly apparent. The reference does not establish a clear directional-lighting convention.

Local PIXL measurement and a read-only Pillow pixel census found:

| Property | Observed value |
| --- | --- |
| File | Single-frame RGBA PNG, 32 × 32 |
| Visible bounds | `[6, 3, 26, 28)`, using exclusive right/bottom bounds; 20 × 25 footprint |
| Pixel coverage | 604 transparent, 390 opaque, 30 partially transparent |
| Opaque colors | Navy `#25354A` (180 pixels), turquoise `#56B5BC` (186), warm pale `#F4DDA2` (24) |
| Partial alpha | Turquoise at alpha 96 (15 pixels) and 160 (15 pixels), on an 8-bit 0–255 scale |
| Partial-alpha locations | Left strip at x=6 and right strip at x=25, both y=11…25; zero-based coordinates |
| Color-count interpretation | Three visible RGB colors; five visible RGBA combinations because turquoise has three alpha values |

The main turquoise panel is opaque. The measured translucency is localized to the side strips. The user identifies this treatment as intentional partial transparency and selective anti-aliasing; preserve that intent even though the visible edge strips are straight. Their positions and opacity asymmetry are observations, not required coordinates or a lighting rule for the lantern.

**Authority and proposed choices**

| Property | Authority and status | Consequence for the lantern |
| --- | --- | --- |
| Matching small lantern | User requirement: “a small matching lantern prop” | Preserve the visual relationships while giving the new object a recognizable lantern silhouette. |
| Partial transparency and selective AA | User requirement: “Keep that treatment in the new props” | Retain intentional intermediate alpha and selected softened edges throughout authoring, export and eventual display. |
| Palette | User: “I have not imposed a fixed palette” | No exact swatch whitelist, color-count ceiling or automatic palette quantization. Reference colors can seed a trial; additional hues and ramp steps remain available. |
| Canvas and footprint | Reference measurement; 32 × 32 trial proposed by PIXL | Use that size for a first comparison if no destination size is supplied. Do not enforce the reference bounds or treat 32 pixels as a proven minimum. |
| Form, projection and lighting | Frontal construction observed; lantern design proposed by PIXL | Trial a loop handle, compact cap, framed body, firm base and warm central light. Keep broad shapes readable; final proportions and illumination remain open. |
| Background and destination | Unresolved; no engine, scene or display scale supplied | Diagnostic backgrounds support planning. Final edge and import judgments need the actual destination. |

No downstream check converts a measured color, alpha value, component count, margin or dimension into an additional artistic requirement.

**Proposed production sequence, for a later art task**

1. Establish the intended on-screen footprint and representative scene background. If these remain unavailable for an exploratory trial, label 32 × 32 and the diagnostic backgrounds as assumptions. A standing lantern could use a bottom-center anchor; hanging or inventory use could require a different anchor.
2. Draw one static lantern in an RGBA-capable pixel editor. Start with its handle opening, cap, side frame and base so it reads as a lantern at the trial size. Translate the reference's broad dark/cool/warm relationships into a cool body with one concentrated warm light. The reference's two accents need not become two lights.
3. Place partial transparency deliberately in narrow glass-edge or light-edge regions. Use the observed alpha levels as optional starting samples, adjusting them by appearance. Keep alpha policy separate from RGB choices. Whole-panel translucency or a larger glow would be additional trial proposals because the source only demonstrates localized partial alpha.
4. Author selective AA where the handle contour or chosen glass edges benefit. Identify those regions during the trial and preserve the intended hard structural boundaries elsewhere. Tune intermediate RGB and alpha together against the test backgrounds. Avoid global smoothing, blanket edge treatment or binary-alpha cleanup that would erase the requested selective treatment.
5. Compare reference and lantern at native size and 8× nearest zoom. Export the trial as an RGBA PNG retaining intermediate alpha. Proposed interchange uses straight alpha; any destination conversion to premultiplied alpha must match its blend configuration and preserve the intended appearance. Point sampling is a proposed way to display the authored edge pixels; selective AA does not itself require bilinear filtering.

**Smallest useful future proof**

Question: can one small lantern remain recognizable while its selected translucent and antialiased edges retain the reference character across relevant backgrounds?

Artifact: one static lantern candidate and comparison views with the unchanged reference. There is no need for variants, animation, normal maps or an engine lighting system to answer this first question.

| Review | Observable condition proposed before creating the candidate |
| --- | --- |
| Mechanical | PNG decodes at the trial dimensions and preserves deliberately authored pixels with `0 < alpha < 255`. Reopening/exporting does not silently threshold their alpha. Use PIXL `asset-check` with `alpha: full` and omit a palette restriction. A pass alone cannot establish style quality. |
| Lantern identity | Handle, enclosure and light read together as a lantern at its intended displayed size; essential features do not merge into an ambiguous block. |
| Reference match | Broad navy/cool/warm relationships, compact flat clusters, localized translucency and selective edge softness remain apparent in side-by-side viewing. Exact swatches and pixel counts are not acceptance gates. |
| Edge behavior | Inspect on light, dark and eventual scene backgrounds. Partial edges blend intentionally without an unintended matte fringe or accidental overall blur. Background-dependent visibility is assessed artistically, not rejected through a universal contrast threshold. |
| Eventual import | Once a destination exists, inspect the exported sprite through its actual sampling, blending, display scale and atlas path if applicable. Check for alpha clipping, double premultiplication and padding bleed. Until then, import behavior remains unverified. |

If a trial loses clarity, revise the specific handle, light or edge region and repeat the affected comparison. A failure at one size/background informs that candidate; it does not establish a universal minimum canvas or justify removing the user's requested transparency. Keep visual, mechanical and destination results separate.

**PIXL research retained for resumption**

Selected methods: `selective-edge-aa` and `alpha-contract`. Their method descriptions and complete compiled context packets were read from the packaged library. Local source discovery reported `files_verified: true`, and the cited ranges below were retrieved with their expected hashes. This verifies local source identity, not external claims.

| Source under `.agents/skills/pixl-kit/resources/` | Exact ranges and relevance |
| --- | --- |
| `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md` | 590–632: authored coverage cues and an edge ramp, with a strict-palette branch that does not become a requirement here. 907–919: distinction between authored AA and runtime filtering. |
| Same research document | 945–977 and 1276–1291: channel layout and companion alignment. These alpha-method citations have limited relevance to this single RGBA prop and do not establish a complete alpha-import contract. |
| `training/original-docs/PIXEL-ART-ASSETS.md` | 942–958: a CSS heart effect using opacity, blur and animation. This is not evidence for a PNG alpha convention or a reason to blur this lantern. |

The selective-AA recipe assumes an approved edge ramp/mask and known backgrounds. Here the trial would propose those local edge choices with flexible colors, then review them; there is no approved fixed palette. The alpha recipe's binary-alpha check applies to binary-alpha assets and is inapplicable to this user's requested treatment. Renderer blend behavior remains a future proof obligation.

Read the existing `evidence/art-methods/poc-report.json`; did not rerun its fixtures. Its `selective-aa-boundary` receipt proves edit locality and fixture color membership, not perceptual AA quality or suitability on arbitrary backgrounds. Its `alpha-compositing-contract` receipt proves bounded linear numeric examples, not display transfer functions, GPU blending or importer behavior. These receipts do not prove this planned lantern or authorize production acceptance. Historical external citation tokens in the local research were not independently verified; no current engine-specific capability claim is adopted.

Source SHA-256 identities:

- Reference: `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`
- Deep research: `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`
- Asset archive: `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`
- Existing POC report identity in the context: `9972632317a17f66d48314feff94d7832c1d5a83db9f7cfaf588a6e703af6e79`

The approach is ready for review. The useful next decision before a future production task is the lantern's intended display size and representative background; those determine how small its handle/light can be and how its partial edges should read. No further decision is needed to complete this Markdown evaluation.
