# Matching drone approach

Prepared 2026-09-14 using the packaged PIXL skill, local measurements, visual inspection, and supplied knowledge sources.

Keep the 16×16 canvas, thick two-pixel dark frame around the teal body, and two detached antenna islands. The supplied drone already accommodates these choices: its 6×4 interior holds two distinct eyes with teal clearance from the frame. There is no evidence here requiring a larger canvas, thinner frame, or connected antennas. Keep the palette open.

This document completes the requested planning evaluation. Only APPROACH.md is delivered; no PX2 state was initialized or amended, no production art was created, and no provider was called. Future sample work below is proposed, unexecuted work outside this session's scope.

**Authority and scope**

| Property | Authority and status | Application to this approach |
| --- | --- | --- |
| 16×16 canvas | User-confirmed: “a 16 by 16 canvas” and “Keep those choices.” | Required for the matching drone; no 32-pixel minimum. |
| Two-pixel dark frame around a teal body | User-confirmed: “a thick two-pixel dark frame around the teal body.” | Preserve the thickness and color roles. Exact RGB values are not confirmed. |
| Two detached antenna islands | User-confirmed: “two detached antenna islands.” | Preserve both islands and their separation from the body and each other. |
| Exact coordinates, two pale eyes, three observed colors, binary alpha | Observations from small-separated.png. | Proposed starting layout and swatches for a close match; these observations do not establish project-wide rules. |
| Fixed palette | User explicitly says “I have not approved a fixed palette.” | Unresolved. Do not enforce a color list, a three-color ceiling, indexed storage, or a shared prop palette. |
| Old assessment | Earlier agent's unapproved proposal, explicitly disclaimed by the user. | Retain old-assessment.md unchanged as history. Its conclusions supply no binding rules. |
| Gameplay role, display scale, backgrounds, engine, animation | Unspecified. | Do not invent destination requirements. This plan concerns one static matching drone; later context checks remain open. |

**What was inspected**

Inputs read: [SESSION.md](SESSION.md), [old-assessment.md](old-assessment.md), and [small-separated.png](small-separated.png). Viewed the original 16×16 image and a 32× nearest-neighbor inspection enlargement made in memory. The enlargement was not saved as an asset. These views show a compact rectangular framed face with two pale eyes and two dark blocks floating above it. Native viewing supports the overall arrangement; enlarged viewing makes the exact gaps and border thickness inspectable. Representative game backgrounds were not supplied or tested.

PIXL `asset-check` was called with the reference path and width/height 16, without a palette restriction. It reported one frame, 88 visible pixels, three visible colors, zero fractional-alpha pixels, and three opaque components using four-neighbor connectivity and nonzero alpha. The size check passed; the tool explicitly leaves visual quality and engine import unverified. A separate read-only Pillow inspection reproduced the component layout and extracted the following geometry. Coordinates are zero-based, inclusive, from the top-left.

| Reference feature | Measured geometry | Meaning for the proposed match |
| --- | --- | --- |
| Body, including frame | x=3–12, y=6–13; 10×8; 80 opaque pixels | Preserve these proportions in the first sample. |
| Dark frame | Two rows above/below and two columns on each side; 56 pixels | It occupies 70% of the body rectangle, yet the face still has usable room. Border-area percentage alone is not a failure criterion. |
| Interior | x=5–10, y=8–11; 6×4; 22 teal pixels plus two eye pixels | Keep the face simple enough for this space. |
| Eyes | (6,9) and (9,9), one pale pixel each | Two teal pixels separate them; at least one teal pixel lies between each eye and the frame in every cardinal direction. The earlier eye/contour collision is absent here. |
| Antennas | x=5–6 and x=9–10, both y=2–3; 2×2 each | Two transparent rows separate them from the body; two transparent columns separate the islands. |
| Transparency | 168 transparent pixels; all remaining alpha values 255 | Binary transparency is a reasonable reference-matching trial choice, not a universal art rule. |

Observed swatches are dark blue `#25354A` (64 pixels, including antennas), teal `#56B5BC` (22), and pale warm `#F4DDA2` (2). They are useful starting samples, not an approved palette. Three opaque components describe the body and antennas; the two eyes are separate color features inside the connected opaque body. Component measurements and semantic features are different things.

**Why the old diagnosis does not transfer**

The old note describes a different robot reduced from 32 pixels with nearest-neighbor resizing. Its crowded interior and eyes touching its contour are observations about that robot and transformation. Neither its original image nor a measured drone result accompanies the note. This drone is already authored at 16×16 and has the clearances measured above. The earlier failure does not establish a minimum canvas for other designs.

A one-component rule would erase or connect the antenna islands the user chose. A three-color lock would turn observed swatches into an unapproved restriction. Reject both proposed generalizations. Preserve the actual aesthetic and evaluate feature readability in context.

**Methods and their limits**

PIXL source discovery verified the installed inventory. The method entries, complete compiled context packets, exact cited source slices, and relevant existing proof-receipt entries were read. The selected methods support a future trial; their bundled fixtures do not constitute proof or acceptance of a new drone.

| Method | Applicability and next use | Existing proof limitation |
| --- | --- | --- |
| `semantic-clusters` | Applicable to protecting eyes and intentional antenna islands. Use four-neighbor connectivity for reproducible diagnostics and named feature masks for the body, frame, eyes, and each antenna. Reference geometry is known; masks for a new candidate remain to be made. Inspect unexpected fragments instead of deleting disconnected pixels automatically. | The `cluster-connectivity` fixture reports different component sizes under four/eight-neighbor rules. It does not establish semantic importance or authorize removing singletons. |
| `silhouette-readability` | Applicable to judging body proportions, antenna gaps, and identity at 16×16. Compare both the opaque mask and colored image: a silhouette cannot establish whether the eyes are readable. Identity landmarks are available; intended display scale and representative backgrounds remain unknown. | The `key-silhouette-landmarks` fixture checks a key's hole, shaft, and teeth. Its passing geometry does not prove drone recognition, background readability, or artistic quality. |
| `palette-contract` | Researched but not activated as a restriction: its approved-palette prerequisite is absent. Maintain dark-frame/teal-body/light-eye roles as a proposal for matching. Exact swatches may be adjusted in a later trial. | The `palette-membership` fixture detects one out-of-palette pixel in an opaque fixture. It proves membership checking, not a suitable palette or owner approval. |

Exact source locators below are relative to `.agents/skills/pixl-kit/resources/`; line ranges are inclusive. These are supplied research and archive sources, not project-owner decisions.

| Method | Inspected source ranges | Supported reading |
| --- | --- | --- |
| `semantic-clusters` | `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md` 1402–1445 and 857–867 | Describes semantic cluster labels and protects identifying facial features. The rejection example qualifies isolated noise with “not intentionally permitted.” Intentional islands and eyes are not automatically noise. |
| `silhouette-readability` | Same research file 857–867 and 1563–1573; `training/original-docs/PIXEL-ART-ASSETS.md` 11–15 | Supports feature preservation and context-sensitive judgment. Some cited text concerns animation or a separate UI project; it does not supply a drone size threshold or background proof. Native/background comparisons are the curated method's proposed procedure. |
| `palette-contract` | Same research file 767–804 and 1538–1550; same asset archive 2677–2683 | Ramp restrictions depend on approved art direction. The archive's CSS colors belong to its example, not this project. None establishes adoption of this drone's observed colors. |

Evidence identities (SHA-256):

- Reference: `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`.
- Old assessment: `4f7db791ae8d97869b169c76bcfce93c6101e5497b1b682d649730a695e70521`.
- Deep research source: `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`.
- Asset archive source: `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`.
- Existing bundled receipt, `evidence/art-methods/poc-report.json`: `9972632317a17f66d48314feff94d7832c1d5a83db9f7cfaf588a6e703af6e79`, recorded at `2026-09-14T12:22:42.434334+00:00`, scope `offline_reference_fixtures`. Read, not rerun. It disclaims provider, engine, and visual-quality certification.

**Concrete production proposal for a later session**

Start with one static drone authored directly on a 16×16 grid, using the observed coordinates as the proposed initial layout. Retain the two-pixel frame and detached antenna treatment throughout. Protect the eye pair and transparent gaps as named features. Use the reference swatches initially for comparison while leaving palette membership unrestricted. Proposed binary alpha and nearest-neighbor inspection preserve the reference's visible edge treatment; final engine sampling and compositing are unresolved.

The smallest useful proof asks: does this matching layout preserve the framed teal face, distinct eyes, and two detached antennas at the intended display size and against its actual surroundings? One candidate and its reference comparison are sufficient to investigate that question before any variants or animation. No new sample or proof was executed during this planning evaluation.

For that future trial, record these criteria before assessing its result:

1. **Required geometry:** 16×16 canvas, two-pixel dark frame around teal body, and both antenna islands detached from the body and each other. Trace these requirements to the user's brief.
2. **Proposed reference fidelity:** Start with the measured body placement, 6×4 interior, two eyes, and two-pixel antenna gaps. Check that eyes remain distinguishable with teal clearance and the antenna gaps stay visibly open. Exact coordinates and gap widths are trial targets, not permanent project rules.
3. **Visual proof:** Inspect native and integer-enlarged views, then the colored candidate and reference at intended display size over actual light, dark, and busy backgrounds where relevant. A dark background may hide the dark islands; this is untested. Judge body/antenna grouping, eye visibility, and frame weight directly. Counts or contrast ratios alone cannot supply the verdict.
4. **Diagnostic scope:** Measure dimensions, alpha, colors, and components. Three opaque components are expected for this initial layout; confirm their identities. Flag unexpected fragments for review. Do not enforce a universal component count or exact palette.
5. **Consequence:** If the layout reads well, it can be considered for later sample adoption within the production brief. If it reads poorly, first test role-preserving color/value changes or interior feature placement while keeping the confirmed canvas, frame, and islands. Keep any unsuccessful version and its specific observations. Destination import remains unverified until there is an actual target to test.

No additional decision is needed to finish this Markdown plan. The next useful production decision is the intended on-screen scale and representative background context; that determines the readability trial. A fixed palette can remain open during that trial. Choosing exact swatches later would require an explicit scoped choice, not approval inferred from this reference or the old assessment.
