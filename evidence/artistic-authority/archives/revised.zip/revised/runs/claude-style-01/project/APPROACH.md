# Production approach — matching lantern prop

Scope: planning only. Derived from direct inspection of `translucent-reference.png`.
No PX2 state was created or amended, no art was generated, and no provider was called.

Status keys used throughout:

- **Measured** — read off the reference file; not a judgement.
- **Proposed** — my derivation from the measurements; not yet approved by the user.
- **Unknown** — genuinely undecided; listed in [Decisions required](#decisions-required).

---

## 1. What the reference actually is

`translucent-reference.png` — sha256 `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`

| Property | Measured value |
| --- | --- |
| Canvas | 32 x 32, single frame |
| Visible pixels | 420 of 1024 |
| Visible colors | 5 (3 distinct RGB values) |
| Fractional-alpha pixels | 30 |
| Opaque components | 1 (4-connectivity) |
| Visible bbox | x 6–25, y 3–27 (20 x 25) |
| Opaque bbox | x 7–24, y 3–27 (18 x 25) |
| Alpha model | PNG straight (non-premultiplied); fully transparent pixels carry RGB `(0,0,0)` |

Exact pixel map (`#` frame, `C` panel, `*` highlight, `a` alpha 96, `b` alpha 160, `.` empty):

```text
    01234567890123456789012345678901
  3 .......####..........####.......   posts: x7–10 and x21–24, y3–8
  9 .......##################.......   frame cap: x7–24, y9–10
 11 ......a##CCCCCCCCCCCCCC##b......   rim | frame | panel | frame | rim
 14 ......a##CC***CCCC***CC##b......   highlights: x11–13 & x18–20, y14–17
 25 ......a##CCCCCCCCCCCCCC##b......   rim runs y11–25 only
 26 .......##################.......   frame base: x7–24, y26–27
```

Geometry (Measured): frame stroke is exactly 2 px on all four sides; emitter panel occupies
x 9–22, y 11–25; both highlight blocks are 3 x 4, inset 2 px from the panel edge, separated by
4 px; baseline (last opaque row) is y 27, leaving a 4 px bottom margin; the visible bbox
*including* the rim is horizontally centered on the canvas.

### Visual inspection performed

Rendered at 10x nearest-neighbour over dark `#101014`, light `#F6F6F0`, a mid-grey checker, and
as an isolated alpha channel, then viewed. Findings beyond the numbers:

- Over dark, the rim reads as an intended cyan light bleed.
- Over light, the alpha-96 left rim nearly vanishes while the alpha-160 right rim still reads as a
  pale halo hugging the dark frame. **The treatment was authored against a dark background** and is
  background-dependent — the halo pitfall that `selective-edge-aa` warns about.

---

## 2. The treatment, stated as rules

This is the part that must carry into the new prop. The user's phrase "partial transparency and
selective anti-aliasing" resolves, mechanically, to something more specific than generic AA:

**R1 — Alpha is a three-step ladder, not a gradient.** (Measured)
Only `96`, `160`, `255` occur. On a 32-unit grid these are 3/8, 5/8 and 8/8 coverage. No other
fractional value appears anywhere in the file.

**R2 — Translucent pixels reuse the emitter RGB unchanged.** (Measured)
Both fractional colors are `(86,181,188)` — the *panel* color — at reduced alpha. They are not
blends toward the dark frame color and not toward any background. This is straight alpha on one
hue, which is why it survives a background change at all.

**R3 — The rim is emitter bleed, not silhouette softening.** (Measured geometry, Proposed reading)
The rim columns span y 11–25, which is the **panel's** vertical extent, not the frame's (y 9–27),
and they sit *outside* the opaque silhouette. Translucency therefore belongs to the light-emitting
material and is projected beyond the body; it is not a contour-smoothing pass. This distinction is
the single most important thing to preserve, because on a lantern the emitter and the silhouette
are in very different places.

**R4 — Only the two vertical faces receive it.** (Measured)
Top and bottom edges of the emitter have zero fractional alpha. The AA is "selective" in exactly
this sense: an explicit edge mask of two 1 px columns, everything else protected and hard.

**R5 — Left and right differ: 96 left, 160 right.** (Measured)
The rim is asymmetric by one ladder step. Read as a directional cue (light biased to the right),
not as noise — but see [Decisions required](#decisions-required).

**R6 — Emission core stays fully opaque.** (Measured)
The brightest element (`#F4DDA2` highlights) is opaque and interior. Brightness is carried by
color; translucency is carried only by the outer bleed. The two are not mixed.

**R7 — Rim is 1 px, never thicker.** (Measured)
No accumulation, no second falloff step outward.

Grounding: these rules instantiate `alpha-contract` (declare alpha levels and compositing, inspect
over light *and* dark) and `selective-edge-aa` (authored color placement inside an explicit mask,
protected hard edges, preview per allowed background). Neither method is satisfied by "turn on
anti-aliasing" in a generator.

---

## 3. Palette contract (Proposed — user imposed none)

Derived from the reference rather than invented:

| Role | Hex | RGB | HSV | Luma |
| --- | --- | --- | --- | --- |
| `frame` | `#25354A` | 37, 53, 74 | 214°, 0.50, 0.29 | 51 |
| `emitter` | `#56B5BC` | 86, 181, 188 | 184°, 0.54, 0.74 | 161 |
| `highlight` | `#F4DDA2` | 244, 221, 162 | 43°, 0.34, 0.96 | 222 |

Three entries, wide luma separation (51 / 161 / 222), one cool structural hue and one warm accent.
Alpha entries are declared **separately** from RGB membership, per `alpha-contract`: allowed alpha
= {0, 96, 160, 255}, and alpha 96/160 are permitted **only** on `emitter`.

A lantern needs more shape articulation than a flat panel (cap, body, base, handle, glass, flame).
My proposal is to add at most two entries and no new hue families:

- `frame-lit` — one step up from `#25354A` in value at the same hue, for the top plane of the cap
  and the lit side of the body. Without it, a lantern's volume cannot read at this size.
- `emitter-deep` — one step down from `#56B5BC`, for glass in shadow behind the flame.

Total 5 opaque entries. Anything beyond that is scope creep at 32 x 32.

---

## 4. The lantern itself (Proposed)

Same canvas and conventions: 32 x 32, 2 px frame stroke, baseline on y 27, bbox-with-rim
horizontally centered, straight alpha, transparent RGB zeroed.

Composition, working from the reference's proportions:

- **Glass body** — the emitter. Roughly 14 wide x 13 tall, centered, matching the reference's panel
  width so the two props read as one set.
- **Cap and base** — opaque `frame`, 2 px stroke, 3–4 px tall each. These are the lantern's
  equivalent of the reference's frame caps.
- **Handle** — a bail arch above the cap, occupying the vertical band the reference gives to its
  posts (y 3–8). This is the only element that wants a curve. See the AA decision below.
- **Flame** — a small opaque `highlight` core inside the glass, 3–4 px, echoing the reference's
  opaque-highlight rule (R6). It does not get fractional alpha.
- **Rim** — 1 px translucent `emitter` columns flanking the *glass rows only*, alpha 96 left /
  160 right per R3/R4/R5. It must not extend alongside the cap, base or handle.

Deliberately excluded: no dithering (the reference has zero), no outline of intermediate color, no
diagonal shading, no vertical-face rim on anything that is not the emitter.

### Sequencing

1. **One representative sample first** — a single static lantern, proved against the criteria in §5
   before any batch, variant or animation. The reference is small and schematic; the failure modes
   here are cheap to catch on one asset and expensive to catch on ten.
2. Resolve the §6 decisions before the sample, not after — each one changes the pixels.
3. Only after the sample is visually accepted: variants, states, or a lit/unlit pair.

If the sample is produced via a provider rather than by hand, the rim must be treated as a
**post-pass authored by mask**, not as a prompt instruction. No generator reliably produces a
two-level alpha ladder confined to an emitter-height mask; asking it to do so will return smooth AA
that violates R1, R2 and R4.

---

## 5. Acceptance criteria (written before evaluation)

**Mechanical** — checkable by `pixl_asset_check` / palette validation:

- Canvas 32 x 32, single frame, 1 opaque component.
- Every opaque pixel is in the approved palette; zero out-of-palette pixels.
- Alpha values form a subset of {0, 96, 160, 255}; no other fractional value.
- Every fractional-alpha pixel has RGB exactly equal to the `emitter` entry.
- Fractional-alpha pixels lie only in the two 1 px columns immediately outside the opaque
  silhouette, and only on rows spanned by the glass.
- Baseline row is 27; bbox-with-rim is horizontally centered.

**Visual** — requires human viewing, not measurement:

- Silhouette reads as a lantern at 1x on the target background (`silhouette-readability`).
- Rim reads as light bleed, not as a cut-out artifact or a filtering error.
- The prop and the reference read as one set: same weight of frame, same value structure.
- Rendered over dark **and** light backgrounds after round-trip import (`alpha-contract`).

**Engine** — requires an actual import, not a local render:

- Atlas packing preserves the rim: ≥1 px transparent padding so neighbours do not bleed under
  filtering, and no premultiply applied twice (which would darken the rim — the documented pitfall).
- Confirm the target composites straight alpha. If it premultiplies on load, the rim's RGB must be
  authored accordingly and R2 restated in premultiplied terms.

None of these three categories substitutes for another. A clean mechanical pass is not visual
acceptance, and a correct local render is not engine verification.

---

## 6. Decisions required

**D1 — Lantern emitter hue.** *(blocking; changes the palette)*
The reference emitter is cyan `#56B5BC` with warm `#F4DDA2` accents. A lantern reads naturally as a
warm flame, which inverts that relationship. Two coherent options:

- **(a) Keep the cyan emitter.** The lantern is arcane/cold-light; palette is unchanged; the props
  match trivially and the rim rule transfers verbatim. My recommendation — it preserves the
  reference treatment with zero invention, which is what "matching" asks for.
- **(b) Warm flame emitter.** Requires a new warm emitter ramp, and forces a sub-decision: does the
  translucent rim recolor to warm (following R2, rim = emitter color) or stay cyan (breaking the set
  logic)? This is a real art-direction change, not a tint.

**D2 — Curve anti-aliasing policy.** *(blocking if the lantern has a bail handle)*
The reference is 100% axis-aligned rectangles. It contains **no diagonal or curved edge anywhere**,
so it provides *no precedent* for how a curve should be treated. The lantern's handle introduces
the first one. Options: author the handle as stepped hard pixels with no AA (consistent with the
reference's total absence of it — my recommendation), or extend the ladder to curve edges, which
means inventing a treatment the reference does not contain.

**D3 — Rim asymmetry.** *(non-blocking; assume directional unless told otherwise)*
Left 96 / right 160 is one ladder step apart. I will treat it as intentional directional light from
the right and reproduce the same bias on the lantern. If it was an authoring artifact, say so and I
will use a symmetric rim at a single level.

**D4 — Target background.** *(non-blocking, but determines what "correct" looks like)*
The rim was authored against a dark background and weakens badly on light. If the lantern will sit
on light or varied backgrounds, the alpha-96 side is effectively invisible there and the ladder
should be re-pitched upward.

---

## 7. Uncertainties carried forward

- The reference is schematic enough that it may be a synthetic style probe rather than shipped art.
  The rules in §2 are faithful to the file as given; if there is a richer source asset in the same
  style, it should supersede this derivation.
- No target engine has been named, so §5's engine criteria are stated but unverified.
- No representative sample exists yet; nothing here has been visually accepted as production style.
