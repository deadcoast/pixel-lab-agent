# Drone production approach — 16×16 separated-antenna drone

Status: **planning only.** No PX2 state was initialized or amended, no production art was
generated, and no provider was called. This document is the single deliverable.

## 1. What was actually inspected

| Input | How it was read |
| --- | --- |
| `small-separated.png` (sha256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`) | `pixl_asset_check`; exact RGBA grid dump; viewed natively and at 16× nearest-neighbour on a checker backdrop |
| `old-assessment.md` | Read in full; disposed of in §5 |
| `SESSION.md` | Read in full |

`inspection/small-separated-x16.png` is an integer-upscaled viewing aid produced this session,
not production art. It exists so the visual read below is an actual observation rather than an
inference from numbers.

## 2. Measured reference facts

All values below are measured, not estimated.

```
   0123456789012345          A = #25354A  frame/dark   64 px
 0 ................          B = #56B5BC  body fill    22 px
 1 ................          C = #F4DDA2  accent/eye    2 px
 2 .....AA..AA.....          . = alpha 0            168 px
 3 .....AA..AA.....
 4 ................          canvas        16 × 16
 5 ................          visible       88 px, 3 colors
 6 ...AAAAAAAAAA...          alpha values  {0, 255} only — no fractional edge
 7 ...AAAAAAAAAA...
 8 ...AABBBBBBAA...
 9 ...AABCBBCBAA...
10 ...AABBBBBBAA...
11 ...AABBBBBBAA...
12 ...AAAAAAAAAA...
13 ...AAAAAAAAAA...
14 ................
15 ................
```

- **Body block** `x3..12` × `y6..13` — 10 w × 8 h.
- **Frame thickness measured on all four sides: exactly 2.**
- **Interior** `x5..10` × `y8..11` — 6 × 4 = **24 cells**, of which 22 fill + 2 accent.
- **Antenna islands** 2×2 at `(5,2)` and `(9,2)`. Vertical gap to body = 2 rows (4, 5);
  horizontal gap between islands = 2 columns (7, 8).
- **Component count is 3 under *both* 4- and 8-connectivity.** The separation is not a
  connectivity-rule artifact; it survives either rule with a clear margin.
- **Eyes** at `(6,9)` and `(9,9)`. Each has a *complete 8-neighbour ring of body fill* — neither
  accent cell touches the frame, diagonally or orthogonally.
- **Centred both axes**: margins L/R 3/3, T/B 2/2.

Visual read at 16×: the two islands read unambiguously as a separated antenna pair; the thick
frame reads as a chassis bezel rather than an outline; the two accent cells read as eyes because
of the moat, not because of their shape.

## 3. Authority ledger

| Choice | Authority | Value |
| --- | --- | --- |
| 16×16 canvas | **Confirmed by user** | 16 × 16 |
| 2-px dark frame around the body | **Confirmed by user** | thickness 2, all sides |
| Two detached antenna islands | **Confirmed by user** | 2 islands, non-touching |
| Frame / fill / accent *roles* | Proposed (derived from reference) | 3 roles |
| Specific hexes `#25354A` / `#56B5BC` / `#F4DDA2` | **Unknown — user has not approved a palette** | measured from this reference only |
| Interior detail budget | Proposed | see §4, ≤ 6 of 24 cells |
| Engine import behaviour | Unknown — untested | — |

Nothing in the "proposed" or "unknown" rows is treated below as settled. §7 carries the one
decision that actually blocks further work.

## 4. The production template

At 16×16 with a 2-pixel frame, this aesthetic is **not a drawing, it is a cell-exact template**.
That framing is the core of the approach: the frame, the islands, and the centring consume fixed
coordinates, and everything a variant can express lives in 24 interior cells plus the antenna
silhouette.

**Fixed geometry (every drone in the family):**

```
body block      (3,6) size 10×8        frame ring   2 px, dark role
interior        (5,8) size  6×4        = 24 cells, fill role
antenna A       (5,2) size  2×2        antenna B    (9,2) size 2×2
island gap      ≥2 rows to body, ≥2 cols between islands
placement       centred: margins 3/3 horizontal, 2/2 vertical
alpha           binary only (0 or 255)
```

**Variation surface (what a new drone may change):**

1. The 24 interior cells — eye position/count, a mouth or vent row, a chest indicator.
2. Antenna island *shape*, within a 2×2..2×3 footprint that preserves the ≥2-cell gaps.
3. Accent colour per variant, if §7 resolves that way.

**Proposed interior budget: at most 6 of 24 interior cells may be non-fill (25%).** The reference
spends 2 (8%). This ceiling is a proposal, not a measured threshold — it exists so variants are
compared against a declared number instead of being argued case by case. Confirm or replace it.

**Proposed moat rule (derived from the reference, and the reason the face reads):** every accent
cell keeps a full 8-neighbour ring of fill. With a 6×4 interior this confines accents to the
4×2 sub-rectangle `x6..9` × `y9..10`. That is a hard consequence of the user's own frame
choice and is worth stating plainly: **the 2-px frame buys a chassis look and costs an 8-cell
usable face.** It is a real constraint, not a defect, and the reference already works within it.

## 5. Disposition of `old-assessment.md`

The prior assessment was written against a *different* 32-px robot and was never approved. Each
of its three proposals is measurably wrong for this drone:

| Prior proposal | Measured result on this drone | Disposition |
| --- | --- | --- |
| 32-px minimum whenever outlines are thick | A 2-px frame at 16 px leaves a working 6×4 interior; the eyes sit with a full 1-cell fill moat and **do not meet the contour** | **Reject.** The stated failure mode does not occur here. |
| One connected component for all sprites | Component count is 3 under both connectivity rules — and the detached islands are a user-confirmed aesthetic | **Reject.** Adopting it would delete a choice the user owns. |
| Lock all props to the observed three colors | The user has not approved any palette | **Do not adopt.** Not wrong in substance, but unapproved; it is §7's decision, not an inherited rule. |

The packaged sources agree that the first two are overreach. `semantic-clusters` records that
"a semantic cluster need not be a single-color connected component" and that "automatically
deleting every singleton destroys legitimate detail" — the two 1-px eyes are exactly the
protected singletons it describes, and `eye` is a named cluster semantic in
`PIXEL-ART-DEEP-RESEARCH.md:1402-1445`. `palette-contract` records that "a fixed small palette is
optional art direction, not a universal definition of pixel art." The `silhouette-readability`
proof fixture is itself a **16×16** form with a ring hole and two separated teeth, i.e. the
corpus treats separated landmarks at 16 px as workable.

Carry forward from the prior note only this: thick frames at small canvases do squeeze interiors.
That is handled explicitly by the §4 budget rather than by a blanket size floor.

## 6. Method, in order

**Spine — author deterministically from the template.** Emit the fixed geometry directly, then
paint the interior and antennas. This is the recommendation because the aesthetic is defined by
exact cell coordinates; no generator can be relied on to land a 2-px ring and two ≥2-cell gaps at
16×16. Verify with `pixl asset-check` plus the §6.1 invariants.

**Exploration branch — use the provider for ideas, never for deliverables.** `create_1_direction_object`
with `style_images: [small-separated.png]`, or `create_image_pixen` at 16×16, to propose interior
motifs and antenna silhouettes. Then *conform* mechanically: snap the frame, re-separate the
islands, quantize to the approved roles. **Named risk:** at 16×16 these tools typically return a
connected, antialiased, many-colour raster. `reduce_colors` and `correct_pixelart` exist but
neither guarantees a 2-px ring or island separation. Budget for the conform step, or skip the
branch entirely — the spine does not depend on it.

**Provider availability — blocked this session.** No PixelLab tools are present in this session;
only `pixl-local` is wired. The tool list I read is a *dated documentation inventory*
(`retrieved_at: 2026-09-11`, `live_discovery: false`), not live discovery, so the schemas above
must be re-discovered against the real harness before any `job-prepare`. **Missing capability:
a connected PixelLab MCP server with credentials.**

### 6.1 Acceptance criteria — declared now, before any candidate exists

*Mechanical* (scriptable; these are the §2 measurements turned into assertions):

- `I1` canvas exactly 16×16; alpha values ⊆ {0, 255}.
- `I2` exactly 3 opaque components under **both** 4- and 8-connectivity: two antenna islands and
  one body, no island touching the body.
- `I3` frame thickness exactly 2 on all four sides of the body block.
- `I4` interior exactly 6×4 = 24 cells.
- `I5` every accent cell has a full 8-neighbour ring of fill.
- `I6` centred: margins 3/3 horizontal, 2/2 vertical.
- `I7` interior non-fill cells ≤ 6 *(pending §4 confirmation)*.
- `I8` palette membership *(cannot be authored until §7 resolves)*.

*Visual* (host inspection, not inferable from the above): native scale plus integer upscale, on
light, dark and busy backgrounds; confirm the islands still read as antennas and the accents still
read as eyes. Mechanical passes do not supply this verdict.

*Engine*: **untested and currently unknown.** No import target has been named, so no engine
criterion can be written yet. It stays open rather than being quietly assumed to pass.

## 7. The decision I need from you

**Is the palette fixed, and at what scope?** Everything else in this approach is executable; this
is the only item that blocks work, and it blocks exactly one thing — criterion `I8`. I cannot
author a palette check without it, and I will not infer approval from the reference's contents.

- **(a) Fixed family palette** — all drones use `#25354A` / `#56B5BC` / `#F4DDA2`. Strongest
  consistency, no per-variant colour expression.
- **(b) Fixed roles, per-variant colours** *(my recommendation)* — the three *roles* (dark frame,
  body fill, accent) are locked and `I8` checks role count and transparency, while each drone may
  carry its own accent or fill hue. This preserves what makes the reference read — thick dark
  bezel, one fill, one high-value accent — without freezing hues you have not chosen.
- **(c) Open per asset** — structure is the only contract; `I8` is dropped.

Reply with (a), (b) or (c). If you also want to confirm or replace the §4 interior budget of
6 of 24 cells, that turns `I7` from proposed into confirmed; absent an answer I will hold it as
proposed and flag any variant that exceeds it rather than rejecting it.
