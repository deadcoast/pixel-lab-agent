# Drone approach — 16×16, 2px dark frame, two detached antenna islands

Scope: bounded planning only. No PX2 state was created or amended, no production art was
generated, and no provider was called. This document is the deliverable.

Reference inspected: `small-separated.png`
(sha256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`)

---

## 1. What the reference actually is

Measured with `pixl_asset_check` and a direct pixel read, then inspected visually at native
scale and at 24× on checker, dark and light backdrops
(`.scratch/ref-x24-checker.png`, `.scratch/ref-x24-darkbg.png`, `.scratch/ref-x24-lightbg.png` —
diagnostic views, not project assets).

```
   0123456789012345      A  #25354A  dark frame        64 px
 0 ................      B  #56B5BC  teal body         22 px
 1 ................      C  #F4DDA2  eye accent         2 px
 2 .....AA..AA.....         transparent              168 px
 3 .....AA..AA.....
 4 ................      canvas          16 × 16
 5 ................      visible pixels  88
 6 ...AAAAAAAAAA...      visible colors  3
 7 ...AAAAAAAAAA...      components      3 (4-connectivity)
 8 ...AABBBBBBAA...      fractional α    0 px
 9 ...AABCBBCBAA...      visible bbox    [3,2,13,14]
10 ...AABBBBBBAA...
11 ...AABBBBBBAA...
12 ...AAAAAAAAAA...
13 ...AAAAAAAAAA...
14 ................
15 ................
```

Structure: one body component (rows 6–13, cols 3–12) that is a 10×8 block whose outer
2-pixel ring is the dark frame, leaving a **6×4 = 24-pixel teal interior**; the reference
spends 2 of those 24 on eyes. Two 2×2 antenna islands sit at rows 2–3, cols 5–6 and 9–10,
separated from the body by 2 fully transparent rows (4–5) and from each other by 2 columns.
The antennae are the **frame color**, not teal.

Measured contrast (sRGB relative luminance, diagnostic only):
frame↔teal 5.18:1 · frame↔eye 9.31:1 · teal↔eye 1.80:1.

---

## 2. Authority table

Every restriction below is traced to its source. Only rows marked **Requirement** may reject
production output; **Observation** and **Proposal** rows may not.

| Property | Value | Status | Source | Scope |
|---|---|---|---|---|
| Canvas size | 16 × 16 | **Requirement** | User instruction, this session | All drone assets |
| Frame thickness | 2 px, surrounding the body | **Requirement** | User instruction | All drone assets |
| Frame tone | dark, separated from the body fill | **Requirement** | User instruction ("dark frame") | All drone assets |
| Body fill | teal | **Requirement** | User instruction | All drone assets |
| Antenna islands | ≥ 2, each detached from the body and from each other | **Requirement** | User instruction | All drone assets |
| Fixed palette | none imposed | **Requirement (negative)** | User: "I have not approved a fixed palette" | All drone assets |
| Frame color `#25354A` | exact RGB | Observation | Reference pixels | Reference only |
| Body teal `#56B5BC` | exact RGB | Observation | Reference pixels | Reference only |
| Eye accent `#F4DDA2`, 2 px | exact RGB and count | Observation | Reference pixels | Reference only |
| Body footprint 10 × 8 | interior becomes 6 × 4 = 24 px | Observation | Reference pixels | Reference only — **see §5** |
| Visible bbox `[3,2,13,14]` | 3 px side margins | Observation | Reference pixels | Reference only |
| Antenna size 2×2, cols 5–6 / 9–10 | exact geometry | Observation | Reference pixels | Reference only |
| Gap between antennae and body | 2 transparent rows | Observation | Reference pixels | Reference only |
| Component count | exactly 3 | Observation | `pixl_asset_check` | Reference only |
| Visible colors | exactly 3 | Observation | `pixl_asset_check` | Reference only |
| Binary alpha (only 0 / 255) | 0 fractional-α px | Observation → **Proposal** for production | `pixl_asset_check`; no user instruction | Would need adoption (§4) |
| Antennae readable on dark backgrounds | frame↔`#1A1C22` = 1.37:1 | Observation, one backdrop, one color pair | Diagnostic composite | Not a rule |

### Why the derived rules stop where they do

Each candidate rule was tested against a variation that still satisfies the brief:

- A drone with 1×3 antennae at different columns still satisfies the brief → antenna
  geometry and gap depth are **observations**, not checks.
- A drone with an additional intentional detached detail (exhaust spark, status light) still
  satisfies "two detached antenna islands" → component count is **≥ 3, flag extras for
  review**, never `== 3`.
- A drone in a different teal with a near-black frame still satisfies the brief, and the user
  has not approved a palette → production checks **omit exact palette membership**.
- A larger body block still satisfies "a 2-pixel dark frame around the teal body" → the 6×4
  interior follows from the reference's 10×8 footprint, not from the brief.
- The brief requests neither antialiasing nor partial transparency, but it does not forbid
  them → binary alpha is a proposal awaiting adoption, not an entailed requirement.

---

## 3. Disposition of `old-assessment.md`

Unapproved, written by an earlier agent about a **different robot**, from a nearest-neighbor
downscale of a 32-pixel source with an **inset** border whose eyes met the contour. None of its
three proposals survive contact with this brief or this reference:

| Prior proposal | Disposition |
|---|---|
| Universal 32-px minimum for thick outlines | **Rejected.** Contradicts the user's chosen 16×16, and this reference demonstrates a legible 2-px frame at 16 px with a detached-island silhouette. The original finding remains valid only for that resized fixture, that inset-border construction and that robot. |
| One connected component for all sprites | **Rejected.** Directly contradicts the required two detached antenna islands. |
| Lock all props to the observed three colors | **Rejected.** The user has not approved a fixed palette. Retained only as the optional experiment in §4. |

What *is* worth carrying forward is the underlying mechanic, re-measured on this drone rather
than inherited: a 2-pixel frame is expensive at 16 px. On the reference's 10×8 body it leaves
24 interior pixels for all face and detail content. That is a real budget constraint for
prompts and review — see §5.

---

## 4. Production plan

### 4.1 Representative sample first

Generate and review **one** drone before any batch. The consequential uncertainty is not the
canvas or the palette; it is whether a generator will reliably produce (a) an exactly 2-pixel
uniform ring and (b) genuinely detached islands with clean transparent separation, at 16 px.
Generative output at this size commonly fuses islands to the body or leaves stray 1-px
speckle. Treat that as an **untested expectation about this provider**, not an established
limitation.

### 4.2 Prompt intent (carries every requirement explicitly)

> 16×16 pixel-art drone, front view, transparent background. Rectangular body with a solid
> teal fill enclosed by a uniform dark outline exactly 2 pixels thick on all four sides. Two
> small antenna blocks floating above the body, in the dark outline color, fully detached —
> a clear band of transparent pixels between each antenna and the body, and between the two
> antennae. Hard pixel edges, no antialiasing, no gradient, no drop shadow.

Deliberately **not** in the prompt: hex values, antenna dimensions, body footprint, eye
treatment. Those are unresolved or reference-only; fixing them in the prompt would smuggle
observations into the contract.

### 4.3 Mechanical checks (candidate rejects only on these)

Run via `pixl_asset_check` plus a small geometry pass:

1. `width == 16 && height == 16`.
2. Body component: exactly one component contains the teal fill; its outer ring is a single
   dark color and is exactly 2 px thick on all four sides (no 1-px or 3-px run).
3. Frame tone: frame relative luminance < body-fill luminance. Report the measured ratio;
   do **not** gate on a fixed threshold — no contrast number proves aesthetic quality.
4. Body fill reads as teal (hue band check, not exact RGB).
5. `opaque_components >= 3`, with ≥ 2 components sitting above the body and touching neither
   the body nor each other under 4-connectivity. Components beyond three are **flagged for
   visual review, not failed**.
6. No stray isolated pixels that are not an intended labelled feature — resolved by review
   using the semantic-cluster rule, since a legitimate detail can be a legal singleton.

Explicitly **absent**: exact palette membership, exact color count, exact component count,
bbox/margin equality, antenna coordinates, gap depth.

### 4.4 Visual review (separate, cannot be satisfied mechanically)

Inspect the actual candidate at native scale and enlarged, against light, dark and busy
backdrops: frame reads as a deliberate thick border rather than a blob; the two antennae read
as antennae and stay visibly separate; the interior still reads as a body, not as leftover
space. A passing checker is not this review.

### 4.5 Engine check

Currently **unavailable** — no target project is specified in this evaluation. Record as
unavailable, not as pass and not as artistic failure.

### 4.6 Optional labelled experiments (not gates)

- **E1 — Palette:** trial a 3–5 entry palette derived from the reference tones against a
  free-color candidate; compare readability. Adoption is the user's call.
- **E2 — Binary alpha:** confirm the candidate uses only α 0/255. Promote to a requirement
  only if an actual atlas or engine destination needs it.
- **E3 — Dark-background legibility:** if drones will sit on dark scenes, trial a lighter or
  outlined antenna treatment; the reference's dark antennae measured 1.37:1 against
  `#1A1C22` and visibly fade there.

### 4.7 Fallback

If a given generation attempt fuses the islands or misses the 2-px ring, author the sprite
deterministically at 16×16 — the structure is a rectangle ring plus two blocks, fully
specifiable in code. That addresses **that attempt**; it does not establish that the provider
cannot do it, and does not justify abandoning generation for the family.

### 4.8 Provider status

No PixelLab tool is connected in this session; the available `pixl-local` tools are all local
and none submits, polls or generates. Executing §4.1 needs a connected PixelLab MCP server
with credentials. Everything above is complete and useful without it.

---

## 5. Open decision

The reference's 10×8 body is an observation, not a requirement, and it drives the whole
detail budget. Two directions both satisfy the brief:

- **A — match the reference footprint (10×8):** 24 interior pixels, ~2 for a face. Silhouette
  matches the supplied reference most closely; almost no room for variants.
- **B — grow the body toward the canvas (e.g. 12×10, keeping the 2-px frame and the detached
  antennae):** 48 interior pixels, enough for eyes plus a light, vent or panel line across a
  family. Reads as a chunkier drone.

I default to **A** for the single representative sample, since it is closest to the supplied
reference, and would revisit if the family needs interior variation.
