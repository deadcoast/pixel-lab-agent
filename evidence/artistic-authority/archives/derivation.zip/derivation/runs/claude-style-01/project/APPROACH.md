# Production approach — matching lantern prop

Scope: planning only. No PX2 state was initialized or amended, no art was generated, and no
provider was contacted. Everything below is either a measurement of the supplied input, a stated
user requirement, or a labeled proposal awaiting confirmation.

## 1. Inputs inspected

| Input | Identity | How it was inspected |
| --- | --- | --- |
| `translucent-reference.png` | sha256 `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132` | `pixl_asset_check` (full alpha), exact per-pixel dump, host viewing at native and 16× integer-nearest scale, host viewing of a 4-background composite sheet |
| `SESSION.md` | project constraints | read |

Inspection views generated locally for actual host viewing (not production art):
`view-nearest-16x.png` (16× integer nearest), `view-backgrounds.png` (8× nearest, composited over
white / black / mid-grey / busy green-teal).

## 2. Authority table

Requirement = binding for this work. Observation = measured from the one supplied file.
Proposal = my suggestion, not yet authorized. Interpretation = my reading, could be wrong.

| Property | Value | Status | Source | Scope |
| --- | --- | --- | --- | --- |
| Treatment to preserve | intentional partial transparency + selective anti-aliasing | **Requirement** | user brief, this session | all new props |
| Subject | a small lantern prop matching the reference | **Requirement** | user brief | this task |
| Palette | none imposed | **Requirement** (constrains checks) | user brief, "I have not imposed a fixed palette" | this task |
| Deliverable | `APPROACH.md` only; no PX2 write, no art, no provider call | **Requirement** | user brief | this task |
| Canvas | 32 × 32, single frame | Observation | reference measurement | reference only |
| Occupied bbox | x 6–25, y 3–27 (20 w × 25 h), 420 visible px | Observation | reference measurement | reference only |
| Opaque colors | `#25354A` navy 180 px, `#56B5BC` teal 186 px, `#F4DDA2` pale gold 24 px | Observation | reference measurement | reference only |
| Alpha levels present | exactly `{0, 96, 160, 255}` — four levels, no others | Observation | reference measurement | reference only |
| Fractional-alpha pixels | 30 total, all `#56B5BC` | Observation | reference measurement | reference only |
| Fractional placement | two 1-px vertical columns: x=6 at α96 (15 px), x=25 at α160 (15 px), rows 11–25 only | Observation | reference measurement | reference only |
| Fractional RGB vs opaque RGB | identical (`86,181,188` at both α96 and α255) | Observation | reference measurement | reference only |
| Alpha model | consistent with **straight** (non-premultiplied) alpha | Observation | identical RGB across alpha levels | reference only |
| Curved / diagonal edges | **zero** — silhouette is entirely axis-aligned rectangles | Observation | reference measurement | reference only |
| Internal boundaries | all hard; no soft pixels at frame↔glass or glass↔gold | Observation | reference measurement | reference only |
| Connected components | 1 (4-connectivity, nonzero alpha) | Observation | `pixl_asset_check` | reference only |
| Soft band = outward glass bleed, not silhouette AA | uses the *interior* color extended past the frame, not a frame↔background blend | **Interpretation** | my reading of the measurement | — |
| α96 left / α160 right asymmetry = directional light | — | **Interpretation** | my reading; no lighting convention was supplied | — |
| Reference subject reads as a case/bag with two lit windows, not obviously a lantern | — | **Interpretation**, reported uncertainty | host viewing | see §6 |
| Reuse the reference's exact alpha values `{96, 160}` | tightens visual match | **Proposal** | — | sample only |
| Reuse the reference's three RGB values | — | **Proposal** (optional experiment; no palette was imposed) | — | sample only |

## 3. The decision that blocks nothing else but must be made

**The reference cannot tell us the anti-aliasing policy for curves, because it contains no curved
or diagonal edges at all.** Every boundary in it is axis-aligned. The only thing in the file that
can be what the brief calls "selective anti-aliasing" is the two 1-px translucent teal columns.

A lantern normally has curves a rectangular case does not — a domed or peaked cap, a ring handle,
a rounded glass belly. So the treatment has to be *extended*, and there are two defensible
extensions:

- **Policy A — literal.** Soft alpha is reserved exclusively for the outward glass bleed band.
  Curved contours stay hard stair-steps, no intermediate pixels anywhere. This is exactly what the
  reference exhibits — but it means the prop contains no anti-aliasing in the usual sense, which
  sits awkwardly against your own description of the treatment.
- **Policy B — by intent.** Same outward bleed band, **plus** authored contour AA applied only to
  the curved cap and handle, drawn from the authored color set and using the same declared alpha
  levels. Hard edges elsewhere (the frame, the base, all internal boundaries) stay protected.

**Recommendation: Policy B, proven by a labeled A/B on the single representative sample before any
batch.** Two variants of the same lantern, identical except for the cap/handle contour treatment,
viewed side by side at native scale. Policy A is the fallback if B reads as blurry at native size.

This is a genuine gap in the evidence, not a style preference — I am not treating either policy as
established. If you would rather not run the A/B, tell me which policy to adopt and I will carry it
straight into the sample.

## 4. Representative sample plan

One lantern, then nothing else until it is accepted.

- **Canvas:** 32 × 32, single frame — shared with the reference so the props align as a set.
  *Assumption:* "small" refers to the subject, not the canvas. Planned occupancy roughly 14 × 22,
  visibly smaller than the reference's 20 × 25 footprint. Say the word if you want a smaller
  canvas (24 × 24 / 16 × 16) instead; it changes the sample but not the treatment.
- **Form:** vertical lantern — cap, a ring or loop handle above it, a glass body panel held in a
  navy frame, a foot. The glass body is the element that carries the translucency, mirroring how
  the reference's glass is the element that bleeds outward.
- **Material language:** dark frame / bright translucent glass / small warm emissive accent,
  matching the reference's three-material read. Exact hues are a proposal, not a constraint.
- **Alpha contract for the sample (declared, then checked against itself):** straight
  non-premultiplied RGBA; allowed alpha set `{0, 96, 160, 255}`; fractional pixels take their RGB
  from the authored glass color, never from a background-specific blend.
- **Soft-band mask (declared before authoring):** a 1-px outward band along the glass body's
  vertical extents only, carrying the reference's stronger-on-one-side asymmetry (α160 on the lit
  side, α96 on the shadow side). Under Policy B, the cap/handle contour mask is added as a second,
  separately named region so the two uses of alpha stay auditable.
- **Backgrounds for review:** white, black, mid-grey, busy — the same four the reference was
  checked on.

## 5. Review criteria — recorded before evaluation

### Rejection rules (traceable to the user brief and the preserved treatment)

1. At least one fractional-alpha region (0 < α < 255) is present and intentional.
2. Alpha values fall only in the sample's declared set; flat quantized levels, no gradient ramp and
   no dithered translucency.
3. The transparency is *selective*: fractional pixels stay inside the declared masks, form no
   universal soft outline around the whole silhouette, and do not appear inside opaque interior fills.
4. Straight alpha; fractional RGB comes from the authored color set, not from a blend with any one
   background.
5. Protected hard edges — frame, base, and all internal material boundaries — contain no
   intermediate pixels.
6. Viewed at native scale on all four declared backgrounds, the soft band reads as intentional
   rather than as a halo artifact or as dirt.
7. The subject reads as a lantern and as a member of the same set as the reference. *Visual
   judgement, made by looking; no measurement substitutes for it.*

### Explicitly **not** rejection rules

These are true of the reference but do not follow from the brief, and a lantern that still honors
the treatment could legitimately violate each one:

- exact palette membership — you imposed no palette, so no exact-palette check runs;
- the exact alpha values 96 and 160 (the check is conformance to the sample's *declared* set);
- component count of 1 — a detached ring handle, a detached spark or a hanging hook is permitted;
- the reference's 30 fractional pixels, its bbox, its 20 × 25 footprint, its exact row span 11–25;
- the band being exactly 1 px wide, or the stronger side being the right side;
- a three-color limit.

## 6. Uncertainties and untested expectations

- **Subject identification.** At native and 16× scale the reference reads to me as a case or bag
  with two lit windows rather than a lantern. I have kept your "lantern" designation and treated
  the *treatment* as the thing to match. If the reference is meant to be a lantern, the new prop
  should probably echo its silhouette more closely than my §4 form does — say so and I will revise.
- **Background robustness is measured, not guaranteed.** Composited, the α96 band lands at
  `(191,227,230)` on white and `(32,68,71)` on black; the α160 band at `(149,209,213)` and
  `(54,114,118)`. Both survive all four backgrounds, but the band's character changes from pale
  mint halo on white to faint glow on black, and the α160 side is consistently the more visible.
  This is a diagnostic result for these four backgrounds only; it says nothing about backgrounds
  not tested, and it does not establish that the same band will read well on a differently shaped prop.
- **No provider work was done.** No PixelLab tool discovery, submission or capability check was
  performed, per the task bounds. Whether a generator can hit this treatment directly is an
  untested expectation; hand-authoring or post-authoring the alpha band is the reliable path and I
  would plan on it rather than assume a provider returns correct selective alpha.
- **Lighting intent is inferred.** The left/right alpha asymmetry is my reading as directional
  light. No lighting convention was supplied for the prop set. If one exists, it should be stated
  before the sample, since it determines which side of the lantern carries α160.
- **Provenance.** The reference is a supplied input with no accompanying reuse or license
  statement. The plan authors an original lantern from the functional brief and reuses only the
  measured *treatment*, not reference pixels — which keeps it clear of an unresolved reuse basis if
  these props are ever distributed.

## 7. Sequence

1. Confirm the §3 AA policy (or authorize the A/B).
2. Author the single lantern sample, with the alpha contract and masks declared first.
3. Measure it, then actually view it at native scale on the four backgrounds.
4. Record an explicit pass/fail per §5 criterion, keeping mechanical results and visual judgement separate.
5. Only after the sample is accepted, extend to the rest of the prop set as a family against the
   accepted baseline.
