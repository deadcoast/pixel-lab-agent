The supplied drone is a workable starting point for the requested 16×16 aesthetic. Preserve the thick two-pixel dark frame around its teal body and its two detached antenna islands. The reference already accommodates those features with room for two distinct eye details. Develop the next sample directly at 16×16; the earlier assessment supplies no basis for replacing these choices with a 32-pixel minimum, connected antennas, or a fixed palette.

This is the Markdown planning deliverable for 2026-09-14. Review used the packaged PIXL skill, local read-only PIXL measurements and research, and direct image inspection. No PX2 state was initialized or amended, production art created, or provider called. Future sample work below is proposed, not executed or accepted.

The following authority table governs the whole approach, including its proposed art instructions and checks.

| Property / value | Authority and status | Exact source | Applicable scope |
| --- | --- | --- | --- |
| Canvas: 16×16 | User requirement | Current brief: “a 16 by 16 canvas” and “Keep those choices.” | Matching drone and its proposed sample; no larger minimum. |
| Two-pixel dark frame around teal body | User requirement | Current brief: “a thick two-pixel dark frame around the teal body” | Body frame; does not impose a two-pixel outline on every detail. |
| Two detached antenna islands | User requirement | Current brief: “two detached antenna islands” | Preserve two identifiable antennas separated from the body and each other. Does not fix total sprite component count or gap coordinates. |
| Palette remains open | User statement; no approved fixed palette | Current brief: “I have not approved a fixed palette.” | No exact color-membership or maximum-color-count rejection rule. Dark frame and teal body still apply. |
| Three visible colors, binary alpha, three visible components | Measured observations | `small-separated.png`; local `pixl_asset_check` and pixel readback below | Describe this reference only. No automatic production restrictions follow. |
| Rectangular body, exact positions, two pale eye pixels, flat fills | Observations; proposed starting layout | Native and enlarged inspection of `small-separated.png`; coordinates below | First sample recipe, open to deliberate matching variations; not immutable coordinates, eye count, or lighting rules. |
| Semantic feature review and native-scale comparison | Agent proposal informed by PIXL methods | `semantic-clusters` and `silhouette-readability`; source evidence below | Diagnostic method for the next sample. No numeric metric supplies artistic approval. |
| Old 32-pixel minimum, single-component rule, three-color lock | Earlier agent proposals; unapproved | `old-assessment.md`, paragraph 1; current brief explicitly disclaims user approval | Historical evidence only; excluded from this approach's requirements. |
| Markdown approach only | User requirement | Current brief: “do not initialize or amend PX2 state, create production art, or call a provider” | This session ends with this document; no production acceptance is needed. |

Inspection of the original native image and an in-memory 16× nearest-neighbor enlargement shows a compact, front-facing rectangular face/body with two pale eye marks and two floating dark antenna blocks. The enlargement was a viewing aid and was not saved as an asset. The visually inspected transparency was shown against the host viewer background; actual game backgrounds and display scaling remain untested.

Local `pixl_asset_check(path="small-separated.png", width=16, height=16)` passed the requested dimensions. It reported one frame, 88 visible pixels, three visible colors, no fractional-alpha pixels, and three components using four-neighbor connectivity over nonzero alpha. No palette or binary-alpha restriction was supplied. The tool explicitly leaves visual quality and engine import unverified.

Pixel readback gives the following concrete construction, using zero-based inclusive coordinates:

| Reference feature | Measured layout |
| --- | --- |
| Body including frame | x=3–12, y=6–13: 10×8 pixels. |
| Dark frame | Two pixels on each side of that rectangle, 56 frame pixels. A direct coordinate audit confirmed the full ring. |
| Face interior | x=5–10, y=8–11: 6×4 pixels, comprising 22 teal pixels and two pale pixels. |
| Eye marks | (6,9) and (9,9). All four immediate orthogonal neighbors of each are teal; neither eye meets the frame. |
| Antennas | Two 2×2 dark blocks at x=5–6 and x=9–10, both y=2–3. Rows 4–5 are transparent between antennas and body. |
| Observed colors | Dark `#25354A` (64 pixels including antennas), teal `#56B5BC` (22), pale `#F4DDA2` (2); 168 transparent pixels. These are swatches, not an approved palette. |

The thick frame occupies 56 of the body's 80 pixels, but the remaining 24 pixels still carry separated facial details. This directly answers the old concern for this reference geometry. It does not prove that every 16×16 drone shape will work. The old note describes a different robot reduced from 32 pixels by nearest-neighbor, whose eyes met its inset border; the underlying robot, diagnostic, background and engine evidence were not supplied for independent review. Its reported failure is bounded to that attempt. It establishes neither a universal minimum size nor any provider limitation.

For the next authorized production session, the proposed approach is:

1. Author one static drone sample on the native 16×16 grid. Use the measured 10×8 body and 6×4 face as a practical first layout. Keep the two-pixel dark frame around the teal body and two detached antenna islands explicitly in the art instructions. Avoid introducing a downsampling step as the way to fit this design.
2. Start with the reference's simple face, rectangular mass and sparse detailing. The two pale eye marks, two 2×2 antenna blocks and current positions are a proposed baseline. If a new expression or silhouette feels cramped, revise interior detail or body proportions within 16×16 while retaining the two-pixel frame and detached antennas. Exact gap rows and coordinates can change.
3. Use the observed dark/teal/pale color relationship as a starting suggestion. Exact hex values and color count remain open. An optional color comparison can vary the teal or eye accent, or add a useful shade; it is not a prerequisite. Start with the observed flat fills and transparent surroundings as proposals. No directional lighting, material response, or universal alpha/anti-aliasing policy is inferred from them.
4. Identify semantic regions for body frame, face, left antenna, right antenna and any proposed eye/detail features before evaluating the sample. Inspect component measurements alongside these regions. Preserve intentional islands and singleton details; a component count alone cannot distinguish an antenna from unwanted noise.
5. Compare the resulting sample with the reference at native scale and integer nearest-neighbor zoom. Review the colored face as well as silhouette/negative space. When available, also view it on the intended game background. Light, dark or busy diagnostic backdrops can expose issues, but results apply to the backdrops actually tested.

The smallest future proof asks: does the newly authored sample retain the requested frame and detached antennas while preserving the reference's compact drone identity at 16×16? Its artifact is one sample plus native/enlarged comparison views. Record measurements, visual observations and revisions separately. The following checks are declared now, before any candidate exists:

| Check | Evidence and consequence |
| --- | --- |
| 16×16 canvas | Mechanical dimension check; a different canvas fails the user requirement. |
| Thick two-pixel dark frame around teal body | Pixel-level inspection of the body frame plus colored visual review. Thinning the frame or losing the teal body requires revising that candidate. |
| Two detached antenna islands | Identify both antenna regions and inspect their separation from each other and the body. Merging or deleting an antenna fails the requirement. Count all components only as a diagnostic. |
| Reference match | Visual comparison of compact body proportions, frame weight, face readability and antenna identity. This is a qualitative review of the requested match, not a guaranteed result from matching coordinates. |
| Proposed facial treatment | For the initial two-eye experiment, inspect whether both marks remain distinguishable from the frame and one another. The reference's exact eye coordinates and teal clearance are observations, not universal rejection thresholds. |
| Colors, alpha and backgrounds | Report measured colors/alpha and actual viewing conditions. Omit exact palette membership, a three-color cap, and a binary-alpha gate. Background readability or engine behavior stays unverified wherever it was not inspected. |

A failed sample warrants revising that sample's spacing, detail or construction while preserving the user's aesthetic. It cannot establish general provider inability. Provider capability and reliability have not been tested here. If a future generated attempt needs correction, local pixel editing is a possible remedy for that attempt; no provider is required to make this plan useful.

The restrictions were also checked against brief-compliant variations: moving an antenna while keeping it detached, adding an intentional detached spark, changing the teal shade, or using another eye arrangement would change reference measurements without necessarily violating the brief. Accordingly, this approach does not enforce exactly three total components, two specific empty rows, reference coordinates, three exact colors, or the observed eye arrangement. Such variations would still receive visual matching review.

PIXL research selected `semantic-clusters` for protecting intentional antennas and facial details, and `silhouette-readability` for reviewing identity at the intended scale. Complete compiled context packets were retrieved for both methods from `.agents/skills/pixl-kit/resources/knowledge/library.px`. Installed source identities were verified and the following exact cited text was read. Paths in this table are relative to `.agents/skills/pixl-kit/resources/`.

| Source and inclusive lines | What transfers to this plan |
| --- | --- |
| `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md`, 1402–1445 | Names connected or semantically related clusters and features such as outline, eye and highlight; supports feature-aware review rather than indiscriminate cleanup. |
| Same source, 857–867 | Its constraints are conditional: isolated noise “not intentionally permitted,” an “approved ramp,” and an edge “that should remain hard.” Intentional antennas are not automatically noise, and this project has no approved fixed ramp. Temporal conditions do not apply to this static plan. |
| Same source, 1563–1573 | Separates silhouette, shading, detail and effects in animation analysis. Useful semantic distinction; the animation-specific diagnostic is not evidence for this still drone. |
| `training/original-docs/PIXEL-ART-ASSETS.md`, 11–15 | A different project's UI note about relevant size, clarity and cohesion. It supplies context for the method, not this project's style authority or drone approval. |

The semantic method requires a declared connectivity rule and semantic masks. Four-neighbor connectivity was used for the reference's occupancy measurement; that measurement is not same-color cluster analysis. Candidate-specific semantic masks remain future work. The silhouette method's identity landmarks are available from this brief/reference, while actual display scale and representative game backgrounds remain unresolved. These are researched candidate methods with partial applicability, not adopted production proofs.

The bundled receipt `evidence/art-methods/poc-report.json` reports passing offline `cluster-connectivity` and `key-silhouette-landmarks` fixtures. The first establishes different four/eight-neighbor component results on a toy pattern; the second checks a key's geometric landmarks against a damaged version. Their stated limits explicitly exclude semantic importance, visual recognition, background readability and final artistic acceptance. Those fixtures were read, not rerun; neither proves this drone's production quality. This session's direct reference audit establishes only the reference facts recorded above.

For reproducibility, the inspected SHA-256 identities are:

| File | SHA-256 |
| --- | --- |
| `small-separated.png` | `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c` |
| `old-assessment.md` | `4f7db791ae8d97869b169c76bcfce93c6101e5497b1b682d649730a695e70521` |
| `PIXEL-ART-DEEP-RESEARCH.md` | `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28` |
| `PIXEL-ART-ASSETS.md` | `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900` |
| `poc-report.json` | `a3b77eae4ab97843829efab67b8773086498d67d91672350520194059f586d81` |

No further aesthetic decision is necessary to use this approach, and a fixed palette need not be chosen. If the user later requests production, the next useful operation is the single native 16×16 sample described above. The intended background and display scale would then improve placement review. This bounded planning evaluation is complete without a new sample, provider result, engine test or production acceptance.
