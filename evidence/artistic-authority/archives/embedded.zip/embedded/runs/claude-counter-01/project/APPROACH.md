# Drone production approach — matching `small-separated.png`

Bounded planning deliverable. No PX2 state was created or amended, no art was generated, and no
provider was called. Every restriction below is traceable to the authority table in §2.

Reference inspected: `small-separated.png`
sha256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`

---

## 1. The question this approach answers

How to produce further drone assets that match the supplied reference, given that the project owner
has fixed three aesthetic choices (16×16 canvas, two-pixel dark frame, two detached antenna islands)
and has deliberately **not** approved a palette.

---

## 2. Authority table

Every enforced restriction in this document appears here. Status is either **requirement** (owner
instruction or adopted project choice — may become a rejection rule), **observation** (measured from
the reference — describes what is, adopts nothing), or **proposal** (mine — defines a labeled trial,
never a rejection rule).

| Property / value | Status | Exact source | Applies to |
| --- | --- | --- | --- |
| Canvas 16 × 16 | **Requirement** | Owner instruction, this session: "chosen aesthetic is a 16 by 16 canvas… Keep those choices." | All drone assets |
| Dark frame two pixels thick around the teal body | **Requirement** | Owner instruction, this session | All drone assets |
| Two detached antenna islands | **Requirement** | Owner instruction, this session | All drone assets |
| Palette (which colors, how many) | **Unresolved** | Owner instruction, this session: "I have not approved a fixed palette." | Blocks any palette rejection rule |
| Colors `#25354A` ×64, `#56B5BC` ×22, `#F4DDA2` ×2 | Observation | Pixel measurement of the reference | The reference file only |
| 88 visible pixels; 3 visible colors | Observation | `pixl_asset_check` on the reference | The reference file only |
| Alpha levels exactly {0, 255}; 0 fractional-alpha pixels; transparent RGB is (0,0,0) | Observation | `pixl_asset_check` + pixel measurement | The reference file only |
| 3 opaque components under 4-connectivity | Observation | `pixl_asset_check` (`opaque_components: 3`) | The reference file only |
| Visible bbox x 3–12, y 2–13 | Observation | `pixl_asset_check` (`visible_bbox [3,2,13,14]`) | The reference file only |
| Body rect 10 w × 8 h at x 3–12, y 6–13 | Observation | Pixel measurement | The reference file only |
| Interior 6 w × 4 h at x 5–10, y 8–11 (24 px) | Observation | Derived from body rect minus the 2 px frame | The reference file only |
| Eyes: 1×1 cream at (6,9) and (9,9) | Observation | Pixel measurement | The reference file only |
| Eye clearance from the frame ≥ 1 interior pixel on all four sides | Observation | Pixel measurement | The reference file only |
| Antennas: two 2×2 blocks at x 5–6 and x 9–10, y 2–3 | Observation | Pixel measurement | The reference file only |
| Island gap: 2 fully transparent rows (y 4–5); 2 transparent columns between islands (x 7–8) | Observation | Pixel measurement | The reference file only |
| Antenna span (x 5–10) equals the interior span (x 5–10) | Observation | Pixel measurement | The reference file only |
| Contrast (sRGB relative luminance): frame↔teal 5.18; teal↔eye 1.80; frame↔`#ECECE8` 10.51; frame↔`#18181C` 1.42 | Observation, diagnostic only | Computed this session on the reference colors, against the three backgrounds I rendered | Those exact color pairs and backgrounds; **not** an acceptance threshold |
| Structural template in §5 (10×8 body, 2×2 antennas, 2-row gap, ≥1 px interior clearance) | **Proposal** | Mine, generalized from the observations above | A labeled trial only, until the owner adopts it |
| Any statement in `old-assessment.md` | **Not adopted** | See §4 | Nothing |

---

## 3. What the reference actually contains

```
    0123456789012345
 0  ................      .  transparent (0,0,0,0)
 1  ................      #  #25354A  dark frame / antennas   64 px
 2  .....##..##.....      +  #56B5BC  teal body interior      22 px
 3  .....##..##.....      o  #F4DDA2  cream eyes               2 px
 4  ................
 5  ................      body    x 3–12, y 6–13   (10 × 8 = 80 px)
 6  ...##########...      frame   2 px on all four sides (56 px)
 7  ...##########...      interior x 5–10, y 8–11  (6 × 4 = 24 px)
 8  ...##++++++##...      islands two 2×2 blocks, 2 empty rows below
 9  ...##+o++o+##...
10  ...##++++++##...      margins 3 cols left/right, 2 rows top/bottom
11  ...##++++++##...
12  ...##########...
13  ...##########...
14  ................
15  ................
```

Three structural facts drive the whole approach:

1. **The interior budget is 24 pixels.** The 2-px frame consumes 56 of the body's 80 pixels. Two eyes
   leave 22 interior pixels for everything else. Feature complexity has to be planned up front; it
   cannot be discovered during generation.
2. **The islands are positioned, not floating.** They span exactly the interior column range (x 5–10),
   and each sits above an eye column. The 2-row gap is what makes them read as *detached* rather than
   as a broken outline.
3. **The eyes do not touch the frame.** Every eye pixel keeps at least one teal pixel between itself
   and the dark ring. That clearance is what keeps the face readable at this size.

### Visual inspection actually performed

I rendered and viewed the sprite enlarged 32× on a checker background, and a contact sheet (colored
and silhouette-mask, on light `#ECECE8`, dark `#18181C`, and a busy two-tone ground) enlarged 12×.
Retained as `view-x32-checker.png`, `view-x32-alpha.png`, `view-contact-sheet.png`,
`view-contact-native.png`.

What I saw:

- On light and busy backgrounds the frame, interior, both eyes and both islands all read as distinct
  landmarks, and the gap between islands and body is unambiguous.
- On the dark background the dark frame separates only weakly from the ground (diagnostic contrast
  1.42), and the antenna islands — which are pure frame color with no interior — are the first thing
  to soften. They remain visible but the silhouette edge is indistinct.

**Stated limit on this inspection:** I viewed enlarged renders, not the sprite at native 16×16 on the
real destination background, and I do not know what that background is. The dark-background result is
a diagnostic on the one background I invented, not a verdict on the art. `silhouette-readability`
is explicit that no contrast ratio or component count proves aesthetic quality.

---

## 4. Status of `old-assessment.md`

That file was written by an earlier agent about a *different* robot, whose 16-px version came from
nearest-neighbor downscaling a 32-px source. It records no owner adoption, no measurement on this
drone, and no engine test. Its three proposals are adjudicated as follows.

| Earlier proposal | Disposition | Why |
| --- | --- | --- |
| Universal 32-px minimum canvas for thick outlines | **Rejected as a project rule** | The owner has fixed 16×16 as a requirement. Independently, the premise does not transfer: this drone is authored natively at 16×16, its 2-px frame leaves a 6×4 interior, and its eyes keep ≥1 px clearance from the contour — the exact failure the earlier diagnostic reported does not occur here. A resampled fixture's failure is attached to its own artifact, method and scale. |
| One connected component for all sprites | **Rejected as a project rule** | It directly contradicts a standing owner requirement (two detached antenna islands). `semantic-clusters` also warns that a semantic cluster need not be a single-color connected component and that automatically deleting every singleton destroys legitimate detail; the cited rejection rule is "isolated 1-pixel noise **not intentionally permitted**", and these islands are intentionally permitted. The measured count of 3 is an observation that *matches* the requirement. |
| Lock all props to the observed three colors | **Not adopted** | The owner has explicitly not approved a palette, so there is nothing to enforce. `palette-contract` lists "an approved RGBA palette, color-space choice and transparency policy" as a prerequisite — that prerequisite is unmet — and notes that a fixed small palette is optional art direction, not a universal definition of pixel art. The three colors stay recorded as an observation of the reference. |

Nothing from that file is carried into §5 or §6. The file itself is preserved unchanged.

---

## 5. Production approach

### 5.1 Methods selected (source-grounded)

Retrieved from the installed corpus (`files_verified: true`), with text inspected at the cited ranges.

| Method | Use here | Citation inspected |
| --- | --- | --- |
| `semantic-clusters` | Treat the eyes and each antenna island as protected semantic clusters, so no cleanup, crop or de-noise pass can dissolve them. Connectivity count stays a measurement. | `PIXEL-ART-DEEP-RESEARCH.md` sha `7efc4789…f725e28`, lines 1402–1445 and 857–867 |
| `palette-contract` | Defines what an approved palette would have to specify *before* a membership check can become a rejection rule. Currently blocked at its prerequisite. | same file, lines 767–804 |
| `silhouette-readability` | Landmark checklist at target size on representative backgrounds — the correct gate for "do the islands still read". Its own POC is a 16×16 key with a hole and two teeth, i.e. separated landmarks at this exact size are a tested pattern in the corpus. | same file, lines 857–867, 1563–1573 |
| `crop-and-anchor` | The islands and the 2-row gap only survive if the 16×16 canvas and trim offset survive. Guards the pipeline step most likely to silently break this design. | `PIXEL-ART-ASSETS.md` 12066–12080; deep-research 476–500, 1276–1291 |
| `alpha-contract` | Keeps the binary-alpha/transparent-RGB policy separate from the still-unresolved color palette. | deep-research 945–977, 1276–1291 |

A corpus POC demonstrates its own fixture's stated properties. None of them proves anything about a
drone this project has not yet generated.

### 5.2 Structural template — **proposal**

Offered as a trial specification, not an adopted contract. The three owner requirements inside it are
marked; everything else is generalized from measurement and remains open.

```
canvas        16 × 16, RGBA, straight alpha            [16×16 = requirement]
alpha         only 0 and 255; transparent RGB = (0,0,0)
body          10 w × 8 h, horizontally centred (x 3–12)
frame         2 px dark ring on all four sides          [2 px = requirement]
interior      6 w × 4 h = 24 px  (the whole feature budget)
islands       two blocks above the body, ≥1 fully transparent row between
              them and the body, ≥1 transparent column between each other
                                                        [detached = requirement]
island span   confined to the interior column range, so they read as
              mounted on the body rather than as stray pixels
clearance     every interior feature keeps ≥1 interior-colour pixel
              between itself and the frame
anchor        logical origin (0,0) of the 16×16 canvas; islands are
              positioned relative to the body, never trimmed independently
```

### 5.3 Pipeline

1. **Author the silhouette mask first.** Flat opaque mask at 16×16, checked for: continuous 2-px ring,
   both islands detached, gap open. Per `silhouette-readability`, proportions and negative space are
   settled before any color is chosen — which is convenient, because the palette is unresolved.
2. **Place the interior features against the 24-px budget.** Decide the feature set explicitly (two
   eyes? eyes plus a status light? a mouth line?) and confirm the ≥1 px clearance rule holds for each
   before generating. This is where a 16×16 drone with a 2-px frame actually succeeds or fails.
3. **Apply color as a labeled trial.** Until the owner approves a palette, each candidate carries the
   colors it used as a *proposal*, and no candidate is rejected for palette membership. Record the
   colors used; do not silently install the reference's three colors as a contract.
4. **Generate.** Discover the actual PixelLab tools and their schemas in the harness first; do not
   assume a tool name or argument shape. The request must carry: 16×16 canvas, the 2-px dark frame,
   the detached antenna islands, binary alpha, and the interior feature list from step 2. Save the
   request against its task, claim dispatch once, and reconcile any unknown outcome before importing.
5. **Measure.** `pixl_asset_check` for size, alpha levels, component count, and the derived frame /
   clearance measurements.
6. **View.** Native scale and enlarged, against the real destination background, with the landmark
   checklist from §6.
7. **Import.** Verify the engine keeps the 16×16 canvas and does not trim to the opaque bbox — the
   single highest-risk step, see §5.4.

### 5.4 The specific risk this design carries

Any pipeline stage that trims transparent padding will crop this sprite to its opaque bbox: **10 × 12
at offset (3,2)**. That silently violates the 16×16 requirement and moves the sprite. `crop-and-anchor`
is explicit that a tighter rectangle moves the sprite if its trim offset is lost. Equally, a
"remove background" step that treats one RGB value as transparent is unsafe here: the fully transparent
pixels carry RGB (0,0,0), so a naive black-key would be ambiguous with any future near-black color.

Mitigation: pin the canvas to 16×16 explicitly at export and import, keep restoration metadata if any
tool does trim, and use an actual alpha mask rather than a color key.

---

## 6. Acceptance criteria

Declared before any candidate exists. Mechanical, visual and engine evidence are separate; passing one
does not supply another.

**Mechanical** — evidence: `pixl_asset_check` plus pixel measurement.

- Canvas is exactly 16 × 16. *(requirement)*
- Dark frame is exactly 2 px thick on all four sides of the body. *(requirement)*
- At least two opaque components are detached from the body component under 4-connectivity, and the
  antenna islands are among them. *(requirement — stated as "the islands are detached", not as a fixed
  count of 3, so a future variant may legitimately add a detail without failing)*
- Alpha levels are a subset of {0, 255}. *(proposal — a trial condition, not yet a rejection rule)*
- Every interior feature keeps ≥1 interior-color pixel between itself and the frame. *(proposal)*

**Visual** — evidence: host viewing of native-scale and enlarged renders on the destination background.
Cannot be satisfied by measurement.

- Landmark checklist: continuous frame ring; teal interior reads as a body, not as a hole; both eyes
  distinct from each other and from the frame; both islands read as detached antennas, not as noise or
  a broken outline.
- The gap between islands and body stays open at native scale.

**Palette** — **no criterion.** Cannot be declared until the owner approves a palette. A candidate must
not be failed for color membership in the meantime.

**Continuity** — not applicable. No animation, family or tile neighborhood has been requested.

**Engine** — **unavailable.** No destination project or engine has been named, so import behavior
(canvas preservation, trim, alpha model) is unknown. This is recorded as unavailable, not as a pass and
not as an artistic failure. It must be run before any drone is called delivered.

---

## 7. Open decisions

1. **Palette.** Blocking for any color rejection rule and for the color instruction in the provider
   request. Options: (a) adopt the reference's three colors as a scoped drone palette; (b) approve a
   wider ramp (the design has room for one more interior value without touching the frame); (c) leave
   open and let each candidate propose its colors, deferring the contract.
2. **Destination background.** Needed to complete `silhouette-readability`. My dark-background
   diagnostic suggests the dark frame and the all-dark islands are the weak point on dark scenes; if
   the game background is dark, that is worth resolving in the palette decision rather than after.

These two are coupled — the background answer changes what a good palette is — which is why they are
asked together.

---

## 8. Not done in this session

- No PX2 project was initialized and no PIXL state was created, amended or committed.
- No production art was generated and no provider was called.
- No engine import was attempted.
- `old-assessment.md` was left unchanged.
- The only files written are this document and the four inspection views named in §3.
