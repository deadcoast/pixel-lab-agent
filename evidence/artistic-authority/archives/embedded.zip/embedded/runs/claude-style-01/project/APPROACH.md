# Production approach — small lantern prop matching `translucent-reference.png`

Scope: planning only. No PX2 state was initialized or amended, no production art was
generated, and no provider was called. Nothing below is an accepted style contract;
it is a proposal built on measurements of the one supplied reference.

- Reference: `translucent-reference.png`
- sha256: `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`
- Inspection views rendered for this review: `inspection/reference-8x-backgrounds.png`,
  `inspection/reference-native-backgrounds.png` (reference composited over dark, light,
  mid-grey and busy backgrounds; nearest-neighbour 8x and native)

---

## 1. Authority table

| Property | Value | Standing | Source | Applies to |
| --- | --- | --- | --- | --- |
| Keep intentional partial transparency | required | **Requirement** | User brief, this session | Lantern prop and any sibling props |
| Keep selective anti-aliasing treatment | required | **Requirement** | User brief, this session | Lantern prop and any sibling props |
| Subject | "small matching lantern prop" | **Requirement** | User brief, this session | This task |
| Palette | not imposed by user | **Requirement (absence)** | User brief, this session | Frees palette choice; does not pre-approve one |
| Deliverable | this Markdown approach only | **Requirement** | User brief, this session | This task |
| Canvas | 32x32 | Observation | `asset-check` on reference | Reference only |
| Subject bbox | `[6,3]-[26,28]`, 20w x 25h | Observation | `asset-check` on reference | Reference only |
| Visible pixels / visible colors | 420 / 5 | Observation | `asset-check` on reference | Reference only |
| Opaque RGB set | `#25354A`, `#56B5BC`, `#F4DDA2` | Observation | Exact pixel enumeration (Pillow) | Reference only |
| Fractional-alpha pixels | 30 (7.1% of visible) | Observation | `asset-check` on reference | Reference only |
| Alpha levels present | 0, 96, 160, 255 | Observation | Exact pixel enumeration | Reference only |
| Alpha model | straight (not premultiplied) | Observation | `#56B5BC` at a=96 has G=181 > 96; premultiplied is impossible | Reference only |
| Transparent pixel RGB | exactly `(0,0,0,0)` | Observation | Exact pixel enumeration | Reference only |
| Opaque components | 1 (4-connectivity) | Observation | `asset-check` on reference | Reference only |
| Palette check passes with 5 RGBA entries + `alpha: full` | verified | Observation | `asset-check` run, this session | Checker design |
| Palette check fails with `alpha: binary` | verified | Observation | `asset-check` run, this session | Checker design |
| Reference-derived palette for the lantern | reuse the 3 opaque RGB entries | **Proposal** | Derived from reference; user has not adopted it | Awaiting decision D3 |
| Glow geometry rule (section 3) | 1px outer rim, body colour, 2 alpha levels | **Proposal** | Derived from reference geometry | Awaiting decision D1/D2 |
| Glow legibility on light backgrounds | a=96 rim is near-invisible | Observation, diagnostic | Composite of this reference over `(236,236,232)` only | Does not generalize to other backgrounds |

Method authority used (bundled corpus, `pixl knowledge`):
`alpha-contract`, `selective-edge-aa`, `palette-contract`, `silhouette-readability`,
`asset-provenance`, `material-channel-budget`. Their source locators are recorded in
the corpus; each is cited inline below where it constrains a step.

---

## 2. What the reference actually does

Exact pixel map (`.` transparent, `#` `#25354A`, `T` `#56B5BC`, `W` `#F4DDA2`,
`m` `#56B5BC` a=160, `l` `#56B5BC` a=96):

```
 3..8  .......####..........####.......    two 4px-wide dark prongs, x 7-10 and 21-24
 9,10  .......##################.......    dark top bar, x 7-24
11..25 ......l##TTTTTTTTTTTTTT##m......    2px dark side frame, 14px flat teal interior
14..17 ......l##TTWWWTTTTWWWTT##m......    two 3x4 cream inserts at x 11-13 and 18-20
26,27  .......##################.......    dark bottom bar
```

Findings that a production plan has to respect:

1. **The translucency is not edge softening — it is a 1px outer rim.** All 30
   fractional pixels sit *outside* the opaque silhouette: a single column at x=6
   (a=96) and a single column at x=25 (a=160), each spanning rows 11-25. Those rows
   are exactly the row span of the teal interior. So the rule is derivable:
   *dilate the body section one pixel left and right, fill with the body colour at
   reduced alpha*. Nothing internal, nothing on the top/bottom bars, nothing on the prongs.
2. **The rim is the body colour, not the outline colour.** RGB is `(86,181,188)` in
   all three of its states (a=96, a=160, a=255). It reads as light bleeding off the
   body, not as a softened contour.
3. **The selectivity is total.** Zero anti-aliasing anywhere else: no dithering,
   no interior ramp, no corner AA, no intermediate colours. The whole form is
   rectilinear, so the reference never exercises a diagonal or curve.
4. **The two alpha levels are asymmetric: left 96 (37.6% coverage), right 160
   (62.7%).** The geometry is otherwise perfectly mirror-symmetric about x=15.5.
   That asymmetry is the only directional cue in the image, and it implies a light
   source to the right.
5. **The flat fills are large.** Interior is 14x15 unbroken teal. Detail density is
   very low; a busy lantern would not match.

Visual inspection (`inspection/reference-8x-backgrounds.png`): the rim reads clearly
on dark, mid-grey and busy backgrounds, and the a=160 right column reads on all four.
The a=96 left column is near-invisible against the light background. Composited values
of the a=96 rim: `(47,83,88)` on dark `(24,24,28)`, `(180,215,215)` on light
`(236,236,232)`. At native 32x32 scale
(`inspection/reference-native-backgrounds.png`) the rim is subliminal on every
background — it is an enlarged-view / dark-background effect. This is the `selective-edge-aa`
pitfall (background-specific intermediate colours form halos on other backgrounds)
observed on this asset; it is a diagnostic result for these four backgrounds only,
not a general claim.

---

## 3. Proposed style contract for the lantern

Every row here is a **proposal** pending decisions D1-D3.

**Canvas and framing.** 32x32, straight alpha, RGB zeroed on fully transparent pixels.
Keep the subject inside a 20x25 bbox with the same footing (bottom of form at y=27,
3-4 rows of headroom) so the lantern sits on the same baseline as the reference prop.

**Palette.** Reuse the reference's three opaque entries with semantic roles assigned
for a lantern — no new hues needed, which is the strongest available guarantee of
"matching" (`palette-contract`: apply colour by semantic ramp, not free interpolation):

| Index | RGBA | Role in reference | Proposed role in lantern |
| --- | --- | --- | --- |
| 0 | `#00000000` | background | background |
| 1 | `#25354Aff` | frame / prongs | lantern chassis: cap, base, corner posts, handle |
| 2 | `#56B5BCff` | body fill | glass pane fill |
| 3 | `#F4DDA2ff` | inserts | flame / emissive core |
| 4 | `#56B5BCa0` | right rim | rim, lit side |
| 5 | `#56B5BC60` | left rim | rim, shadow side |

**Form vocabulary.** Rectilinear only, 2px chassis members, flat interiors, no dither,
no interior shading, one 4-connected opaque component. The reference's two 3x4 cream
inserts become the lantern's flame: a single centred cream block (proposed 4w x 5h)
rather than two, so the prop reads as a lantern and not as a second copy of the
reference. The reference's twin top prongs become the lantern's hanger — this is the
natural mapping and preserves the existing silhouette landmark.

**Glow rule (the part that must not be improvised).** Author it deterministically, not
by eye and not by asking a generator for it:

1. Rasterize the opaque lantern at the 6-entry palette above, binary alpha.
2. Identify the *glass section* row span (the rows where index 2 appears inside the chassis).
3. For those rows only, write index 4/5 into the single column immediately outside the
   left and right chassis edges.
4. Write nothing elsewhere. Top, bottom, hanger and all interior pixels stay binary.

This reproduces the reference's rule exactly rather than approximating its appearance,
and it makes the AA mask explicit as `selective-edge-aa` requires (changed pixels must
stay inside the selected mask; protected hard edges must remain byte-identical).

**Emission.** The cream core is *colour data only*. Per `material-channel-budget`, do not
ship an emission mask, height map or normal map unless a named renderer consumer exists;
no destination engine has been named for this task, so the deliverable is a single RGBA
sprite and the glow is baked.

---

## 4. Acceptance checks (write these before evaluating any candidate)

Mechanical, verified to behave as described in this session:

- `asset-check` with `width: 32`, `height: 32`, `alpha: full`, and the palette given as
  **5 explicit 8-digit RGBA entries** (`#25354Aff`, `#56B5BCff`, `#F4DDA2ff`,
  `#56B5BCa0`, `#56B5BC60`). Confirmed: the reference passes this exact configuration.
- Do **not** use `alpha: binary` — confirmed to fail on this treatment by design.
- Do **not** give the palette as 3-digit-pair RGB entries: confirmed that
  `["#25354A","#56B5BC","#F4DDA2"]` reports the two translucent variants as
  `outside_palette`. The palette check is RGBA-exact, so translucency must be
  enumerated as palette membership, which is the declared exception
  `alpha-contract` calls for.
- Fractional-alpha pixel count equals `2 x (glass row span)`, and every such pixel lies
  outside the opaque bbox columns. Reference budget for comparison: 30 px, 7.1% of visible.
- `opaque_components` = 1.

Visual, and not substitutable by the above (`silhouette-readability`):

- Native 32x32 and 8x views composited over at least dark, light and busy backgrounds.
- Landmark checklist at native scale: hanger reads as a hanger, glass reads as a single
  pane, flame separates from the glass, chassis corners stay closed.
- Side-by-side with `translucent-reference.png` at both scales to judge family match.
- A human verdict is required. `visual_quality_verified` and `engine_import_verified`
  both report `false` from the tool and cannot be satisfied mechanically.

---

## 5. Proof of concept to run before any batch

| Field | Content |
| --- | --- |
| Question | Can the chosen generator return an asset that conforms to the 3-colour opaque contract closely enough that the deterministic rim pass is the *only* alpha authoring needed? |
| Method | Generate one lantern at 32x32 with the reference as a style image, quantize to the 3 opaque entries, then apply the rim pass from section 3. |
| Smallest artifact | One static lantern sprite. No states, no variants, no siblings. |
| Acceptance | Stated before looking: `asset-check` passes the section 4 configuration; fractional pixels appear only in the two rim columns; rim row span equals the glass row span; enlarged and native views over three backgrounds read as the same family as the reference. |
| Result | Not run. Blocked on the missing provider surface (section 6). |
| Consequence | If the generator returns soft or noisy edges that survive quantization, drop generation for this prop and author the 32x32 by hand — at this detail density that is the cheaper path, and it removes the conformance risk entirely. |

The dominant technical risk is worth stating plainly: image generators return their own
edge treatment. A generated sprite will not spontaneously contain a 1px, 2-level,
body-coloured, glass-rows-only rim. **Do not put the transparency treatment in the
prompt.** Request an opaque rectilinear lantern, then author the alpha locally. Prompt
text is not a mechanism for reproducing a measured 30-pixel rule.

---

## 6. Provider status — blocked

No PixelLab tools are present in this session; the only MCP surface available is
`pixl-local`, which by its own contract never submits, polls, authenticates or generates.
`pixl capabilities` returns a **dated inventory** (retrieved 2026-09-11,
`live_discovery: false`), not live discovery, so it cannot establish current availability.

Precise missing capability: **a connected PixelLab MCP tool surface with credentials.**

From the dated inventory, the candidate that fits this task is `create_1_direction_object`
(requires `description` + `style_images`), with `reduce_colors` as a possible
post-pass; `create_image_pixflux` / `create_image_pro` are fallbacks. Those names must be
re-discovered live and their schemas re-read before use — they are not confirmed here.

When the surface exists, the sequence is `job-prepare` (save the exact request against
its task and output plan) → `job-dispatch` (claim once) → host call → `job-observe` →
`job-import`, then inspection and review as separate steps. That sequence requires PX2
state, which this task explicitly excludes.

---

## 7. Provenance

Per `asset-provenance`: `translucent-reference.png` is a user-supplied input in this
project root; no creator or reuse-permission evidence was supplied with it. If the
lantern is redistributed, the reuse basis for the reference-derived palette and form
vocabulary is **unresolved** and must be recorded before release. The lantern itself
is planned as an original asset authored from the functional brief, reusing only
measured colour values and proportions.

---

## 8. Open decisions

**D1 — Rim symmetry (blocking the rim rule).** The reference's 96/160 split implies an
external light from the right. A lantern is self-emitting, so the two readings conflict:

- *Inherit the asymmetry* (left a=96, right a=160): literally matches the reference
  treatment and keeps the props consistent if they share a scene light.
- *Make it symmetric* (both a=160, or both a=96): semantically correct for an emitter,
  but introduces an alpha pattern the reference does not contain.

Recommendation: inherit the asymmetry. The brief asks to keep the treatment, and a
matched scene light is the reading that keeps both props in one family.

**D2 — Curves.** The reference is entirely rectilinear and therefore supplies no
evidence for how a diagonal or curve should be anti-aliased. A lantern conventionally
wants a domed cap and a ring handle. Either constrain the lantern to the rectilinear
vocabulary (recommended — zero invention, guaranteed match), or approve an authored
edge ramp for curves, which would be a new style decision with no source authority.

**D3 — Palette adoption.** You imposed no palette, so the 6-entry table in section 3 is
a proposal, not a contract. Confirm it and it becomes a rejection rule for candidates;
leave it unconfirmed and it stays a labelled experiment.

Also worth your awareness, though not blocking: the a=96 rim effectively disappears on
light backgrounds and the rim is subliminal at native 32x32 on all four tested
backgrounds. If the lantern will be seen at 1x on light ground, the treatment will not
be visible there — that is a property of the reference treatment itself, not a defect
to fix silently.
