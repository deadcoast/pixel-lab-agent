# Matching drone approach

The supplied drone supports a useful starting point at the chosen 16×16 size: its two-pixel dark frame surrounds a 6×4 interior, both eyes remain separated from the frame, and two antenna islands sit clearly above the body. Preserve that construction. The earlier robot diagnostic supplies no reason to enlarge this drone, thin its frame, or connect its antennas. Exact palette values remain open.

This is the requested bounded planning evaluation, dated 2026-09-14. Only this Markdown approach is delivered. No project PX2 state was initialized or amended, no production art was created, and no provider was called. The supplied reference and earlier assessment are preserved.

The following authority account governs the whole approach, including future instructions and checks. “Proposed” means a starting point for a trial, without project-owner adoption.

| Property / value | Authority and status | Exact supporting source | Applicable scope |
| --- | --- | --- | --- |
| 16×16 canvas | User requirement | Current brief: “a 16 by 16 canvas” and “Keep those choices.” | Matching drone canvas; a different size fails this requirement. |
| Thick two-pixel dark frame around teal body | User requirement | Current brief: “a thick two-pixel dark frame around the teal body” | Body treatment; retain thickness and dark/teal relationship. |
| Two detached antenna islands | User requirement | Current brief: “two detached antenna islands” | Drone identity; preserve both islands and their separation from body and each other. |
| Match supplied drone reference | User requirement | Current brief: “review the supplied small-separated.png reference and prepare a matching drone approach” | Visual resemblance, informed by the observations below. |
| Exact three observed colors | Observation; provisional swatches proposed | Reference color counts below; current brief: “I have not approved a fixed palette.” | Starting color reference only; no exact membership rule or color-count ceiling. |
| Body rectangle, eye coordinates, antenna dimensions, two-row gap | Reference observations; matching layout proposed | Reference pixel coordinates below | Initial static sample layout; these exact measurements are not independently approved rejection thresholds. |
| Binary alpha and hard pixel edges | Reference observations; preservation proposed for first sample | Reference has only alpha 0/255 and flat color blocks | Sample treatment, without a universal alpha or antialiasing prohibition. |
| Native and integer-nearest enlarged inspection | Review method proposed by PIXL | `silhouette-readability` method and the inspection performed here | Diagnostic presentation; does not prescribe engine settings. |
| Minimum 32px, one component for every sprite, fixed prop palette | Unapproved earlier-agent proposals; not adopted | `old-assessment.md`, lines 1–3; current brief explicitly disclaims approval | Historical assessment of another resized robot, not this drone's requirements. |
| Target backgrounds, display scale, engine route | Unresolved | No destination supplied in current brief or `SESSION.md` | Later destination review; does not block this report. |

**Reference inspection and evidence.** PIXL `asset-check` was run on `small-separated.png` with width and height 16 and no palette restriction. It reported one frame, 88 visible pixels, three visible colors, zero fractional-alpha pixels, and three components using 4-neighbor connectivity over nonzero alpha. Its dimension check passed; it explicitly did not verify visual quality or engine import. A separate read-only Pillow inspection measured the following geometry and colors. Coordinates start at `(0,0)` in the upper left; ranges below are inclusive.

| Feature | Observed pixels |
| --- | --- |
| Body including frame | x=3–12, y=6–13: 10×8 rectangle, 80 visible pixels |
| Frame | Two rows at top and bottom, two columns at left and right; 56 dark body pixels |
| Interior | x=5–10, y=8–11: 6×4 area, containing 22 teal pixels and two eye pixels |
| Eyes | Pale single pixels at (6,9) and (9,9); two teal pixels between them; at least one teal pixel between either eye and the frame |
| Left antenna island | x=5–6, y=2–3: 2×2 dark block |
| Right antenna island | x=9–10, y=2–3: 2×2 dark block |
| Antenna separation | Empty rows y=4–5 above body; empty columns x=7–8 between islands at their height |
| Colors | Dark `#25354A`: 64 pixels; teal `#56B5BC`: 22; pale warm `#F4DDA2`: 2; alpha-zero background: 168 |

The original 16×16 image and an in-memory 16× nearest-neighbor enlargement were viewed. The compact rectangular face, substantial dark frame, pale paired eyes and detached upper blocks are legible in these reference views. The enlarged view supports the measured separation and clean rectangular clusters. No preview image was saved. The viewer's transparency backdrop and physical display scaling are not a target-game test; no light/dark/busy gameplay-background comparison was performed.

The three alpha components are the 80-pixel body and two four-pixel antennas. The eyes belong to the body's opaque component even though each is an isolated same-color detail. This distinction is why a global component-count rule or automatic singleton cleanup would be unsuitable. Preserve the named features and inspect unexpected fragments; a component count alone cannot establish a match.

**How the research applies.** The packaged PIXL source inventory verified local source identities. The three method entries, their complete compiled context packets, cited text and relevant existing proof receipts were read. These are candidate review methods, not new project style authority:

| Method | Applicability and remaining proof |
| --- | --- |
| `semantic-clusters` | Use separate semantic regions for body/frame, each antenna and each eye; use declared 4-neighbor measurements for repeatability. The existing connectivity fixture distinguishes 4- and 8-neighbor results and expressly does not establish semantic importance. This drone's mapped features supply the relevant interpretation. A future cleanup still needs before/after feature review. |
| `silhouette-readability` | Inspect antenna separation and body silhouette, then use the colored image to inspect eyes and teal interior. The existing key fixture checks a hole, shaft and teeth; it proves no drone recognition or background readability. Actual display scale and representative backgrounds remain prerequisites for destination conclusions. |
| `palette-contract` | Exact palette enforcement is inapplicable now: its approved-palette prerequisite is absent. Its fixture proves exact RGBA membership detection only. Use the observed swatches as a trial starting point; evaluate dark frame, teal body and eye distinction without rejecting every new color. |

The exact source excerpts are conditional and context-specific. The cluster passage permits intentional isolated pixels and refers to an **approved** ramp; the animation passage evaluates changes by semantic role. The archive excerpts concern another project's UI and CSS colors. None establishes this project's palette, minimum canvas, global connectivity policy or engine settings.

The earlier assessment records a nearest-neighbor reduction of a different 32px robot, where its inset border crowded its eyes at 16px. No original diagnostic artifact, drone measurement or engine test accompanies that note. Keep the reported failure attached to that robot and resize method. On this supplied drone, the observed teal margins around the eyes directly address the crowding concern, without claiming every 16px design will work.

**Proposed production sequence, for a later art assignment.**

1. Author one static matching drone directly on a 16×16 logical canvas. Start from the observed body, eyes and island layout so the known interior budget is preserved. Retain the required two-pixel dark frame and teal body. Propose hard edges, transparent surroundings and the reference's flat, front-facing appearance for this first sample. Use the three observed swatches provisionally; additional colors or adjusted shades remain available for review.
2. Treat both antenna islands and both eyes as intentional named features during editing. If a trial becomes crowded, first adjust interior detail or spacing within the chosen aesthetic. Any proposed change to canvas size, frame thickness or antenna detachment would require a new user decision; the old note grants none.
3. Before judging the sample, record separate checks: exact 16×16 dimensions; two-pixel dark frame around teal; two identifiable detached antennas; and visual resemblance to the reference at native size and integer-nearest zoom. For the proposed layout, inspect paired-eye readability and the intervening teal. Measure gaps, alpha and components as diagnostics, without silently promoting the reference's exact counts or coordinates to requirements. Omit fixed-palette validation unless the user later adopts an explicit palette and scope.
4. Review that single sample on actual intended backgrounds at the intended display scale. A flat silhouette tests body/island separation; colored views test the eyes, interior and dark-frame distinction. Record observations for each named feature. Revise a failing sample within the established choices and review it again before extending variants or animation. No numeric contrast threshold or fixture pass substitutes for this visual assessment.

No decision is needed to complete this approach. The next production action would be the single static trial above, under a later art assignment. Before an in-game readability conclusion, establish the intended display scale and representative background(s). Palette policy can stay open during that trial; a fixed palette becomes a decision only if exact color enforcement is wanted. This session establishes a reference-based approach, not production or engine acceptance.

**Source locators for resumption.** All bundled paths below are relative to `.agents/skills/pixl-kit/resources/`. Text ranges are inclusive and one-based.

- `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md`: lines 1402–1445 and 857–867 for semantic clusters; 857–867 and 1563–1573 for silhouette/semantic review; 767–804 and 1538–1550 for conditional palette guidance. SHA-256: `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`.
- `training/original-docs/PIXEL-ART-ASSETS.md`: lines 11–15 for contextual UI readability and 2677–2683 for an unrelated CSS palette example. SHA-256: `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`.
- `knowledge/library.px`: read-only context focuses `k.semantic-clusters`, `k.silhouette-readability`, `k.palette-contract`. Existing receipt `evidence/art-methods/poc-report.json`, scope `offline_reference_fixtures`, checks `cluster-connectivity`, `key-silhouette-landmarks`, `palette-membership`; SHA-256: `a3b77eae4ab97843829efab67b8773086498d67d91672350520194059f586d81`. These receipts were inspected, not rerun or adopted as drone acceptance.
- Project input `small-separated.png`: SHA-256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`.
- Project input `old-assessment.md`: SHA-256 `4f7db791ae8d97869b169c76bcfce93c6101e5497b1b682d649730a695e70521`.

Final authority reconciliation: the enforceable art restrictions above trace to the current user's canvas, frame/body treatment, antenna detachment and reference-match request. Exact swatches, color count, alpha policy, pixel coordinates, gap widths, total components and preview sampling retain their observed/proposed scopes throughout.
