Use a compact lantern with dark structural shapes, a cyan body and small warm light accents, preserving the reference's intentional partial transparency and selective anti-aliasing. Start with a proposed 32×32 study so it can be compared directly with the reference. Color selection remains flexible; the reference supplies relationships and examples, not an exact palette requirement.

This is a planning deliverable only. The reference and packaged PIXL guidance were inspected locally. No production artwork was made, no provider was called, and no PX2 state was initialized or amended. The sample and checks below describe future work, not production acceptance.

The supplied [reference](translucent-reference.png) was viewed at native size and in temporary, in-memory 8× nearest-neighbor previews over white (`#FFFFFF`), dark blue-gray (`#202830`) and gray (`#808080`). Its upright motif has two top uprights, a substantial dark border, a broad cyan interior and two pale warm rectangular accents. The silhouette is mostly rectilinear. The cyan side strips change appearance with the background, while the interior stays solid. On the dark diagnostic background, the dark structure is less distinct. These observations apply to these views; the actual game background and display behavior remain unknown.

Local PIXL `asset-check`, using `alpha: "full"` and no palette restriction, measured one 32×32 frame, 420 nonzero-alpha pixels and 30 partially transparent pixels. Direct RGBA inspection found 604 fully transparent and 390 fully opaque pixels. The occupied bounds are x=6–25, y=3–27, using zero-based coordinates. The checker reports five visible color entries; these represent three distinct RGB colors with alpha variants:

| Observed RGB | Alpha, on a 0–255 scale | Pixels | Location or visual role |
| --- | --- | ---: | --- |
| `#25354A` | 255 | 180 | Dark structure |
| `#56B5BC` | 255 | 186 | Cyan interior |
| `#F4DDA2` | 255 | 24 | Two warm accents |
| `#56B5BC` | 96 | 15 | Left exterior strip, x=6, y=11–25 |
| `#56B5BC` | 160 | 15 | Right exterior strip, x=25, y=11–25 |

The partial transparency is localized to one-pixel side strips. The interior cyan pixels are opaque. This identifies where the supplied treatment occurs without changing the user's description of intentional transparency and selective anti-aliasing. A broadly translucent glass pane would be a new artistic proposal, rather than something established by these pixels.

The following authority table governs the proposed design, future instructions and checks. Observations and proposals do not become production rejection rules merely by appearing here.

| Property / value | Authority and status | Exact source | Applicable scope |
| --- | --- | --- | --- |
| Small matching lantern prop | User requirement | Brief: “a small matching lantern prop” | Subject and reference continuity |
| Intentional partial transparency and selective anti-aliasing | User requirement | Brief: “Keep that treatment in the new props” | Authored pixels, cleanup, export and visual review |
| Palette remains unconstrained | User-specified absence of a restriction | Brief: “I have not imposed a fixed palette” | Color choices and mechanical checks; no exact palette or color-count gate |
| 32×32 canvas, measured colors, occupied bounds and alpha values | Observations | `translucent-reference.png`; measurements above | Reference description only; no mandatory dimensions, opacity levels, counts or gaps for new props |
| Upright shape, dark structure, cyan field, warm accents, localized softer sides | Visual observations | Native reference and the three 8× diagnostic composites described above | Basis for the matching proposal; material identity and directional lighting are not established |
| One static 32×32 front-facing study, handle, cap, base, cyan body and warm core | Assistant proposal | This approach, derived from the brief and inspected reference | First future sample; size, projection and design remain provisional |
| RGBA PNG with straight alpha for the proposed export; nearest/point inspection | Assistant technical proposal | PIXL methods `alpha-contract` and `selective-edge-aa`, with limits below | Future trial and export investigation; destination import settings remain unresolved |
| Markdown approach only; local project work | User requirement | Evaluation instruction: “do not initialize or amend PX2 state, create production art, or call a provider”; `SESSION.md` | This evaluation, which ends with this file |

For a later production assignment, the proposed sequence is:

1. **Establish the viewing context.** Determine the intended on-screen size and representative background. The 32×32 canvas is a practical comparison study, not a minimum viable size or an adopted delivery specification. Keep engine-specific choices open until the destination is known.
2. **Build one representative lantern.** Give it a legible handle or loop, cap, base and frame surrounding a compact light-bearing body. Use the observed dark/cyan/warm hierarchy as a starting point, adjusting hues and values when useful. Favor a few readable shapes at native size. The observed pair of warm rectangles need not be copied literally into a lantern's light source.
3. **Author the transparency and edges deliberately.** Retain visibly intentional partial-alpha areas and selective edge smoothing. Start by testing narrow cyan edge coverage alongside an opaque structural frame, reflecting the reference. Choose the softened regions for the lantern's own geometry and keep the other edges deliberate. Alpha 96 and 160 are available reference starting values, not the only permitted opacities. Additional glass translucency can be investigated as a labeled variation. Preserve the treatment through cleanup and export: avoid flattening partial alpha or replacing selective edge work with blanket blur. Evaluate color changes by their effect on the intended treatment.
4. **Review the actual sample.** Compare it with the reference at native size and integer zoom. Test lantern recognition, the dark/cyan/warm relationship and whether the softened regions remain intentional. Preview over light, dark and actual destination backgrounds. Look for background-dependent fringes or loss of structure, distinguishing intended translucency from export defects. Adjust the sample based on the observed problem; a weak result on one diagnostic background does not establish a universal size or contrast threshold.
5. **Verify export and destination behavior when available.** Reopen the proposed RGBA PNG and inspect its alpha histogram and partially transparent regions. Use full-alpha checking with no fixed palette argument. A generic checker pass does not prove that partial transparency survived or that anti-aliasing is aesthetically successful. Compare the reopened file with the authored sample. For later engine delivery, test the actual blend convention, sampling and any atlas edge behavior against the selected background. Keep unavailable engine review recorded as unresolved.

The smallest future proof is one lantern containing both a hard structural edge and a deliberately softened, partially transparent edge. Its question is whether the reference treatment can survive a readable lantern design and the chosen display path. Before evaluating it, record the intended edge regions and viewing conditions. Evidence would include the actual sample, alpha measurements, native/enlarged comparisons and an export comparison. The user-derived review criteria are lantern identity, matching treatment, retained partial transparency and selective anti-aliasing. The 32×32 size and suggested colors are trial parameters. No such sample or proof was executed during this evaluation.

PIXL research selected `selective-edge-aa` for localized authored edge treatment and `alpha-contract` for preserving transparency through compositing. Their compiled contexts and existing bounded receipts were read from the packaged library. The first method assumes an approved edge ramp and representative background; this project has neither, so its fixed-ramp palette check is not adopted. Color and alpha can be chosen for the study while retaining localized editing as the technique under investigation. Nearest-neighbor previews preserve authored pixels for inspection; they do not settle the game's eventual rendering policy.

The exact retrieved source text is in `.agents/skills/pixl-kit/resources/`:

| Source | Retrieved lines | Relevance and limitation |
| --- | --- | --- |
| `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md` | 590–632; 907–919 | Coverage cues, authored edge colors and the distinction from runtime filtering. Its strict-palette example does not impose a palette here. |
| Same file | 945–977; 1276–1291 | Channel layout and companion-texture alignment. These provide broader context, not proof of the lantern's alpha interpretation or a target importer. |
| `training/original-docs/PIXEL-ART-ASSETS.md` | 942–958 | CSS opacity/blur example cited by the alpha method; insufficient to establish a PNG or engine blending contract. |
| `evidence/art-methods/poc-report.json` | 1173–1220; 1347–1394 | Existing `selective-aa-boundary` and `alpha-compositing-contract` receipts. They demonstrate edit locality and numeric compositing in their fixtures, respectively; they do not establish this prop's visual quality, display color handling or engine behavior. |

Source discovery verified the installed corpus identities. The reference SHA-256 is `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`. The retrieved deep-research source hash is `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`; the asset-archive source hash is `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`. Source and fixture inspection supplies planning evidence, not a newly executed production proof.

The approach is complete for this bounded evaluation. The next consequential production choice is the lantern's intended display size and representative background. Those determine how the proposed sample should be judged; a fixed palette decision is unnecessary.
