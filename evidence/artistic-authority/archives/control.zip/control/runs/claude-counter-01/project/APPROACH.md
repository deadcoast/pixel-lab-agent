# Drone production approach

Scope: planning only. No PX2 state was initialized or amended, no production art was
generated, and no provider was called. Conclusions below rest on measurement of the
supplied reference plus my own visual inspection of rendered views.

## 1. What was inspected

| Item | Detail |
| --- | --- |
| Reference | `small-separated.png`, sha256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c` |
| Measurement | `pixl_asset_check` (4-connectivity, nonzero alpha) |
| Review views | `review/backgrounds.png`, `review/silhouette.png`, `review/scale-ladder.png` (inspection artifacts, not deliverables) |
| Methods consulted | `silhouette-readability`, `semantic-clusters` from the bundled knowledge library |

Engine import behavior is **not** verified — no engine was available this session.

## 2. Measured facts of the reference

Canvas 16x16. 88 visible pixels, 3 visible colors, 3 opaque components, content bbox
x 3-12 / y 2-13. Alpha is fully binary (0 fractional-alpha pixels).

```
      col 3 4 5 6 7 8 9 10 11 12
row 2         # #     # #            antenna islands (2x2 each)
row 3         # #     # #
row 4                                gap (2 empty rows)
row 5
row 6     # # # # # # # #  #  #      body box 10x8, uniform 2px frame
row 7     # # # # # # # #  #  #
row 8     # # T T T T T T  #  #      teal interior 6x4
row 9     # # T E T T E T  #  #      eyes at (6,9) and (9,9)
row 10    # # T T T T T T  #  #
row 11    # # T T T T T T  #  #
row 12    # # # # # # # #  #  #
row 13    # # # # # # # #  #  #
```

Colors observed: frame `#25354A` (64 px), teal `#56B5BC` (22 px), eye cream `#F4DDA2` (2 px).

Geometry worth locking:

- The frame is uniform 2px on all four sides of the body box. Confirmed, not assumed.
- The sprite is symmetric about x = 7.5. Each antenna's inner column aligns with one eye
  (antenna 5-6 / eye 6; antenna 9-10 / eye 9).
- Canvas margins: 3 px left and right, 2 px top and bottom. Antenna-to-body gap: 2 rows.

## 3. Status of `old-assessment.md`

That document was written by an earlier agent about a **different** robot, derived from a
nearest-neighbor downscale of a 32px source, and carries no owner adoption, no measurement
on this drone, and no engine test. I tested each of its three claims against this drone:

| Prior claim | Result on this drone |
| --- | --- |
| A 2px border at 16px "consumes most of the interior" | **Overstated.** The frame is 64 of 88 px, but the interior is a usable 6x4 = 24 cells. The relevant limit is the free field (section 4), not total area. |
| "Eyes meet the contour", so 32px is the minimum | **False here.** Both eyes have exactly one teal cell of clearance from the frame on every side. The 32px minimum is unsupported for this sprite. |
| All sprites should be one connected component | **Contradicts the chosen aesthetic.** 3 components is deliberate: body plus two detached antenna islands. |
| Lock all props to the three observed colors | **Not adopted.** You have not approved a palette; these three colors are reference-observed facts, not a contract. |

The prior assessment is not carried forward. Its underlying worry — small canvas plus thick
frame — is real but lands in a different place, described next.

## 4. The constraint that actually binds: the interior free field

Keeping the observed one-cell teal clearance around interior features, the region where a
feature can sit without touching the frame is **x 6-9 by y 9-10 — 8 cells**. The eyes
already occupy 2 of them. **Six cells remain** for every future interior feature.

Practical consequence: a mouth, vent, status light or chest emblem must fit either the
4x1 strip at row 10 or the central 2x2 at (7-8, 9-10). Two such features cannot coexist at
full clearance. Interior detail is a scarce, budgeted resource on this sprite — plan
variants around swapping the interior feature, not accumulating features.

A second rule follows from the 2px frame directly:

> **The 5-pixel rule.** Any form that should show teal needs at least 5 px across
> (2 frame + 1 teal + 2 frame). Anything narrower is necessarily solid dark.

This governs limbs, mounts, props and antenna variants. The existing 2x2 antennas obey it:
at 2 px they are correctly all-frame with no interior.

## 5. The real risk: background-dependent silhouette collapse

This is the finding that changes production, and it is the opposite of the prior
assessment's concern.

Viewing the sprite composited on four backgrounds, the frame color `#25354A` is dark and
desaturated, so on dark or navy-ish backgrounds the frame merges into the background and
the sprite visually reduces to a floating teal rectangle. Supporting contrast ratios of
frame against background:

| Background | Ratio | Observed |
| --- | --- | --- |
| White | 12.45 | reads fully |
| Busy mid-brown | 2.11 | reads; the checker's light cells carry it |
| Near-black `#141416` | 1.48 | frame edge weak, antennas hard to find |
| Dark navy `#1C283A` | 1.19 | near-collapse |
| The frame color itself | 1.00 | **antennas vanish entirely** |

The flat silhouette confirms why this hurts: it is a plain rectangle with two small squares
above it. **The silhouette carries almost no identity.** Identity on this drone is
color-borne — the teal panel and cream eyes — so when the frame drops out, the two detached
antenna islands, the feature you specifically chose to keep, are the first thing lost.

One thing that is *not* a problem: eye/teal luminance contrast is only 1.80, but on the
scale ladder the eyes read clearly at every integer scale from 1x to 6x on a light
background. The warm/cool hue split carries them. No change needed there.

## 6. Production approach

Carry these forward as the working contract. Items marked (open) await your decision.

**Fixed by your choice — do not vary:**

1. 16x16 canvas; body box 10x8 with a uniform 2px frame; two detached 2x2 antenna islands.
2. Content centered: margins 3 left/right, 2 top/bottom; antenna-to-body gap 2 rows.
3. Anchor on the **body box** (rows 6-13), not the bbox, so antenna motion does not shift
   the sprite's registration.

**Derived rules:**

4. Interior features must fit the 6 remaining free-field cells and keep 1 cell of teal
   clearance from the frame. Prefer swapping the interior feature over adding features.
5. Apply the 5-pixel rule to any new appendage or prop.
6. Treat the antenna islands as **protected semantic clusters** (`semantic-clusters`):
   never auto-merge components, and never run a "delete small islands" cleanup. Component
   count must stay 3 under 4-connectivity.
7. Keep alpha binary. No fractional-alpha edge softening.
8. Integer presentation scales only.
9. Animation headroom is 2 rows above and below. An idle bob of +/-1 px is safe; +/-2 px
   touches the canvas edge. If antennas lag the body, cap relative travel at 1 px so the
   gap never closes to 0 and merges the components.

**Verification before any batch:**

10. Prove the palette decision (below) on one representative sample and inspect it on the
    actual target backgrounds before generating a family. Do not accept from measurement
    alone — measurement did not surface the collapse; viewing did.
11. Engine import remains untested. Confirm the importer preserves 3 separate components
    and does not trim per-component before accepting any delivery.

## 7. Open decision required from you

Palette is unapproved, and because identity on this sprite is color-borne rather than
silhouette-borne, it is the load-bearing decision. The collapse in section 5 can be fixed
in the sprite or in the environment:

- **Option A — background contrast floor.** Keep exactly the three observed colors. Require
  that backgrounds behind drones hold roughly >= 3:1 contrast against `#25354A`. Costs
  nothing in the sprite and preserves your aesthetic exactly, but constrains level art.
- **Option B — reserve a fourth palette slot** for a lighter rim applied only where the
  frame meets a dark background. Fixes the sprite anywhere, but it changes the look and
  spends interior-adjacent pixels on the 2px frame.
- **Option C — leave palette open**, treating the three colors as reference-observed only
  and deciding per asset. Defers the problem; not recommended for a family.

Recommendation: **Option A if you control the backgrounds drones appear on; Option B if
they are uncontrolled.** Option B has not been tested — if you choose it, it should be
proven on one representative sample first.

Nothing else blocks starting production.
