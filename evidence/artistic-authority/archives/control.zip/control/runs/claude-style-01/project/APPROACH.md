# Production Approach — Matching Lantern Prop

**Status:** Planning only. No PX2 state written, no art generated, no provider called.
**Reference:** `translucent-reference.png`
**sha256:** `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`
**Date:** 2026-09-14

---

## 1. What was actually inspected

| Check | Result |
| --- | --- |
| Canvas | 32 × 32, RGBA, straight alpha (no `premultiplied` marker in PNG `info`) |
| Visible pixels | 420 |
| Distinct visible RGBA values | 5 |
| Fractional-alpha pixels | 30 |
| Opaque components (4-connectivity) | 1 |
| Visible bbox | x 6–25, y 3–27 |
| Opaque bbox | x 7–24, y 3–27 |

Visual inspection was done at 12× integer-nearest over four backgrounds
(checker, `#111114`, `#EEEEE8`, `#C83CB4`) — see `views/`. Measurements alone do not
establish artistic acceptance; the observations below come from looking at those views.

### Exact pixel inventory

| Role | RGBA | Alpha | Count |
| --- | --- | --- | --- |
| Empty | `(0,0,0,0)` | 0 | 604 |
| Glass / body | `#56B5BC` | 255 | 186 |
| Frame | `#25354A` | 255 | 180 |
| Emissive window | `#F4DDA2` | 255 | 24 |
| Soft column, **left** | `#56B5BC` | **96** | 15 |
| Soft column, **right** | `#56B5BC` | **160** | 15 |

---

## 2. What the treatment actually is

The brief calls this "partial transparency and selective anti-aliasing." Reading the
raster, the second half of that needs a correction before it can be reproduced, because
copying it as anti-aliasing would produce the wrong asset.

**The fractional alpha is not edge anti-aliasing.** Three facts from the pixel map:

1. It occupies exactly **two 1-pixel vertical columns** — `x=6` and `x=25` — sitting
   *outside* the opaque silhouette, spanning only rows 11–25.
2. Those columns are **glass hue** (`#56B5BC`), not an intermediate between the frame
   (`#25354A`) and the background. A true AA ramp on that boundary would darken toward
   the frame; this brightens away from it.
3. The treatment is **absent** from every other edge — the top posts, the top rail, the
   bottom rail, and both window cutouts are all hard-edged and byte-clean.

So it is a **light bleed keyed to the lit-glass band**: the glass appears to emit past
its housing, and only where the housing contains glass. That is a material behavior, not
a contour-smoothing behavior. This matters because the `selective-edge-aa` method would
tell us to derive intermediate colors from the frame→background ramp inside an edge mask,
which would visibly destroy the effect. The governing method here is `alpha-contract`
(emission/translucency policy), with `selective-edge-aa` applying only to the *discipline*
of keeping the treatment inside a declared mask — which the reference does rigorously.

**The bleed is asymmetric.** Left is α=96, right is α=160 — a ~1.7× difference, clearly
visible at 12×. Two readings, and they are not equivalent for production:

- **(A) Directional light.** The prop is lit from the right, so the right-hand bleed is
  stronger. Reproducing this means every prop in the family inherits a fixed light
  direction and the bleed asymmetry must flip consistently on mirrored assets.
- **(B) Authoring artifact.** The two levels were placed by hand and drifted.
  Reproducing it means picking one level and applying it symmetrically.

I cannot settle this from one 32×32 sample. See §7 — this is the decision I need from you.

**The alpha levels are dither-convertible, and that is probably not a coincidence.**

| Level | α/255 | In 16ths | Nearest 4×4 rank | Error |
| --- | --- | --- | --- | --- |
| 96 | 0.3765 | 6.024 | **6/16** | 0.15 % |
| 160 | 0.6275 | 10.039 | **10/16** | 0.25 % |

Both land within a quarter of a percent of exact 4×4 ordered-dither coverages. Verified
against the `dither-coverage` rank matrix: threshold `rank<6` selects exactly 6 of 16
cells, `rank<10` selects exactly 10 of 16. This gives a free, faithful fallback if a
consumer ever demands binary alpha (§5.3).

**The treatment is tuned for a dark background.** Composites of the α=96 / α=160 columns:

| Background | α=96 result | α=160 result | Reads as |
| --- | --- | --- | --- |
| `#111114` dark | `#2B4F53` | `#3C787D` | Dim glow — correct |
| `#EEEEE8` light | `#B5D9D7` | `#8FCACC` | Pale mint halo — acceptable |
| `#C83CB4` magenta | `#9D6AB7` | `#8088B9` | **Purple-grey fringe — hue-alien, fails** |

This is the documented `selective-edge-aa` pitfall ("background-specific intermediate
colors can form halos on different backgrounds"). The reference is only valid against
backgrounds that are dark or desaturated. That constraint must be declared, not inherited
silently.

---

## 3. Geometry vocabulary to carry into the lantern

The reference is built from a strict module grid. The lantern should be drawn in the same
vocabulary rather than redesigned, or it will not read as a set.

- **Frame stroke: 2 px**, uniform — side walls `x 7–8` / `x 23–24`, rails `y 9–10` / `y 26–27`.
- **Posts: 4 px wide × 6 px tall** (`x 7–10`, `x 21–24`, `y 3–8`), flush with the outer wall.
- **Glass field: 14 × 15 px**, fully inset inside the frame.
- **Emissive windows: 3 × 4 px**, two of them, bilaterally placed, hard-edged, never bled.
- **Bleed: exactly 1 px**, outside the opaque silhouette, glass band rows only.
- Everything is axis-aligned. There is not a single diagonal or curve in the reference,
  so `edge-rhythm` (stair-step auditing) has nothing to audit and imposes no constraint —
  but it also means **a curved or tapered lantern body would be off-style.** Keep the
  lantern rectilinear: a boxed housing with a rectangular cage, not a rounded hurricane lamp.

---

## 4. Palette

You have not imposed a palette, so nothing here is confirmed. The reference supplies only
three opaque colors — enough for a flat box, too lean for a lantern, which needs at minimum
a metal shadow (cage depth), a metal highlight (top cap / handle), and a flame core.

**Proposal: keep the three reference colors as fixed anchors and extend by semantic ramp,
never by free RGB picking** (`palette-contract`, `material-ramps`). Candidate extension,
derived by HLS shift with cool-shadow / warm-highlight hue rotation:

| Index | Role | Hex | Origin |
| --- | --- | --- | --- |
| 0 | transparent | `(0,0,0,0)` | reserved |
| 1 | frame shadow | `#14222D` | derived (L −0.09, H −7°) |
| 2 | **frame base** | `#25354A` | **anchor — from reference** |
| 3 | frame light | `#3A4D6D` | derived (L +0.11, H +4°) |
| 4 | glass deep | `#379391` | derived (L −0.14) |
| 5 | **glass base** | `#56B5BC` | **anchor — from reference** |
| 6 | **emissive base** | `#F4DDA2` | **anchor — from reference** |
| 7 | emissive core | `#FBEBBA` | derived (L +0.06, S +0.10) |

Eight entries, three of which are byte-identical to the reference. Index 4 drifted slightly
green during derivation and should be hand-corrected toward `#3E9AA4` if you want the glass
ramp to hold a single hue. **Confirm or replace this table before any generation** — it is
the largest un-nailed-down variable in the plan.

---

## 5. Style contract for the new prop

### 5.1 Alpha contract (binding)

- **Straight** (non-premultiplied) RGBA. Empty pixels are exactly `(0,0,0,0)`.
- **Allowed alpha ladder: {0, 96, 160, 255}.** No other value is permitted. This is the
  declared exception to a binary-alpha rule and must be written down as such, because a
  validator would otherwise flag all 30 fractional pixels.
- Fractional alpha is **reserved to the glass/emissive material**. The frame is always
  α=255 or α=0. No fractional alpha anywhere on the housing silhouette.

### 5.2 Bleed mask rule (binding)

- Bleed extends **1 px** beyond the opaque silhouette, and only laterally from a lit region.
- Bleed carries the **glass hue**, not a frame→background interpolation.
- Top and bottom edges, posts, caps, handles and window borders stay **hard**.
- Composite-safe backgrounds: dark or low-saturation only. Declare this; do not ship the
  prop onto a saturated background without re-authoring the bleed.

### 5.3 Binary-alpha fallback (pre-approved, no new decision needed)

If a consumer rejects fractional alpha, replace α=96 → 4×4 ordered dither at `rank<6` and
α=160 → `rank<10`, using the `dither-coverage` rank matrix, phase-locked across the whole
prop. This is numerically faithful to within 0.25 % coverage. It changes the look at 1×
(stippled rather than smooth), so it is a fallback, not the default.

### 5.4 Framing and anchor

- 32 × 32 canvas, matching the reference.
- Reserve **≥2 px atlas padding** on every side. The bleed lives *outside* the opaque body
  and inside the visible bbox; tight-packing to the opaque bounds will clip it, and
  bilinear atlas sampling will smear it into neighbours (`crop-and-anchor`).
- Anchor at the **base centre** of the opaque housing, not the visible bbox centre — the
  bleed is asymmetric (§2) and would otherwise drag the anchor off-centre by a subpixel.

---

## 6. Execution plan

Sequenced so the riskiest unknown is proven on one asset before any batch.

**Step 1 — Lock the contract.** Resolve §7 decisions. Write the confirmed palette, alpha
ladder and bleed mask rule into PX2 intake as *confirmed* choices; everything else stays
*proposed*. Plan the lantern output before the file exists.

**Step 2 — Representative sample (one lantern, no batch).** The consequential uncertainty
is **whether a generator will return the 4-level alpha ladder at all.** Generators commonly
flatten to binary alpha or emit a soft anti-aliased fringe on every edge — either outcome
silently breaks the treatment. This must be proven on one asset first.

Route, in order of preference:

- **`create_1_direction_object`** — requires `description` + `style_images`; the single-view,
  style-matched prop path. Feed `translucent-reference.png` as the style image. Best match.
- `create_map_object` as fallback if style-image conditioning underperforms.
- **Hand-authored / post-corrected 32×32** if both return unusable alpha. Given the reference
  is 420 visible pixels of axis-aligned rectangles, this is a genuinely cheap fallback and
  should not be treated as defeat.

Record the request against its task and output plan, claim dispatch, then reconcile —
the host performs the actual call.

**Step 3 — Acceptance, recorded in four separate categories.** Do not collapse these.

| Category | Criterion |
| --- | --- |
| Mechanical | Every opaque pixel ∈ confirmed palette; every alpha ∈ {0, 96, 160, 255}; canvas 32×32; ≥2 px padding intact |
| Mechanical | Fractional-alpha pixels fall **only** inside the declared bleed mask; frame silhouette byte-hard |
| Visual | Inspect at 1× and 12× nearest over dark, light and checker. Lantern reads as a lantern in silhouette alone (`silhouette-readability`) |
| Visual | Glow reads as emission, not as a blur or a drop shadow |
| Continuity | Side-by-side with the reference at 1×: same frame stroke weight, same module rhythm, same glow intensity. They must read as one set |
| Engine | Round-trip import; confirm straight-alpha interpretation and that the bleed is not double-multiplied (`alpha-contract` pitfall: re-multiplying premultiplied RGB darkens edges) |

**Step 4 — Only after the sample is accepted**, extend to further props as a family with
the sample as declared baseline.

**Carry provenance.** Record on the output that it derives from
`translucent-reference.png` @ `bda5c9b1…`, with the adaptation intent "match bleed treatment,
extend palette by ramp" (`asset-provenance`). Without this the alpha ladder looks like a bug
to the next person who validates the file.

---

## 7. Open decisions

**Blocking — needed before Step 2:**

1. **Is the left/right bleed asymmetry (α 96 vs 160) intentional directional lighting, or
   an authoring artifact?** If directional, I fix a light direction for the whole family and
   mirrored assets must flip the ladder. If artifact, I standardise on one level — I'd
   suggest α=128 (= 8/16, exactly half, and the cleanest dither fallback).

2. **Confirm or replace the §4 palette.** Three anchors are locked by the reference; the
   five derived entries are my proposal, and index 4 needs the hue correction noted.

**Non-blocking — assumptions I will proceed under unless corrected:**

3. Lantern stays **rectilinear** and 32×32, in the reference's module vocabulary (§3).
4. Target backgrounds are **dark or desaturated**; the bleed is not authored for saturated
   backgrounds and will fringe on them (§2).
5. Fractional alpha is the default; the dither path (§5.3) is fallback only.

---

## 8. Scope statement

This document is the sole deliverable. Per the evaluation bounds: no PX2 state was
initialised or amended, no production art was created, and no provider was called. The
files under `views/` are local nearest-neighbour inspection renders of the supplied
reference, generated solely to support §2, and are not project state or candidate assets.

Nothing here constitutes production acceptance. The alpha-preservation question in Step 2
is unresolved and cannot be resolved without a live generation call.
