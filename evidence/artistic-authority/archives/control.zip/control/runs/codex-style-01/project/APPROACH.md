# Matching lantern production approach

Preserve the reference's compact dark structure, broad cyan fill, small cream accents, and deliberately localized partial transparency. Begin with a single static lantern proposal at 32 × 32 pixels. Keep palette development open: the reference colors are useful starting points, and additional colors may serve the lantern's materials and light without becoming a fixed palette requirement.

This document completes the bounded planning evaluation. Only the supplied reference was inspected; no lantern art, production proof, PX2 state, or provider request was created. All production steps below are proposals for later work.

The user requires partial transparency and selective anti-aliasing to remain part of the new props. The user has not specified a fixed palette, target engine, display scale, mounting type, or animation. Those omissions do not prevent this approach from being completed.

**Reference findings — measured and visually inspected.** The supplied [translucent-reference.png](translucent-reference.png) is a single-frame, 32 × 32 RGBA PNG. Its nonzero-alpha bounds are `[6, 3, 26, 28)` in zero-based coordinates: 20 × 25 pixels. It has 420 visible pixels, comprising 390 opaque and 30 partially transparent pixels; the other 604 pixels are fully transparent. There are three visible RGB colors and five visible RGBA combinations. The local checker reports five visible colors because alpha differences count separately.

| Measured RGB | Alpha / pixel count | Visual role inferred from inspection |
| --- | --- | --- |
| `#25354A` | 255 / 180 | Dark blue structural border and upper prongs |
| `#56B5BC` | 255 / 186 | Broad cyan interior |
| `#56B5BC` | 96 / 15; 160 / 15 | Selected softer side edges |
| `#F4DDA2` | 255 / 24 | Two small cream rectangular accents |

The partial-alpha pixels occupy exactly the vertical strips at x=6 and x=25, both from y=11 through y=25. Their alpha values are about 38% and 63%, respectively. The broad cyan interior is opaque; describing the entire reference as translucent glass would overstate the evidence. The user's stated intent establishes that these softer edges are authored treatment to preserve.

The native image and 8× nearest-neighbor inspection views were viewed, including composites over light `#F0F0F0`, dark `#202028`, and a gray checkerboard. The cyan strips respond to the background while the structural pixels remain crisp. The right strip is stronger than the left. On the dark test background, the blue frame has lower contrast; the cyan center and cream accents carry more of the readability. These local previews were constructed in memory and are not retained deliverables or evidence of engine behavior. The reference suggests a frontal, blocky presentation; it does not establish an isometric projection or a reliable global lighting direction.

**Proposed lantern treatment.** Use a compact frontal lantern with a recognizable handle, cap, rectangular illuminated chamber, and stable base. Start on the reference's 32 × 32 canvas with a comparable visual footprint and transparent margin. This is a proposed working size, not a confirmed project standard. Use broad pixel clusters and sparse interior detail so the handle and lit chamber read at native size.

Use the dark blue for the solid frame, cyan for the chamber, and restrained cream highlights or a small light core. Additional material shades or warmer light colors may be introduced where they improve the match and readability. Judge their relationships and visual hierarchy rather than enforcing a color count or exact hex whitelist. Avoid inferring physically accurate glass, bloom, or dynamic illumination from this tiny reference; begin with the light appearance authored into the sprite.

Keep the frame and essential silhouette edges opaque. Place selective anti-aliasing and partial-alpha coverage deliberately along chosen chamber boundaries, initially testing narrow cyan side strips with the reference's opacity strengths. Their locations and coverage should follow the lantern's geometry; matching the exact 30-pixel count is not a goal. Other alpha values remain available where visually justified. Retain a full alpha channel through editing and export. Do not threshold it to binary alpha, flatten it onto a matte, replace it with dithering, or apply blanket smoothing. Use nearest-neighbor enlargement for review so the authored edge pixels remain visible; runtime filtering is a separate presentation choice to verify.

**Production sequence and representative proof — planned, not executed.**

1. Establish the intended on-screen size and representative scene or UI background before finalizing the canvas and contrast. Propose a bottom-center anchor for a standing prop; use a handle attachment point if its actual role is hanging. Keep a single static view as the initial sample scope.
2. Author one lantern sample with separate editable structure, chamber/light, and selected soft-edge regions. Preserve the reference alongside it. Define the soft-edge mask and protected opaque regions before the edge pass. Keep RGB choices editable and alpha policy independent of them.
3. Test one question: does the lantern retain the reference's crisp structure and localized softness while reading as a lantern at its intended size? Review the sample beside the reference at native size and integer zoom, on light, dark, checkerboard, and the actual target background. The observable criteria are a recognizable handle and lit chamber; distinct structural and light clusters; softness confined to intended regions; and no unwanted matte halo, missing edge, or broad blur. A failure calls for revising that sample before extending the prop family.
4. Measure dimensions, bounds, clipping, and alpha distribution. Use PIXL's `asset-check` with `alpha: full` and no palette restriction; set expected dimensions only once the sample size is settled. Verify that partial alpha survives PNG round-trip export and that the edge pass leaves protected structural pixels unchanged. Measurements inform the review; counts alone cannot pass its visual criteria.
5. When the destination is known, test the actual imported sample at its intended display size. Propose a straight-alpha RGBA PNG source and explicitly reconcile any importer conversion with the renderer's blend mode. Check the same edges on light and dark backgrounds after import, including color-space behavior, texture filtering, and atlas padding if an atlas is used. Confirm that alpha is neither discarded nor multiplied twice. Engine behavior remains unverified until this test is performed.

The smallest future proof is that one lantern sample plus its background comparisons and an import check when available. No batch, animation, emission map, or additional material channel is needed to answer the present question. A visual sample review and an engine result must remain separate findings.

**Method basis and limits.** Local PIXL source discovery verified the installed corpus bytes on 2026-09-14. The selected methods are `selective-edge-aa` and `alpha-contract`; their complete compiled contexts and bounded receipt entries were read from the packaged resources.

- `selective-edge-aa` supports restricting authored edge edits to chosen regions and checking representative backgrounds. Its prerequisite edge ramp and mask are proposed per-sample authoring choices here. The source's strict-palette example does not impose a palette on this project. Relevant exact text: [PIXEL-ART-DEEP-RESEARCH.md](.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-DEEP-RESEARCH.md), lines 590–632 and 907–919. Its bundled `selective-aa-boundary` receipt proves edit locality and fixture color membership; it does not prove perceptual quality or arbitrary-background suitability.
- `alpha-contract` usefully separates alpha policy from RGB membership and calls for consistent compositing. Its bundled `alpha-compositing-contract` receipt tests linear numeric straight/premultiplied equivalence and detects double multiplication. It does not test display transfer functions, a GPU, or an importer. The method's cited original passages were also retrieved: deep-research lines 945–977 and 1276–1291 concern material channels and alignment, while [PIXEL-ART-ASSETS.md](.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-ASSETS.md) lines 942–958 are a CSS heart example. Those passages do not directly establish the full compositing procedure; treat the compiled method and bounded fixture as local guidance, with the lantern's actual import proof still outstanding.

Evidence identities for resumption:

- Reference SHA-256: `bda5c9b18e38b60a617877de6e9df6c5bf8e040410e9dfbe6bc85ca501b17132`.
- Deep-research source SHA-256: `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`.
- Asset-archive source SHA-256: `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`.
- [Bundled POC report](.agents/skills/pixl-kit/resources/evidence/art-methods/poc-report.json) SHA-256: `9972632317a17f66d48314feff94d7832c1d5a83db9f7cfaf588a6e703af6e79`. Its passing entries are pre-existing offline fixtures, not proofs executed for this lantern.

The project-root MCP context calls initially reported `file_missing: e.alpha-contract: evidence/art-methods/poc-report.json`. Both contexts were then retrieved successfully through the selected Python interpreter and bundled runner with the packaged resources directory explicitly supplied as `--root`. No source or receipt was amended.

**Next decision for production.** Set the lantern's intended display context: its on-screen size and representative background/engine destination. That determines final scale, contrast, and the import proof. Until then, the 32 × 32 frontal static proposal is a useful starting point. No further user decision is needed to complete this Markdown evaluation, and no fixed-palette approval is required.
