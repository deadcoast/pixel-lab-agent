# Matching drone approach

Keep the 16×16 canvas, two-pixel dark frame around the teal body, and two detached antenna islands. The supplied drone has room for both eyes inside that frame, with visible separation from the contour. A matching sample should be authored directly at 16×16 using this reference's proportions. The earlier robot diagnostic does not justify enlarging this drone, thinning its frame, or joining its antennas. Exact palette membership remains undecided.

This is the requested Markdown planning deliverable, dated 2026-09-14. Only reference inspection and local research were performed. No PX2 state was initialized or amended, no production artwork was created, and no provider was called. The reference review below is evidence for the approach, not production acceptance.

| Choice | Authority and treatment |
| --- | --- |
| 16×16 canvas | Confirmed by the user; preserve throughout authoring. |
| Two-pixel dark body frame and teal body | Confirmed by the user; protect the frame's thickness and the body's color identity. |
| Two detached antenna islands | Confirmed by the user; treat both as intentional features. |
| Specific proportions, eye placement and observed swatches | Measured from the reference; proposed starting geometry and colors for the matching sample. |
| Fixed palette | Not approved. Do not impose a three-color maximum, exact membership test, or project-wide palette. |
| Final display scale and game backgrounds | Unspecified; needed for a later review in context, not for completing this plan. |

The inputs reviewed were [small-separated.png](small-separated.png), [old-assessment.md](old-assessment.md), and [SESSION.md](SESSION.md). The old assessment describes a different robot reduced from 32 pixels using nearest-neighbor sampling. Its reported eye/contour collision is a useful warning to examine interior space, but its universal 32-pixel minimum, single-component rule, and palette lock are unapproved agent proposals. It contains no measured drone result or engine test. The user's present instructions govern this approach; the old note remains historical evidence.

The reference was viewed at native size and at 32× nearest-neighbor enlargement using an in-memory inspection view. The enlarged view shows a rectangular dark frame, flat teal interior, two pale eye pixels, and two square antenna islands. Native presentation is very small; readability on the eventual game background remains unverified. The local PIXL asset check passed the requested 16×16 dimension and binary-alpha checks, with no palette constraint supplied. Its result explicitly does not verify visual quality or engine import.

| Reference measurement | Observed result |
| --- | --- |
| File identity, SHA-256 | `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c` |
| Image | One 16×16 frame; 88 visible pixels; 168 transparent pixels; no fractional alpha. |
| Occupied bounds | x=3–12, y=2–13; PIXL reports the exclusive-end box `[3,2,13,14]`. |
| Opaque components | Three under both 4- and 8-neighbor connectivity: body 80 pixels, each antenna 4 pixels. |
| Body | 10×8 rectangle at x=3–12, y=6–13. |
| Frame and interior | Two-pixel frame on all four sides; 56 frame pixels around a 6×4 interior at x=5–10, y=8–11. |
| Eyes | One pixel each at (6,9) and (9,9), separated by two teal pixels; each retains at least one teal pixel between it and the frame. |
| Antennas | 2×2 islands at x=5–6 and x=9–10, y=2–3; two empty rows separate them from the body, and two empty columns separate the islands. |
| Observed colors | Dark `#25354A`: 64 pixels; teal `#56B5BC`: 22; pale `#F4DDA2`: 2. All visible alpha values are 255. These are observations, not an approved palette. |

Coordinates above are zero-based and inclusive except for the explicitly identified PIXL bounding box. Pixel-coordinate inspection supplements PIXL's aggregate measurements. The frame occupies 70% of the body rectangle, so detail space is limited, but the existing two eyes fit without touching the frame. Preserve that economy of detail. Opaque connectivity combines all visible colors; the two eye pixels are semantic features inside the body, not additional detached opaque islands. Neither color singletons nor intentional antenna islands should be removed as automatic cleanup.

The proposed production sequence is:

1. Author one static representative drone directly on a 16×16 transparent canvas. Start with the measured 10×8 body, 6×4 interior, eye positions and antenna spacing. Protect masks for the frame, teal interior, each eye and each antenna. Keep the blocky corners and flat treatment seen in the reference; additional greebles or shading would need to earn their limited pixel space.
2. Use the reference's dark/teal/pale color relationships as a provisional starting point. Sampling its swatches for this sample does not adopt an exclusive palette. Match the teal body and strong eye contrast; judge any later color adjustment by those roles and the intended background. Exact-color enforcement is applicable only if the user later chooses a scoped palette.
3. Review the sample alongside the reference at native size and integer nearest-neighbor zoom. Use silhouette inspection for body proportions and antenna gaps, then the colored image for eye separation and the frame/interior relationship. Inspect on representative light, dark and busy game backgrounds at the intended display scale. Neutral backgrounds may be useful diagnostics but cannot substitute for the game context.
4. If eyes or antennas become hard to read, revise detail placement or color contrast within the established canvas, frame thickness and detached-island design. Do not carry a larger canvas or connected silhouette forward as a presumed fix. Keep failed trials and their specific defects for comparison before expanding into variants or animation.

For that future sample, declare these review criteria before judging its result:

| Criterion | Evidence required |
| --- | --- |
| Geometry matches the chosen aesthetic | Measure 16×16 canvas and two-pixel frame; inspect body, eye and antenna masks. |
| Intentional separation survives | Confirm the body and two antenna islands remain separate, preserve the proposed two-pixel gaps, and flag unexplained new islands. A count alone cannot identify the correct features. |
| Face stays legible | Inspect both eyes individually at native and target display sizes; keep their separation from each other and the frame. |
| Teal body and dark frame remain distinct | Inspect the colored image on the intended backgrounds. A silhouette or palette count cannot establish this. |
| Reference edge treatment is matched | Check the proposed binary transparency and crisp edges for accidental resampling artifacts; this is reference matching, not a universal ban on authored antialiasing. |

The smallest remaining proof is that one matching static sample viewed in context. It was deliberately not produced in this planning session. Production acceptance, animation continuity and target-engine sampling/alpha behavior have not been evaluated. No engine test is a prerequisite for accepting this Markdown deliverable.

PIXL research selected `semantic-clusters` for preserving meaningful disconnected features and `silhouette-readability` for the future visual review. The former requires an explicit connectivity rule and semantic masks; both connectivity rules were measured here, and the feature coordinates above supply the proposed masks. The latter requires viewing scale, backgrounds and named landmarks; the landmarks are identified, while the final scale/background prerequisites remain open. `palette-contract` was researched but is inapplicable as an enforcement step because its approved-palette prerequisite is absent. `edge-rhythm` was screened: it cautions against smoothing away intentional corners and supplies no reason to regularize this rectangular reference.

The packaged source inventory verified local byte identities. The three selected method context packets were retrieved with their dependency closures, and these cited passages were read with expected-hash verification:

| Method | Exact bundled source ranges and applicability |
| --- | --- |
| `semantic-clusters` | [PIXEL-ART-DEEP-RESEARCH.md](.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-DEEP-RESEARCH.md), lines 1402–1445 and 857–867: semantic feature descriptions and rejection of unintended noise or destruction of identifying features. Intentional details remain permissible. |
| `silhouette-readability` | Same research file, lines 857–867 and 1563–1573; [PIXEL-ART-ASSETS.md](.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-ASSETS.md), lines 11–15. These discuss identity, context-dependent changes and clarity at relevant size. The latter is a UI example, not a drone specification; the animation discussion supplies no static size minimum. The background-review procedure comes from the compiled method. |
| `palette-contract` | Research file, lines 767–804 and 1538–1550; asset archive, lines 2677–2683. These describe declared ramps, approved-palette validation and a particular CSS palette. That CSS example does not set this drone's colors; none of these passages grants project-owner approval. |

Source SHA-256 identities: research file `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`; asset archive `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900`. The installed [POC receipt](.agents/skills/pixl-kit/resources/evidence/art-methods/poc-report.json), SHA-256 `9972632317a17f66d48314feff94d7832c1d5a83db9f7cfaf588a6e703af6e79`, records passing bounded checks for connectivity, key landmarks and palette membership. Its limits are explicit: connectivity does not determine semantic importance, geometric landmarks do not prove recognition, and palette membership does not judge palette taste. Those receipts were read, not rerun or promoted to drone acceptance. They provide no universal thick-outline size rule, single-component mandate, provider guarantee or engine result.

No further user decision is necessary to use this approach. When work advances to a sample review, the useful next input is the intended display scale and representative game background. A fixed palette can remain open; only a future decision to enforce exact colors requires explicit palette selection and scope.
