# Approved sample through family delivery

Use this operation when extending a reviewed representative sample into related assets, comparing their continuity, retaining a delivery package, or resuming an existing family. It governs PIXL production. A developer maintaining these instructions remains in the development role.

## Start with the actual saved family

For authoring, begin with `context STATE TASK_OR_OUTPUT_OR_PLAN --view authoring
--root ROOT` (`pixl_context` with `view: "authoring"`). Optionally supply `--plar
PATH --asset ID` / `plar_path` and `asset_id` for the selected requirements. This
index exposes literal current criteria, contracts, choices, decisions, source
retrieval arguments, prerequisite nominees and relevant pending intents. Sources
are indexed once; retrieve the relevant original lines before interpreting their
authority. Connected-plan entries return the exact `request_review` arguments.
The index omits proof history and embedded provider payloads; it neither approves
a nominee nor replaces the full workflow/jobs checks below. Source drift stays
visible so the caller can orient itself before repair. Default `context` still
returns its complete wire dependency closure and never truncates to fit a budget.

Read the [PX2 specification](../../../resources/spec/PIXL-2.md) and [registry](../../../runtime/pixl/registry-v2.json), including their family extension. Discover the installed runner's help or MCP schemas before using the operations below. Existing PX1 and older PX2 projects retain their declared semantics; do not manufacture a migration by relabeling their headers.

Gather the brief and sources, target use, actual sample bytes and verdicts, confirmed style choices, applicable adoption decisions and proofs, member inventory, destination choices, and authorized provider scope. Read `workflow STATE --root ROOT`, `family STATE [OUTPUT] --root ROOT`, and `jobs STATE --root ROOT` before extending or retrying existing work. `family` verifies retained files and reports current selection, requirements, pending jobs and historical snapshot drift. It changes no state.

Open the exact nominated sample X and its retained observations. Confirm its sample task is done and that its passing verdicts answer the family-relevant question. A replaced or rejected candidate cannot serve as the approved baseline merely because its old PNG remains. A sample that demonstrated a front idle pose does not establish all-direction walk contacts or diagonal tile seams; use the [sample operation](intake-sample.md) to exercise that uncertainty before scaling it.

When a corrected contract follows an earlier delivery, identify which review actually
adopts the sample for this family. Preserve the earlier contract/verdicts; evaluate
the retained bytes against the new saved criteria before claiming new acceptance.
For linked PLAR stages, the connected plan's optional `selection.replaces` names
the exact current store/task/output link. After resolving earlier pending intents,
author a new plan ID with that explicit replacement and current state hash. The
adapter retains the old generation and allocation history. This route also supports
reuse with new review criteria; no provider job is invented for unchanged files.
The same image can remain useful without another generation. Record the baseline's
exact identity, the caller's scoped style decision and which properties carry into
later members. A completion glyph may establish edge treatment and color roles; it
does not prescribe the other members' silhouettes or prove their motion/meaning.
The caller may resolve expert design choices within its delegated assignment; do
not invent a separate owner approval when that authority was already supplied.

Inventory available and missing members before collective review. A sample decision
and a comparison with an existing control can be complete while the family remains
unfinished. Keep missing members planned, with concrete next work; do not create a
passing family snapshot or silently remove them from the family to finish a report.

## Save the members and collective requirements first

For a new family or staged seed → animation/edit workflow, prefer the
[connected authoring operation](../../../resources/spec/production-plan.md).
`production-plan` / `pixl_production_plan` takes reviewed stages, existing contracts,
baseline, adoption and destination choices, then writes the dependency graph and
explicit PLAR links. For delivery of already accepted outputs, use `stages: []`
and name their existing output IDs as delivery members. The baseline and ordinary
family requirements still apply; authoring does not accept the package or invent
a provider request. It leaves all work open. Once inputs are accepted,
`stage-prepare` / `pixl_stage_prepare` binds their exact bytes and the reviewed
official request before the normal durable-job workflow. Use the returned IDs;
do not reproduce the same wiring manually. Existing linked generations and unusual
amendments keep the explicit saved-state/revision route below.

Pass the returned `request_review` arguments to `pixl_request_review` and save its
report. It contains the exact member **and collective** Q identities, literal
clauses, cited source excerpts, controls and any prepared request. Complete the
[request and criteria handoff](request-review.md#connected-family-and-stage-handoff)
with the caller before adopting those interpretations. A grouped statement that
the family preserves style or geometry is not a comparison of its individual
rejection rules. Method-specific criteria can be useful; state their actual scope
without attributing the construction to the owner. Preserve required qualitative
outcomes when correcting an overly specific recipe.

Use the normal decode/edit/encode/validate/expected-hash commit sequence. Record only fields defined in the current specification. Before files exist, save F plans rather than invented X identities.

1. Each production F names the exact sample candidate through `bs`. Its producer T lists that X in `ip` and the sample T directly in `dp`. Retain the applicable contract, confirmed choices, adoption D and executed proof; the baseline link does not replace those requirements.
2. Make a delivery T and a report-kind F. Set this F's `bs` to the same sample, `mb` to the distinct ordered member F IDs, and `ds` to the same project's destination I choices. The sample output itself may be a member. Other members must be production outputs with the same baseline. List every producer as a direct prerequisite of the delivery T and the baseline X as its input. A family cannot contain itself or another family delivery.
3. Define member Q criteria and separate collective Q criteria before results. The family needs a continuity criterion with an observable condition and appropriate evidence mode. State the actual comparison: for example, consistent equipment placement across the requested directions, grounded feet across the cycle, or matching shared boundaries across the required tile transitions. Add engine criteria when required by this destination; a target name alone does not create an engine verdict.
4. Save destination choices with their sources, owner and rationale: target project and version, intended paths/names, slicing or tile mapping, pivots, timing, sampling, scale, alpha or atlas rules as applicable. Missing choices remain unresolved; observed/proposed values remain distinct from confirmation. Such choices block delivery activation/completion, while useful member files can still be retained.

Commit this plan before collecting verdicts. Keep the project's actual dimensions, style and acceptance conditions; example values are not defaults. `ready` and `workflow` apply activation blockers. Retaining a package has narrower prerequisites and does not grant production adoption or delivery acceptance.

## Produce members, compare them, and preserve rejection

Run the [provider recovery operation](provider-recovery.md) for each required real generation attempt. It saves the exact request before dispatch and imports actual downloaded bytes as an unaccepted candidate. Read the family report as well as jobs: a member or baseline attempt may be outside the delivery task's forward context packet. For `prepared`, `unknown`, `submitted` or `running` work, resolve the reported action before another attempt or snapshot. An unknown attempt requires the saved request/history and actual provider reconciliation; missing service access leaves that attempt unknown. Do not invent a job ID or infer that a request was never received.

Evaluate each member against its own requirements and approved baseline. Keep mechanical measurements, visual observations, temporal or neighborhood comparisons, and engine results separate. A contact sheet is useful comparison evidence, but the actual task determines the required additional inspection:

| Family | Inspection to perform and retain |
| --- | --- |
| Static sprites or variants | Compare actual members and baseline at native scale and enlarged scale; inspect silhouette, volume, equipment landmarks, palette/ramp use, lighting and edge treatment against this project's contract. |
| Animation or directions | Play the actual sequence at its intended timing, including loop boundaries and required direction changes. Inspect contact poses and individual frames for anchor drift, sliding, volume changes and direction mapping. Save which files/frames, playback timing, context and observed defect or pass condition support the verdict. |
| Tiles or transitions | Assemble repeated neighborhoods using the actual members, including the edges, corners, diagonals and material transitions this game requires. Inspect seams, repeat visibility and projection in those arrangements. Retain the arrangement/mapping and images or observations identifying the compared files. |

A dimension or palette check cannot supply these visual judgments. If playback, neighborhood assembly or visual access is unavailable, retain that precise boundary and leave its criterion unavailable/unperformed. Do not write a passing visual receipt for an unseen artifact. When an inspection fails, retain X/E/V and its actual defect, create a revised X at a new path, inspect the revision, and nominate it only with its own current evidence. A successful generation request does not answer the member's acceptance criteria.

For timed consumers, retain the frames actually painted during a live loop and
their observed clock values, including wrap. Calculated boundary crops alone do
not show that the running view advanced. Check those pixels against the retained
sheet and inspect the sequence separately for motion quality. A mechanically
correct clock can still play a visibly hesitant or morphing sequence.

## Retain and review the exact delivery

When the baseline is still eligible and every planned member has a nominee on a done task, inspect the family report for pending jobs and blockers. The delivery task must be open or active for retention. Invoke:

```text
family-snapshot STORE OUTPUT CANDIDATE --expect HASH --root ROOT
family STATE OUTPUT --root ROOT
```

MCP equivalents are `pixl_family_snapshot` with `store`, `output_id`, `candidate_id`, `expect`, and `pixl_family` with `path` and optional `output`. The server supplies the project root. Reload and reconcile after a stale-hash error; do not overwrite state or repeat remote generation.

Snapshot retains actual member copies and a canonical manifest under the store's content-addressed `deliveries/` directory, then publishes a new manifest X with its exact constituent references. Its `accepted: false` means retention created no nomination, verdict or task completion. `remote_executed: false` describes this local operation. Read the resulting manifest and report, verify member order and copied-file identities, and use the copied files for collective review and destination testing. A successful copy does not demonstrate continuity.

Nominate the intended manifest candidate through the normal saved-state operation. Evaluate each collective Q against this exact manifest, baseline, copied members, destination choices and current plan. Retain actual observation files, then bind E/V to the full candidate/criterion semantic scope. Save a continuity failure independently from per-member passes. Revise the implicated member and repeat its checks, then take a new snapshot; preserve the rejected family candidate and observations.

Published manifest candidates and their constituent X identities are immutable. Member selection, baseline, membership or destination changes leave old packages intact. Reopen affected completed work and supersede stale verdicts/receipts, save the changed plan, and evaluate a new snapshot. The report identifies drift; recomputing an old receipt hash cannot make a historical package current.

## Destination boundary and cold handoff

For collective and destination judgments, prefer `pixl_review_context` followed by
`pixl_candidate_review` on the saved manifest candidate, using the
[candidate/family review contract](../../../resources/spec/candidate-review.md).
For a matching queue consumer, use the shipped [isolated execution operation](consumer-execution.md)
to capture, check and import its exact delivered files in one invocation.
When the project runner can supply a structured report, use
`destination-import STATE CANDIDATE REPORT_JSON --out FRESH_DIR --root ROOT`
(or `pixl_destination_import`) with the
[destination observation contract](../../../resources/spec/destination-observation.md).
Export the candidate's current review context first. The report identifies that
exact manifest and binding, destination bytes, renderer and consumer sources,
viewport, views, actual motion samples and all output files. The import verifies
and retains those declared bytes in a bounded ZIP with PNG previews; it neither
runs the renderer nor attests that anyone viewed the result. An incompatible
package, changed file or stale binding is a refusal, not a passing observation.

Open the relevant retained previews and actual playback evidence. Use the returned
`observation` entry (the complete bundle) in candidate-review, adding the specific
viewed previews as needed. Keep unavailable motion and runner limitations explicit;
report consistency alone cannot supply artistic or destination acceptance.

Bind actual viewed files and renderer reports to their hashes, state each literal
criterion's judgment and limitations, and explicitly choose record, nominate or
complete. The operation handles evidence bindings and lifecycle publication; it
does not run the renderer or judge the pixels. `snapshot_acceptance` remains the
immutable package-creation status; `current_acceptance` and task status describe
subsequent review. Read both without rewriting the original manifest.

Use the target engine and the retained files to exercise the applicable import behavior: frame slicing and order, pivots/contact alignment, timing and loop transitions, direction mapping, texture sampling/display scale, alpha/atlas edges, tile neighbor mapping, or required material/lighting behavior. Record the actual engine/project version, files tested, settings and observed outcome. Metadata inspection alone does not establish engine acceptance.

Exercise the real consumer path, including backend transitions and every assigned
shared view, rather than drawing the asset in an unrelated preview. If an existing
representative fixture only supplies source descriptors, an explicitly scoped
graphical entry point can make those modules executable. Bind captures to the
actual modules, image bytes and renderer version; report this fixture's observed
behavior without claiming another project's engine acceptance. Preserve missing
or failed states visibly. Browser screenshots, pixel/compositing measurements and
the specialist's visual judgment answer different questions; retain each as needed.

Prefer the project's existing isolated capture/integration command for that
execution. Review the resulting actual playback sequence and native/enlarged
images through available image tools. Desktop control is one optional observation
route, not a prerequisite for family or destination acceptance. A supplemental
playback surface can cover a missing review scale, but keep it distinct from the
actual destination run and verify it uses the same asset bytes and timing.

If the engine or target project is unavailable, still deliver links to the retained manifest and useful files. Record an unavailable V with `ev=[]` and the precise missing capability; keep delivery unfinished. Leave the concrete next action, such as importing the named copied sheet into the specified target scene, applying the saved slice/pivot/timing settings, and playing the listed loop and direction transitions. State that destination acceptance is unverified. Do not turn missing engine access into a visual rejection or a fabricated live receipt.

Commit a handoff containing the state path and observed revision/hash, family output and manifest candidate, package and copied-file locations, baseline and selected member IDs, relevant failed/unavailable verdicts, pending job IDs and last observed states, and the next task with its required context and action. An N record can point to the retained records/tasks; retain the human-readable instructions in project evidence as needed.

A cold session starts with `family`, `workflow` and `jobs` against that root, then retrieves focused `context` and opens the cited artifacts and observations. Reconcile unknown jobs first, review reported plan/selection drift before new evaluation, and execute only the outstanding check or revision. Mark the delivery T done only after every declared criterion on its current nominee passes and prerequisites are done. Finish with the useful files, actual verification, unresolved limits and actionable handoff, without claiming art quality or engine readiness from local fixtures.

## Give a consumer the named package

For integration without reading internal state records, request the
[consumer deliverable index](../../../resources/spec/deliverable-index.md):

```text
family STATE OUTPUT --view consumer --root ROOT --result-path FRESH_INDEX_JSON
```

Use MCP `pixl_family` with `path`, explicit `output`, `view: "consumer"` and an
optional fresh consumer-relative `result_path`. Omit `candidate` to select the
current nominee; use CLI `--candidate` / MCP `candidate` only to inspect a specific
retained package. A missing nominee returns no package and an unresolved reason;
it does not choose the latest snapshot. The default complete family report remains
the route for full history.

Open the exact saved JSON. Give the caller its manifest, each `assets[].path` and
any `integration.sources[].path` required by the saved destination or member
contract choices. Check the named hashes and byte lengths when transferring them.
Preserve the exported relative layout or retain an explicit verified copy mapping.
A package-only caller can use those files, names, contracts, choices, sources and
current review without opening `state.px`. Producer state/refresh locators remain
available for later continuation; they are not prerequisites for reading the handoff.

Use `integration.choices` for the actual recorded key, value, status and rationale;
open its cited source files before interpreting slicing, frame order, timing or
pivot behavior. An authored consumer module may hold that contract. Transfer the
exact cited module when it is needed; do not substitute an inferred layout.
The index's `metadata` preserves opaque X.mt with `not_interpreted` or
`not_declared` layout status. Dimensions, kind, filenames and lineage alone do not
supply missing frame, timing or pivot facts. Old/current source and choice bindings
stay visible; unresolved or unavailable source information needs explicit follow-up.

Read `package.creation_acceptance` separately from each candidate's current
`review`, the family's `current_eligible` and `unresolved`. An old package's
creation `accepted: false` remains recorded after later review;
a current eligible result covers only the saved declared criteria at this state
hash. Package validity, metadata and transfer checks do not run the consumer or
supply artistic, engine or human acceptance. Retain the exported index and refresh
through its exact arguments after relevant producer-state changes.

## Saving family results

Use MCP `result_path` or CLI `--result-path` on family, family-snapshot and
candidate-review to retain exact result JSON under a fresh consumer-relative path.
Read the returned file when comparing the immutable snapshot with current
acceptance. A post-publication export error retains `operation_result`; reconcile
current state before retrying. Never hand-copy JSON paths from a tool transcript.

## Visible asset lineage

Read the `lineage` next to each delivered member in `family` or `review-context`;
use the exact candidate IDs for the historical package being discussed. Fresh PLAR
reads and handoffs also expose nominated candidate and family member lineage.
Follow the retained job, request and evidence references before describing an
origin. Separate a generated seed, a provider edit, a deterministic construction,
and reuse of existing bytes. One asset can involve several of these operations.

Keep the reported evidence limits visible. A validated journal proves local
retention and consistency of caller observations, not authenticated provider
execution. A baseline or task input is not automatically a pixel parent, and
matching hashes establish equal bytes without selecting an ancestor. Missing
relationships remain unknown. Preserve controlled-fixture provenance even when
its request names a generation tool. A corrected deterministic Working animation
must not be described as successful generative animation merely because an earlier
animation attempt exists in the project.

Lineage does not create acceptance or authorize more generation. Preserve saved
state, old manifests and prior handoffs while reading it. If the compact caller
view returns `delivery_ref` or `resume_ref`, resolve the exact saved report and JSON
pointer before summarizing the delivered members.
