# User brief (verbatim, 2026-09-14)

> Make a character family matching this project, using PIXL. The supplied
> references disagree about outline treatment and I have not chosen the final
> canvas size. The family will have a scout and a medic for a side-view game.
> References are reference.png and reference-b.png. Begin the project and make
> the progress possible in this session.

## Constraints stated by the session environment

> This is an isolated PIXL evaluation project. Work only in this project. The
> packaged PIXL skill and runtime are available under .agents/skills/pixl-kit.
> The selected Python interpreter is
> C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe. Local
> PIXL tools are supplied by the session MCP configuration. Input images are in
> the project root. Do not install packages or change host settings.

## What the user stated explicitly

- Asset family: characters, two members, a scout and a medic.
- Destination: a side-view game.
- Style authority: the two supplied references ("matching this project").
- Declared open: outline treatment (references disagree).
- Declared open: final canvas size (not chosen).
- Scope for this session: begin the project, make the progress that is possible.

## What the user did not state

- The target canvas size, or the display scale the game renders at.
- Which outline treatment wins, or whether the disagreement is a style split
  (for example, outline for actors and no outline for background props).
- The destination engine and its import requirements.
- The backgrounds these characters are shown against, which is the evidence the
  outline decision actually depends on.
- Animation requirements, directions, or frame timing.
