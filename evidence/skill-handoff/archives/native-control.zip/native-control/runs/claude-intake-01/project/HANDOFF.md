# Handoff — side-view scout and medic family

State: `.pixl/state.px`, PX2 revision 2, hash
`0951d7be64fe4e8d9b63f6c6baa9b29540142d4d6c5afb75594d9ff689434a14`.
Resume a cold session with `pixl_workflow` on that file, then read
`work/poc/outline-canvas-report.md`.

## What is done

- **Project created** with 12 recorded intake choices, separating what you
  stated, what was measured from the references, what is proposed, and what is
  still open.
- **Research task `t_research` is done.** It proved how outline treatment and
  canvas size constrain each other, and both its criteria pass with retained
  evidence.

## What is blocked and why

| Task | Phase | Blocker |
|---|---|---|
| `t_scout` | sample | `f_scout` has no concrete raster contract, because canvas size is unresolved and outline treatment is in conflict |
| `t_medic` | production | waits on `t_scout`, plus its own adoption decision |

No sprite was generated. **PixelLab is not connected in this session** — the
only MCP tools exposed are the local `pixl-local` ones. `pixl_capabilities`
lists PixelLab tools but reports `live_discovery: false`, so it is dated
documentation, not a callable surface. No job was prepared, dispatched or
imported, and no remote identifier exists.

## The three questions that unblock production

1. **What backgrounds does the game render these characters against?** This is
   the one that matters most, and it is a question about your game rather than
   about the art. The proof found that neither reference wins outright: the
   outlined version loses its two upper prongs against a dark field, and the
   unoutlined version loses its body edges against a field sharing its teal.
2. **What canvas size?** Not independent of question 1's answer. A 2 px inset
   outline like `reference.png` works at 32, is marginal at 24, and breaks at
   16 — at 16 the interior falls to 25% and the eyes collide with the contour.
   If you want a canvas of 16, the outline must drop to 1 px, which visibly
   changes the look because the reference's solid-navy prongs gain a teal core.
3. **Which engine?** Every engine criterion stays unavailable until one is
   named, so nothing can be called game-ready.

A proposal is recorded but untested (`i_outline_color`): pick the outline colour
for contrast against your actual backgrounds rather than fixing it at the
reference's `#25354A`. Both observed failures were failures of that one navy
against one background, not of outlining as such.

## Answer shapes that unblock immediately

- "Backgrounds are mostly dark interiors, canvas 32" → outline treatment
  resolves toward no outline, or an outline in a lighter colour; `i_edges` and
  `i_canvas` become confirmed, a contract can be instantiated, `t_scout`
  activates.
- "Canvas 16" → the 2 px outline alternative is eliminated by the proof, which
  narrows `i_edges` to no outline or a 1 px outline.

## Files

| Path | What it is |
|---|---|
| `sources/brief.md` | your instruction verbatim, plus what it did and did not fix |
| `sources/reference-observations.md` | measured geometry and palettes of both references |
| `sources/knowledge-notes.md` | the two knowledge methods used, with corpus revisions |
| `work/poc/outline-canvas-report.md` | the proof; nominated candidate `x_poc` |
| `work/poc/viewing-log.md` | what the agent actually saw, per fixture cell |
| `work/poc/checks.json` | structural check receipt |
| `work/poc/A-backgrounds-*.png` | both references on light, dark and busy fields |
| `work/poc/B-*.png` | outline thickness 2/1/0 at canvas 32/24/16 |
| `work/views/*-x12.png` | references at 12x |
| `work/build_plan.py`, `work/build_verdicts.py` | how revisions 1 and 2 were authored |

The `work/poc/B-*.png` files are agent-authored fixtures for the proof. They are
not proposed scout or medic designs and are not deliverables.

## Honest limits

- The backgrounds used in the proof are invented stand-ins. The proof shows the
  outline choice is background-sensitive; it does not pick a winner for a game
  whose backgrounds are unknown.
- The visual verdict `v_poc_viewed` records that the *agent* viewed the
  fixtures. No human has reviewed them.
- Nothing has been checked in any engine.
