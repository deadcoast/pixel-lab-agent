# Viewing log for the outline/canvas proof fixtures

Reviewer: PIXL (agent), acting in this session. Date: 2026-09-14.
Mode: visual. The acting agent opened and viewed each file listed below through
the host's image display. This log records what was seen; it is not a
measurement and it does not certify any human reviewed these images.

## Files viewed

| File | Scale viewed |
|---|---|
| `reference.png` | native 32x32 |
| `reference-b.png` | native 32x32 |
| `work/views/reference-x12.png` | 12x nearest |
| `work/views/reference-b-x12.png` | 12x nearest |
| `work/poc/A-backgrounds-native.png` | native |
| `work/poc/A-backgrounds-x10.png` | 10x nearest |
| `work/poc/B-outline-cost-x11.png` | 11x nearest |

## Fixture A — observed, per cell

Rows: outlined `reference.png` then unoutlined `reference-b.png`.
Columns: light, dark, busy.

- **Outlined / light.** Full silhouette present. The navy reads as a crisp
  contour; the two upper prongs read as solid dark shapes against the pale
  field. Both eyes clearly separated. **Pass.**
- **Outlined / dark.** The navy contour sits close enough to the dark field that
  the outer edge stops registering. The prongs, which are solid navy with no
  teal core, come close to disappearing into the background; what reads instead
  is the teal torso alone. The figure appears smaller and a different shape than
  it is. **Fail**, on the landmark check: the prongs are an identity landmark
  and they do not remain visible.
- **Outlined / busy.** The navy separates the teal torso cleanly from the grey
  checker. The prongs weaken where they cross the darker checker cells but stay
  traceable. Both eyes hold. **Pass.**
- **Unoutlined / light.** Full silhouette including both prongs reads clearly.
  **Pass.**
- **Unoutlined / dark.** The strongest cell in the dark column. The whole form,
  prongs included, separates from the field. **Pass.**
- **Unoutlined / busy.** The body's left and right edges dissolve where they
  cross the vertical band whose hue is near the sprite's own teal. The form
  stops being separable from the scene along those edges. **Fail**, on the
  separation check.

At native scale the same pattern is visible, though smaller: in the outlined /
dark cell only the teal core registers, while in the unoutlined / dark cell the
whole form registers.

## Fixture B — observed, per cell

Rows: canvas 32, 24, 16. Columns: inset outline 2 px, 1 px, 0 px. These are
agent-authored fixtures, not supplied art.

- **32 / 2 px.** Matches the reference's look, including prongs that are solid
  navy with no teal core. Interior ample, eyes well separated. **Pass.**
- **32 / 1 px.** Reads well, but the prongs now carry a teal core. That is a
  visible departure from the reference, where solid-navy prongs are a
  deliberate feature. Noted as a style change, not a failure of this check.
- **32 / 0 px.** Clean, matches `reference-b.png`.
- **24 / 2 px.** Still works. The interior is visibly squeezed and the eyes sit
  closer to the contour than at 32. **Pass, marginal.**
- **16 / 2 px.** The interior collapses. The two eye blocks nearly touch each
  other and sit hard against the outline; the form reads as a dark blob with a
  speck of teal rather than as a body with features. **Fail**, on both the
  landmark-visible and gaps-stay-open checks.
- **16 / 1 px.** The outline survives, the teal core survives, the eyes stay
  separated from each other and from the contour. **Pass.**
- **16 / 0 px.** Reads cleanly as a small form. **Pass.**

## What this log does not establish

- No human has viewed these images.
- The backgrounds in fixture A are invented stand-ins. The observations show
  that the outline choice is background-sensitive; they do not select a winner
  for a game whose backgrounds are unknown.
- Nothing here is an engine or import observation.
