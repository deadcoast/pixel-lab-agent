# Proof of concept: outline treatment and its coupling to canvas size

Author: PIXL (agent). Date: 2026-09-14. Mode: local raster fixtures, inspected
visually by the acting agent at native scale and at integer zoom.

**Status: this is research, not an adopted project decision.** No outline
treatment and no canvas size has been confirmed by the project owner.

## Question

The two supplied references disagree about outline treatment. Which treatment
should the scout/medic family use, and is that choice independent of the canvas
size the owner has not yet chosen?

## Method

Knowledge method `silhouette-readability` (compiled library index, version 1)
directs: "Compare the colored asset on representative light, dark and busy
backgrounds", checked against "Named identity landmarks remain visible at the
target size." Declared sources for that method:
`training/original-docs/PIXEL-ART-DEEP-RESEARCH.md` lines 857-867 and 1563-1573,
and `training/original-docs/PIXEL-ART-ASSETS.md` lines 11-15, in the installed
corpus whose byte identity was verified by `pixl_sources`
(`PIXEL-ART-DEEP-RESEARCH.md` sha256
`7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`). The method
was unproven for this asset before this exercise; that is what this proof
addresses.

Two fixtures were built:

- **A** — the two supplied references, unmodified, composited over light
  (#E8E8E4), dark (#1A1C22) and a busy 4 px checker that deliberately contains a
  vertical band close to the sprite's own teal.
- **B** — the reference's logical form re-authored by this agent at canvases 32,
  24 and 16, at inset outline thickness 2, 1 and 0. Proportions are scaled from
  the measured reference (body 18x26, prongs 4x6, eyes 3x4 at canvas 32).
  **These are agent-authored fixtures, not supplied art and not deliverables.**

## Acceptance stated before interpreting results

1. A treatment passes background readability only if the full silhouette,
   including the two upper prongs, stays distinguishable from the background on
   all three backgrounds.
2. A treatment passes canvas robustness at a canvas only if the interior fill
   and both eye landmarks survive and remain separated at that canvas.

## Result A — background readability

| Reference | Light | Dark | Busy |
|---|---|---|---|
| `reference.png` (2 px navy inset outline) | pass | **fail** | pass |
| `reference-b.png` (no outline) | pass | pass | **fail** |

- On dark, the navy outline #25354A is close enough to the #1A1C22 background
  that the prongs nearly disappear and the read silhouette collapses to the teal
  core. The figure looks smaller and differently shaped than it is.
- On the busy background, the unoutlined teal dissolves into the similar-hue
  band; the left and right body edges stop separating from the scene.

Neither reference dominates. Each fails on exactly the background the other
survives. Artifacts: `A-backgrounds-native.png`, `A-backgrounds-x10.png`.

## Result B — canvas robustness

Surviving interior fill as a share of the body's occupied pixels:

| Canvas | outline 2 px | outline 1 px | outline 0 px |
|---|---|---|---|
| 32 | 49% | 71% | 94% |
| 24 | 44% | 66% | 95% |
| 16 | **25%** | 47% | 92% |

- Canvas 32 / 2 px: **pass**. Reproduces the reference's look, including prongs
  that are solid navy with no teal core.
- Canvas 24 / 2 px: **pass, marginal**. Interior visibly squeezed.
- Canvas 16 / 2 px: **fail**. Interior falls to 26 px total; the eyes touch the
  outline and nearly each other; the form reads as a dark blob.
- Canvas 16 / 1 px: **pass**. Outline preserved, interior and eye separation
  survive.

Artifacts: `B-outline-cost-x11.png` and the nine `B-c<canvas>-t<thickness>.png`
files.

## Consequence

1. **Outline treatment cannot be settled before the canvas is settled.** A 2 px
   inset outline is viable at 32, marginal at 24 and broken at 16. "Keep the
   outline" and "use a small canvas" are not jointly satisfiable at the
   reference's own thickness.
2. **Outline thickness is not a free parameter either.** At canvas 32, dropping
   to 1 px gives the prongs a teal core, which visibly departs from the
   reference, where solid-navy prongs are a deliberate feature. Thickness
   changes identity, not just weight.
3. **The outline question is really a background question.** The decision the
   owner faces is not aesthetic preference between two images; it is which
   backgrounds the side-view game actually renders these characters against.
   The recorded conflict should stay open until that is known.
4. **A third option is worth putting to the owner.** Both failures are failures
   of one specific navy against one specific background. An outline whose color
   is chosen to contrast with the game's actual backgrounds, rather than the
   reference's navy specifically, would pass all three columns of fixture A.
   This was not tested here and remains a proposal, not a result.

## Limits of this proof

- The backgrounds are invented stand-ins. The game's real backgrounds are
  unknown, so the pass/fail pattern in A shows that the choice is
  background-sensitive; it does not select a winner for this game.
- Fixture B re-authors a simplified form. It measures how an inset outline
  consumes area as canvas shrinks. It is not a proposed scout or medic design.
- No PixelLab generation was performed and no destination engine was checked.
