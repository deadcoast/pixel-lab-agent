# Knowledge retrieved for this project (2026-09-14)

Retrieved from the installed PIXL knowledge corpus via `pixl_knowledge`. Source
byte identity verified by `pixl_sources`; that verification establishes local
byte identity of the installed corpus, not external truth. These files live
inside the plugin installation, so they are quoted here in a project-owned note
rather than referenced as project sources.

Corpus revisions verified at retrieval time:

| Document | sha256 | lines |
|---|---|---|
| `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md` | `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28` | 1713 |
| `training/original-docs/PIXEL-ART-ASSETS.md` | `450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900` | 16070 |

## Method `silhouette-readability`

Title: Evaluate identity using silhouette and target backgrounds.
Applies to: characters, inventory icons, interactive props.

Requires: intended viewing scale, representative backgrounds and identity
landmarks.

Procedure:

1. Render a flat opaque mask before detailing.
2. Inspect major proportions, negative spaces and landmark separation at native
   logical scale.
3. Compare the colored asset on representative light, dark and busy
   backgrounds.

Checks:

- Named identity landmarks remain visible at the target size.
- Required gaps stay open and interactive forms separate from their
  surroundings.

Pitfalls:

- Silhouette alone cannot validate faces, materials or fine symbols.
- No contrast ratio or component count proves aesthetic quality.

Declared sources: `PIXEL-ART-DEEP-RESEARCH.md` 857-867 and 1563-1573;
`PIXEL-ART-ASSETS.md` 11-15.

**Relevance here:** procedure step 3 and the first check are the direct method
for the disputed outline treatment. This project's identity landmarks are the
two upper prongs, the two cream eye blocks, and the body's outer edge.

## Method `edge-rhythm`

Title: Audit stair-step runs without imposing one contour style.
Applies to: clean linework, small curved forms, hard silhouettes.

Requires: a contour mask and declared intentional corners or irregular regions.

Procedure:

1. Trace boundary runs and highlight sudden run-length changes.
2. Regularize only contours intended to read as smooth.
3. Preserve corners, damage and organic asymmetry identified in the brief.

Checks:

- A supplied straight diagonal retains its declared repeating step pattern.
- No protected corner changes during cleanup.

Pitfalls:

- Not every uneven run is a jaggy; shape can require an abrupt change.
- Mechanical contour smoothing can erase style and identity.

Declared sources: `PIXEL-ART-DEEP-RESEARCH.md` 1402-1431 and 857-867.

**Relevance here:** both references are entirely axis-aligned rectangles with no
diagonals at all. The pitfall applies directly and in reverse: the hard
right-angle contour is the declared style, so any later generation that
introduces smoothed or diagonal contours is a style violation to be corrected,
not an improvement.

## Status of both methods

Neither method has an executed proof bound to this project's assets. Both are
research context. The outline/canvas proof of concept in
`work/poc/outline-canvas-report.md` exercises `silhouette-readability` step 3
against the actual supplied references; `edge-rhythm` remains unproven here and
is retained as context for reviewing future generated candidates.
