"""Author revision 2: the research candidate, its receipts, verdicts and handoff."""
import hashlib, json, pathlib, subprocess

ROOT = pathlib.Path(__file__).resolve().parent.parent
PY = "C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe"
RUNNER = str(ROOT / ".agents/skills/pixl-kit/scripts/pixl.py")
AT = "2026-09-14T00:00:00"
SEMANTIC_EXCLUDED = {"E", "P", "T", "J", "N", "V"}

sha = lambda rel: hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
ref = lambda i: {"$ref": i}
sym = lambda s: {"$symbol": s}

doc = json.loads(subprocess.run([PY, RUNNER, "decode", str(ROOT / ".pixl/state.px")],
                                capture_output=True, text=True, check=True).stdout)
records = {r["id"]: r for r in doc["records"]}

# ---- new records ----
new = [
    {"id": "x_poc", "kind": "X", "fields": {
        "nm": "Outline and canvas coupling report",
        "ur": "work/poc/outline-canvas-report.md",
        "dg": sha("work/poc/outline-canvas-report.md"),
        "kd": sym("report"), "of": ref("f_poc")}},
]
for r in new:
    records[r["id"]] = r

# ---- semantic closure, matching graph.scope ----
def refs_in(value):
    if isinstance(value, dict):
        if "$ref" in value:
            return {value["$ref"]}
        return set().union(*(refs_in(v) for v in value.values())) if value else set()
    if isinstance(value, list):
        return set().union(*(refs_in(v) for v in value)) if value else set()
    return set()

semantic = {i: refs_in(r["fields"]) for i, r in records.items()
            if r["kind"] not in SEMANTIC_EXCLUDED}
edges = {i: t & semantic.keys() for i, t in semantic.items()}

def scope(seed):
    seen, stack = set(), [seed]
    while stack:
        cur = stack.pop()
        if cur in seen or cur not in edges:
            continue
        seen.add(cur)
        stack.extend(edges[cur])
    return seen

def hashes(ids):
    out = subprocess.run([PY, RUNNER, "validate", str(CAND), "--root", str(ROOT)],
                         capture_output=True, text=True)
    return json.loads(out.stdout)["record_hashes"]

# ---- receipts, binding each candidate/criterion closure ----
def binding(ids, rh):
    return [{"rf": ref(i), "dg": rh[i]} for i in sorted(ids)]

EVIDENCE = [
    ("e_poc_stated", "Structural check of the coupling report",
     "work/poc/checks.json", "local", "q_poc_stated"),
    ("e_poc_viewed", "Viewing log for the outline and canvas fixtures",
     "work/poc/viewing-log.md", "visual", "q_poc_viewed"),
]
VERDICTS = [
    ("v_poc_stated", "q_poc_stated", "e_poc_stated",
     "The report fixes its question and its acceptance conditions before the "
     "result sections, and every project artifact it cites exists with the "
     "recorded hash. Citations into the installed knowledge corpus lie outside "
     "the project root and were verified separately at retrieval time."),
    ("v_poc_viewed", "q_poc_viewed", "e_poc_viewed",
     "Both fixture sets were viewed by the acting agent at native scale and at "
     "integer zoom. Every reported pass and fail names the background or the "
     "canvas at which it was observed. No human has viewed these images."),
]

for eid, nm, path, mode, qid in EVIDENCE:
    records[eid] = {"id": eid, "kind": "E", "fields": {
        "nm": nm, "ur": path, "dg": sha(path), "rs": sym("pass"),
        "md": sym(mode), "at": AT, "bs": []}}

for vid, qid, eid, why in VERDICTS:
    records[vid] = {"id": vid, "kind": "V", "fields": {
        "tk": ref("t_research"), "rq": ref(qid), "xr": ref("x_poc"),
        "st": sym("pass"), "wh": ref("actor"), "wy": why, "at": AT,
        "ev": [ref(eid)]}}

t = records["t_research"]["fields"]
t["ca"] = [ref("x_poc")]
t["vr"] = [ref("v_poc_stated"), ref("v_poc_viewed")]
t["st"] = sym("done")

records["handoff"] = {"id": "handoff", "kind": "N", "fields": {
    "wh": ref("actor"),
    "fo": [ref("i_backgrounds"), ref("i_canvas"), ref("i_edges"),
           ref("i_engine"), ref("x_poc")],
    "nx": [ref("t_scout")], "bl": [ref("t_scout"), ref("t_medic")],
    "rv": 2}}

# ---- two-pass: bindings need record hashes from a validated candidate ----
CAND = ROOT / "work/candidate2.px"
ADAPTER = ROOT / "work/candidate2.json"

def emit(rev, subset=None):
    chosen = list((subset or records).values())
    ADAPTER.write_text(json.dumps(
        {"revision": rev, "format": 2, "records": chosen},
        indent=2), encoding="utf-8")
    subprocess.run([PY, RUNNER, "encode", str(ADAPTER), "--out", str(CAND)], check=True)

need = {q: scope(q) for _, _, _, _, q in EVIDENCE}
targets = {eid: scope("x_poc") | need[q] for eid, _, _, _, q in EVIDENCE}

# Pass 1 omits E/V so the bound targets can be hashed. Those targets are
# unchanged in pass 2, so their record hashes carry over unchanged.
probe = {i: r for i, r in records.items() if r["kind"] not in ("E", "V", "N")}
probe["t_research"] = json.loads(json.dumps(records["t_research"]))
probe["t_research"]["fields"].update(st=sym("active"), vr=[])
emit(2, probe)
rh = hashes(None)
for eid in targets:
    records[eid]["fields"]["bs"] = binding(targets[eid], rh)
emit(2)

result = subprocess.run([PY, RUNNER, "validate", str(CAND), "--root", str(ROOT)],
                        capture_output=True, text=True)
print(result.stdout[:400] or result.stderr[:2000])
print("bound per receipt:", {k: len(v) for k, v in targets.items()})
