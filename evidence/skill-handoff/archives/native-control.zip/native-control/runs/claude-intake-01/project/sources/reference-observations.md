# Measured observations of the supplied references (2026-09-14)

Measured with `pixl_asset_check` and a Pillow pixel dump; enlarged 12x with
nearest-neighbour sampling and viewed by the acting agent. These are
observations of the supplied files, not approved project choices.

## Shared by both files

- Canvas 32x32, RGBA, single frame.
- 390 visible pixels, visible bbox [7,3,25,28] -> an 18x26 occupied region.
- Alpha is binary: 0 fractional-alpha pixels in either file.
- The alpha silhouette is pixel-identical between the two files (verified by
  comparing nonzero alpha at every one of the 1024 positions).
- One 4-connected opaque component each.
- Shared colors: teal #56B5BC (86,181,188) and cream #F4DDA2 (244,221,162).
- The cream marks are two 3x4 blocks at rows 14-17, reading as eyes.
- All forms are axis-aligned rectangles. No diagonals, no curves, no dithering,
  no anti-aliasing.

## reference.png ("outlined")

- 3 colors. Adds dark navy #25354A (37,53,74), 180 px.
- Pixel map of the occupied region (`#` navy, `o` teal, `*` cream):

```
    ####..........####
    ####..........####
    ####..........####
    ####..........####
    ####..........####
    ####..........####
    ##################
    ##################
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oo***oooo***oo##
    ##oo***oooo***oo##
    ##oo***oooo***oo##
    ##oo***oooo***oo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##oooooooooooooo##
    ##################
    ##################
```

- The navy border is 2 px thick on every side of the body.
- The two upper prongs (rows 3-8) are solid navy, 4 px wide, with no teal core.

## reference-b.png ("unoutlined")

- 2 colors. The navy is absent; every pixel that is navy in reference.png is
  teal here. Same cream eyes in the same positions.

## The consequential finding

The outline in reference.png is **inset**, not added around the form. Both files
occupy the identical 18x26 silhouette, so the navy border is spent out of the
body's own area rather than expanding it.

Cost of the outline at the reference's own scale:

- Body width 18 px, of which 4 px (22%) is border, leaving a 14 px interior.
- Body height from row 9 to row 27 is 19 px, of which 4 px is border.
- The 4 px wide upper prongs are entirely consumed by the 2 px border on each
  side, which is why they have no teal core.

This couples the two open decisions. The narrower the final canvas, the larger
the share of the character the inset border eats, and the prongs show what the
failure looks like: a feature narrower than 2x the border thickness loses its
fill color entirely and stops reading as part of the body.
