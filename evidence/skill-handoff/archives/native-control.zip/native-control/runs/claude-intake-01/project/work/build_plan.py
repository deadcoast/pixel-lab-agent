"""Author revision 1: full intake, knowledge, plans and criteria. No candidates."""
import hashlib, json, pathlib, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
PY = "C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe"
RUNNER = str(ROOT / ".agents/skills/pixl-kit/scripts/pixl.py")
AT = "2026-09-14"

def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

def lines(rel):
    return len((ROOT / rel).read_text(encoding="utf-8").splitlines())

ref = lambda i: {"$ref": i}
sym = lambda s: {"$symbol": s}
R = []
def rec(id_, kind, **fields):
    R.append({"id": id_, "kind": kind, "fields": fields})

# ---------------- sources ----------------
def source(id_, rel, au, at=AT, textual=True):
    rec(id_, "S", ur=rel, dg=sha(rel), ln=[1, lines(rel)] if textual else [],
        at=at, au=sym(au))

source("s_brief", "sources/brief.md", "local")
source("s_obs", "sources/reference-observations.md", "local")
source("s_knowledge", "sources/knowledge-notes.md", "local")
source("s_poc", "work/poc/outline-canvas-report.md", "local")
source("s_ref_a", "reference.png", "study", textual=False)
source("s_ref_b", "reference-b.png", "study", textual=False)

SRC = ["s_brief", "s_obs", "s_knowledge", "s_poc", "s_ref_a", "s_ref_b"]

# ---------------- intake choices ----------------
def choice(id_, key, status, value, sources, why, who="user"):
    rec(id_, "I", pr=ref("project"), wh=ref(who), ky=key, st=sym(status),
        vl=value, so=[ref(s) for s in sources], wy=why)

choice("i_roster", "family_roster", "confirmed", ["scout", "medic"], ["s_brief"],
       "The owner stated the family is a scout and a medic.")
choice("i_view", "vw", "confirmed", "side", ["s_brief"],
       "The owner stated the destination is a side-view game.")
choice("i_canvas", "px", "unresolved", None, ["s_brief", "s_poc"],
       "The owner has not chosen the final canvas size. It is not independent of "
       "edge_treatment: the proof shows a 2 px inset outline works at 32, is "
       "marginal at 24 and destroys the interior at 16.")
choice("i_edges", "edge_treatment", "conflict",
       ["2 px inset outline in #25354A, as in reference.png",
        "no outline, flat body color, as in reference-b.png"],
       ["s_ref_a", "s_ref_b", "s_obs", "s_poc"],
       "The two supplied references carry the identical silhouette and differ "
       "only in this. The proof found neither alternative dominates: the "
       "outlined form loses its prongs on a dark background, and the unoutlined "
       "form loses its edges on a background sharing its hue. Held open "
       "deliberately until backgrounds is known.")
choice("i_backgrounds", "backgrounds", "unresolved", None, ["s_brief", "s_poc"],
       "The backgrounds the game renders these characters against are unknown. "
       "This is the evidence edge_treatment actually depends on, and is the "
       "single most useful answer the owner can supply.")
choice("i_outline_color", "outline_color_policy", "proposed",
       "choose the outline color for contrast against the game's actual "
       "backgrounds rather than fixing it at the reference's #25354A",
       ["s_poc"],
       "Both observed failures are failures of one specific navy against one "
       "specific background, not of outlining as such. Untested proposal; it "
       "cannot be adopted before backgrounds is known.", who="actor")
choice("i_palette", "pl", "observed",
       ["#56B5BC", "#F4DDA2", "#25354A"], ["s_ref_a", "s_ref_b", "s_obs"],
       "Measured from the references. #56B5BC body and #F4DDA2 eyes appear in "
       "both; #25354A appears only in the outlined reference, so its membership "
       "follows from edge_treatment and is not yet agreed.")
choice("i_alpha", "al", "observed", "binary", ["s_ref_a", "s_ref_b", "s_obs"],
       "Both references have zero fractional-alpha pixels across all 1024 "
       "positions. Observed from the art, not yet confirmed as a project rule.")
choice("i_sampling", "sa", "observed", "nearest", ["s_obs"],
       "Both references are axis-aligned rectangular clusters with no "
       "anti-aliasing, which is consistent with nearest-neighbour presentation. "
       "The actual display scale has not been stated.")
choice("i_scale", "display_scale", "unresolved", None, ["s_brief"],
       "The scale the game presents these at is unknown; it bears on how much "
       "interior detail the chosen canvas needs to carry.")
choice("i_engine", "target_engine", "unresolved", None, ["s_brief"],
       "No destination engine was named, so no import requirement can be "
       "checked and every engine criterion stays unavailable.")
choice("i_anim", "animation", "unresolved", None, ["s_brief"],
       "No animation, direction set or frame timing was requested. Recorded so "
       "a later session does not assume a still sprite is the whole deliverable.")

CHOICES = ["i_roster", "i_view", "i_canvas", "i_edges", "i_backgrounds",
           "i_outline_color", "i_palette", "i_alpha", "i_sampling", "i_scale",
           "i_engine", "i_anim"]

# ---------------- knowledge ----------------
rec("k_silhouette", "K", nm="Evaluate identity using silhouette and target backgrounds",
    ap=[sym("characters_25d939ff"), sym("protected_eyes_3d8487f0")],
    op=["Render a flat opaque mask before detailing.",
        "Inspect major proportions, negative spaces and landmark separation at native logical scale.",
        "Compare the colored asset on representative light, dark and busy backgrounds."],
    ck=["Named identity landmarks remain visible at the target size.",
        "Required gaps stay open and interactive forms separate from their surroundings."],
    so=[ref("s_knowledge")],
    rq=["Intended viewing scale, representative backgrounds and identity landmarks"],
    rk=["Silhouette alone cannot validate faces, materials or fine symbols.",
        "No contrast ratio or component count proves aesthetic quality."])

rec("k_edges", "K", nm="Audit stair-step runs without imposing one contour style",
    ap=[sym("hard_silhouettes_99485584"), sym("clean_linework_08dea3fe")],
    op=["Trace boundary runs and highlight sudden run-length changes.",
        "Regularize only contours intended to read as smooth.",
        "Preserve corners, damage and organic asymmetry identified in the brief."],
    ck=["A supplied straight diagonal retains its declared repeating step pattern.",
        "No protected corner changes during cleanup."],
    so=[ref("s_knowledge")],
    rq=["A contour mask and declared intentional corners or irregular regions"],
    rk=["Not every uneven run is a jaggy; shape can require an abrupt change.",
        "Mechanical contour smoothing can erase style and identity."])

# ---------------- criteria ----------------
def crit(id_, name, dm, md, ck, sources, who="user"):
    rec(id_, "Q", nm=name, dm=sym(dm), md=sym(md), ck=ck, wh=ref(who),
        so=[ref(s) for s in sources])

crit("q_poc_stated", "proof is self-describing", "other", "local",
     "The report states its question, the acceptance conditions it fixed before "
     "looking at results, and for every conclusion the artifact path and the "
     "measurement or observation that supports it.",
     ["s_brief"], who="actor")
crit("q_poc_viewed", "proof fixtures were actually viewed", "visual", "visual",
     "Both fixture sets were viewed at native scale and at integer zoom, and "
     "each reported pass or fail names the specific background or canvas at "
     "which it was observed.",
     ["s_knowledge"], who="actor")
crit("q_size", "canvas, palette and alpha", "mechanical", "local",
     "The file matches the confirmed canvas size, contains no color outside the "
     "confirmed palette, and has zero fractional-alpha pixels.",
     ["s_obs"])
crit("q_read", "native-scale readability", "visual", "visual",
     "At native scale on the game's actual backgrounds, the full silhouette "
     "including both upper prongs stays distinguishable from the background, "
     "and both eye landmarks remain visible and separated from each other and "
     "from the body edge.",
     ["s_knowledge", "s_poc"])
crit("q_style", "style match to the references", "visual", "visual",
     "Viewed beside reference.png and reference-b.png the candidate reads as "
     "the same style: axis-aligned rectangular clusters, hard right-angle "
     "contours, no anti-aliasing and no dithering, with the confirmed outline "
     "treatment applied consistently.",
     ["s_ref_a", "s_ref_b", "s_knowledge"])
crit("q_role", "role reads from the sprite", "visual", "visual",
     "Without a label, the sprite reads as its intended role, and the scout is "
     "not mistaken for the medic or the reverse.",
     ["s_brief"])
crit("q_continuity", "scout and medic are one family", "continuity", "visual",
     "Viewed side by side at native scale, both members share body volume, eye "
     "placement, outline treatment and palette; role is distinguished by "
     "silhouette and accent rather than by a change of style.",
     ["s_brief", "s_obs"])
crit("q_engine", "destination import behaviour", "engine", "live",
     "The destination engine imports the sprite with nearest sampling, an "
     "integer display scale, unmultiplied binary alpha and the intended pivot, "
     "with no resampling at the edges.",
     ["s_brief"])

# ---------------- planned outputs ----------------
rec("f_poc", "F", tk=ref("t_research"), nm="Outline and canvas coupling report",
    kd=sym("report"), rq=[ref("q_poc_stated"), ref("q_poc_viewed")])
rec("f_scout", "F", tk=ref("t_scout"),
    nm="Scout representative sprite, single side-view pose",
    kd=sym("sprite"), rq=[ref("q_size"), ref("q_read"), ref("q_style"),
                          ref("q_role"), ref("q_engine")])
rec("f_medic", "F", tk=ref("t_medic"),
    nm="Medic sprite matching the accepted scout",
    kd=sym("sprite"), rq=[ref("q_size"), ref("q_read"), ref("q_style"),
                          ref("q_role"), ref("q_continuity"), ref("q_engine")])

# ---------------- tasks ----------------
rec("t_research", "T", nm="Resolve how outline treatment and canvas size constrain each other",
    ow=ref("actor"), pr=ref("project"), dp=[], dc=[],
    kn=[ref("k_silhouette"), ref("k_edges")], st=sym("active"),
    ph=sym("research"), ip=[], op=[ref("f_poc")], ca=[], vr=[])
rec("t_scout", "T", nm="Produce and accept the representative scout sprite",
    ow=ref("actor"), pr=ref("project"), dp=[ref("t_research")], dc=[],
    kn=[ref("k_silhouette"), ref("k_edges")], st=sym("blocked"),
    ph=sym("sample"), ip=[], op=[ref("f_scout")], ca=[], vr=[])
rec("t_medic", "T", nm="Produce the medic from the accepted scout baseline",
    ow=ref("actor"), pr=ref("project"), dp=[ref("t_scout")], dc=[],
    kn=[ref("k_silhouette")], st=sym("blocked"),
    ph=sym("production"), ip=[], op=[ref("f_medic")], ca=[], vr=[])

# ---------------- project ----------------
rec("actor", "A", nm="PIXL", rl=sym("agent"))
rec("user", "A", nm="Project owner", rl=sym("user"))
rec("project", "P",
    nm="Side-view scout and medic family",
    br=("Character family (scout, medic) for a side-view game, matching the "
        "style of reference.png and reference-b.png. The references disagree "
        "about outline treatment and the final canvas size is unchosen."),
    ow=ref("user"), sc=[ref(s) for s in SRC],
    in_=[ref(c) for c in CHOICES])
R[-1]["fields"]["in"] = R[-1]["fields"].pop("in_")

doc = {"revision": 1, "format": 2, "records": R}
out = ROOT / "work/candidate.json"
out.write_text(json.dumps(doc, indent=2), encoding="utf-8")

cand = ROOT / "work/candidate.px"
subprocess.run([PY, RUNNER, "encode", str(out), "--out", str(cand)], check=True)
print(subprocess.run([PY, RUNNER, "validate", str(cand), "--root", str(ROOT)],
                     capture_output=True, text=True).stdout or
      subprocess.run([PY, RUNNER, "validate", str(cand), "--root", str(ROOT)],
                     capture_output=True, text=True).stderr)
