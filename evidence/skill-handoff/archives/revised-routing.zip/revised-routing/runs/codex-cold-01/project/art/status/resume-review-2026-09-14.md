# Character-family resume review

Verified 2026-09-14 at 12:17 UTC using the session's local PIXL tools.

The project is at the boundary between completed intake and the first scout sample. [Authoritative state](../../.pixl/state.px) is PX2 revision 2, canonical SHA-256 `eb3af18a5e5fae4769d6768dcb6a2e09546fc59def8ff23957a603972c46ee7a`. Validation passed for all 66 records, bindings and retained files. Workflow, family, jobs and focused scout context were read from the live local runtime. This report preserves those decisions; it adds no production contract or acceptance verdict.

## Current decisions and observations

- Confirmed by the retained brief: a scout and medic family for a side-view game.
- Completed: `t.intake`, with nominated `x.intake_report` at [art/PROJECT.md](../PROJECT.md). Both local traceability and visual reference-review criteria pass. These verdicts apply to the intake report.
- Observed: both input references are 32x32 with identical silhouettes and binary alpha. They share angular teal forms and cream eye marks; A adds navy to its border and upper protrusions, while B uses teal there. Reference measurements establish source properties, not output requirements.
- Proposed: one right-facing standing scout at a provisional 32x32, a cream eye/visor and compact field pack, transparent PNG with binary alpha, followed by a medic with a cream medical satchel and shared construction. No full-body design, exact output palette or production method has been adopted.
- The two references and [native/8x comparison](../reference-review/comparison.png) were opened again during this resume. Navy separates more explicitly on the light and muted teal backgrounds; teal separates more clearly on dark. Those backgrounds are diagnostic. Neither outline has been chosen.

## Unresolved dependencies

| Stage | Required next dependency |
| --- | --- |
| Scout, `t.scout` / `f.scout` | A concrete raster trial contract. The 32x32 trial is still proposed; final canvas is unresolved and outline retains both conflicting alternatives. Side-view body and role readability need a real sample. |
| PixelLab execution | This session exposes local PIXL operations, with no callable PixelLab submit, poll or download tool/schema. No remote authentication was tested. There are zero saved jobs and zero generated character candidates. |
| Medic, `t.medic` / `f.medic` | The exact nominated scout on a completed sample task; confirmed production choices, a concrete contract, an evidence-backed adoption decision and current project-specific proofs for silhouette-readability and edge-rhythm. Bundled key/stair fixtures do not meet those proofs. |
| Family, `t.delivery` / `f.delivery` | Accepted members and an adoption decision, then exact baseline/member/destination bindings, retained copies and collective continuity review. The family report is empty: the generic delivery plan has no family manifest or accepted baseline yet. |
| Destination acceptance | Engine/version/project, game backgrounds, display scale, ground pivot and relevant import settings, followed by actual import testing. Palette and alpha policy, lighting and animation scope also remain unresolved or proposed. |

Scout and medic mechanical/visual checks and delivery continuity/engine checks are saved requirements with no performed verdicts yet. There are no failed character candidates to revise or pending jobs to reconcile. No task is currently ready.

## Next useful action

Resolve and save the smallest scout trial contract. The retained recommendation is a provisional 32x32 right-facing standing scout, comparing navy-edge and teal-edge alternatives while holding silhouette, pose and eye/pack landmarks stable. This experiment can inform the eventual production canvas and outline without treating either as already confirmed. Keep any generation differences as confounds, and retain failed or ambiguous variants.

The outstanding choice is: **What canvas size and edge experiment should the first scout trial use?** The existing recommendation is the 32x32 controlled comparison of both references. The packaged [PIXL skill](../../.agents/skills/pixl-kit/skills/pixl/SKILL.md) directs cold resumes without an accepted sample to its intake handoff; [that operation](../../.agents/skills/pixl-kit/skills/pixl/references/intake-sample.md) says, "Carry a still-unanswered question into that final response even when it was asked earlier or saved in the handoff."

Once the trial is selected, use the actual PX2 contract/choice schema and expected-hash commit to save it before results. Rediscover a real PixelLab schema before provider intent/dispatch. No host configuration change or package installation is part of this continuation. Evaluate retained scout bytes against the original mechanical and visual criteria at native size and integer zoom, preserving missing target-background/display evidence.

After scout acceptance and proof-backed production adoption, bind that exact nominee as `f.medic.bs`, add it to the medic task's inputs and keep the scout task as a direct prerequisite. Bind the delivery baseline and ordered members (scout, medic) and destination choices before collective evaluation. Retain the family snapshot after eligible member acceptance; copied files still need continuity and destination verdicts.

[Machine-readable runtime reports and tool discovery](resume-review-2026-09-14.json) retain this verification. The canonical production state, original accepted report, reference bytes and prior evidence were not changed.

