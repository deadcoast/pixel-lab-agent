# Visual inspection receipt — supplied references

- **Criterion:** `q_study_seen` (domain visual, required mode visual)
- **Candidate under review:** `x_study` = `sources/reference-observations.md`
- **Reviewer:** PIXL (agent), acting in this session
- **Date:** 2026-09-14
- **Outcome:** pass

## What was actually viewed

Both files were opened and rendered in this session:

1. `reference.png` and `reference-b.png` at native 32 x 32 scale.
2. `work/reference-views/reference-x12.png` and
   `work/reference-views/reference-b-x12.png`, produced by nearest-neighbour
   enlargement to 384 x 384 (integer factor 12), and viewed at that size.

At native 32 x 32 the images were legible only as two small coloured blocks; the
outline difference was not reliably judgeable at that size. The integer enlargement is
what made the treatments distinguishable, and the observations below come from it.

## Observed

- Both figures are the same bilaterally symmetric, front-facing blocky form: a body
  block with two vertical stalks rising from the top, separated by a central notch.
- Two cream rectangles sit side by side in the upper-middle of the body and read
  immediately as eyes. They are taller than they are wide, mirrored about the vertical
  axis, and level with each other. This matches the measured 3-wide x 4-tall clusters at
  x 11..13 and x 18..20, y 14..17.
- **reference.png** shows a flat dark navy border of even thickness running all the way
  around the teal body, with no gradient or ramp within it. The same navy also forms a
  horizontal bar across the figure below the stalks, a second bar across the bottom, and
  fills the two stalks completely so they read as solid dark uprights rather than
  outlined ones.
- **reference-b.png** shows no border at all. It is a flat teal silhouette carrying only
  the two cream eyes. The horizontal bars and the dark stalks are absent, and the stalks
  read as teal extensions continuous with the body. The figure looks noticeably flatter
  and less articulated than reference.png, and loses the shoulder and base landmarks
  entirely.
- Neither image shows anti-aliasing, dithering, or any soft edge at 12x. Every boundary
  is a hard colour change on the logical grid.
- Neither image shows a side view, a facing direction, limbs, or any equipment.

## Agreement with the study

The description of the outline treatment and of eye placement in
`sources/reference-observations.md` matches what was seen. The study's claim that the
outline is load-bearing rather than decorative was confirmed visually: the bars and
stalk fills disappear along with the contour in reference-b.png.

## Limits of this receipt

This receipt covers only the supplied reference art. It establishes no acceptance for
any produced asset, no engine import behaviour, and no judgement about which outline
treatment the project should adopt. That decision belongs to the project owner.
