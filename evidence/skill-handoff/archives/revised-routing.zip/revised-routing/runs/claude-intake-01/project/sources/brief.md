# User brief (verbatim, 2026-09-14)

> Make a character family matching this project, using PIXL. The supplied references
> disagree about outline treatment and I have not chosen the final canvas size. The
> family will have a scout and a medic for a side-view game. References are
> reference.png and reference-b.png. Begin the project and make the progress possible
> in this session.

## Session constraints (verbatim)

> This is an isolated PIXL evaluation project. Work only in this project. The packaged
> PIXL skill and runtime are available under .agents/skills/pixl-kit. The selected
> Python interpreter is C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe.
> Local PIXL tools are supplied by the session MCP configuration. Input images are in
> the project root. Do not install packages or change host settings.

## What the brief states explicitly

- Family roster: a scout and a medic.
- Destination: a side-view game.
- Style authority: the two supplied references, which the user states disagree about
  outline treatment.
- Final canvas size: explicitly not chosen by the user.
- Scope: begin the project and make the progress that is possible in this session.

## What the brief does not state

- Which outline treatment wins.
- The final canvas size.
- Target display/zoom scale and engine or importer for the side-view game.
- Animation requirements (poses, cycles, directions) beyond "character family".
- Whether the reference figures' front-facing symmetric shape is itself the intended
  character design, or only a style/palette swatch.
