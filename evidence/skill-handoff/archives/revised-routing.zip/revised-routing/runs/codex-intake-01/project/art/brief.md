# User brief

Make a character family matching this project, using PIXL. The supplied references disagree about outline treatment and I have not chosen the final canvas size. The family will have a scout and a medic for a side-view game. References are reference.png and reference-b.png. Begin the project and make the progress possible in this session.

This is an isolated PIXL evaluation project. Work only in this project. The packaged PIXL skill and runtime are available under .agents/skills/pixl-kit. The selected Python interpreter is C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe. Local PIXL tools are supplied by the session MCP configuration. Input images are in the project root. Do not install packages or change host settings.
