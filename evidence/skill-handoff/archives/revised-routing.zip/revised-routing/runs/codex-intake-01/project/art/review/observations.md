# Reference observations

The assistant opened both original 32x32 PNGs and separate 256x256 nearest-neighbor views through the host image viewer on 2026-09-14. Viewer device-pixel mapping is unknown; the files and nominal view dimensions are retained. This is a reference inspection, not candidate acceptance.

Both references have the same block-shaped body with two upper projections, a rectangular notch between them, and two cream face marks. Their alpha masks and face-mark positions match. The shape appears frontal; neither reference proves a side-facing character pose. Side-view gameplay comes from the user brief and will need its own representative pose.

Reference A has a navy (#25354A) exterior band, generally two logical pixels thick around the body, with navy filling the upper projections. Reference B replaces all 180 navy pixels with teal (#56B5BC), retaining the same silhouette. Calling B selective outlining would overstate what is visible: it has no contrasting dark outer border. Both have 24 cream (#F4DDA2) pixels, and neither exhibits a shading ramp or evident lighting direction.

Measured in each source: 32x32 canvas, one frame, 390 nontransparent pixels, one connected opaque component, binary alpha, and visible bounds [7,3,25,28] (right/bottom exclusive). A uses three visible colors; B uses two. These are observations about references, not requirements adopted for the family. Component count does not prove readability.

Open choices: final canvas; which edge treatment to use; target engine/project and display scale. Proposed first experiment: use one right-facing idle scout at a trial 32x32 canvas and compare both outline treatments while keeping body proportions, landmarks, pose, and placement fixed. Final canvas remains unresolved even if that trial is selected. Role equipment is proposed separately in the research report.

No scout or medic sprite has been generated or accepted. No actual gameplay background, engine scene, animation, or imported asset was available for review.
