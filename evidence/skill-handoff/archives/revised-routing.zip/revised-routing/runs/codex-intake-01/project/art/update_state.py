"""Project-local PIXL intake publication helper; uses the packaged CLI only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / '.agents/skills/pixl-kit/scripts/pixl.py'
STORE = ROOT / '.pixl'

def cli(*args):
    result = subprocess.run([sys.executable, str(RUNNER), *map(str, args)], cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout

def ref(value): return {'$ref': value}
def sym(value): return {'$symbol': value}
def refs(*values): return [ref(v) for v in values]
def digest(path): return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
def write_json(path, value):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

before = json.loads(cli('validate', STORE / 'state.px', '--root', ROOT))
doc = json.loads(cli('decode', STORE / 'state.px'))
records = {r['id']: r for r in doc['records']}
now = datetime.now(timezone.utc).isoformat()

def add(id, kind, **fields):
    if id in records: raise ValueError(f'Already published: {id}')
    records[id] = {'id': id, 'kind': kind, 'fields': fields}

def source(id, path, lines=None):
    add(id, 'S', ur=path, dg=digest(path), ln=lines or [], at=now, au=sym('local'))

def choice(id, key, status, value, why, sources, owner='actor'):
    add(id, 'I', pr=ref('project'), wh=ref(owner), ky=key, st=sym(status), vl=value, so=refs(*sources), wy=why)

def criterion(id, name, domain, mode, condition, sources=('src.brief',)):
    add(id, 'Q', nm=name, dm=sym(domain), md=sym(mode), ck=condition, wh=ref('actor'), so=refs(*sources))

def task(id, name, phase, outputs, dependencies=(), state='open', methods=()):
    add(id, 'T', nm=name, ow=ref('actor'), pr=ref('project'), dp=refs(*dependencies), dc=[], kn=refs(*methods), st=sym(state), ph=sym(phase), ip=refs('ref.a', 'ref.b'), op=refs(*outputs), ca=[], vr=[])

def output(id, name, kind, task_id, requirements):
    add(id, 'F', nm=name, kd=sym(kind), tk=ref(task_id), rq=refs(*requirements))

if sys.argv[1] == 'plan':
    if before['revision'] != 0: raise ValueError('Plan already initialized')
    inventory = {
        'observed_at': now,
        'discovery': 'Actual tool names and schemas inspected through session ALL_TOOLS metadata',
        'local_pixl': ['pixl_intake','pixl_workflow','pixl_family','pixl_jobs','pixl_validate','pixl_encode','pixl_commit','pixl_asset_check','pixl_knowledge','pixl_sources','pixl_source','pixl_context','pixl_inspection_prepare','pixl_inspection_review'],
        'pixellab_provider_tools': [],
        'other_image_tool': 'image_gen__imagegen is present; it is not a PixelLab tool and was not used as a substitute for the requested PIXL production route',
        'missing_capability': 'A connected authenticated PixelLab generation tool with its actual input schema and retrieval/polling capability',
        'remote_jobs_submitted': 0,
        'installations_or_host_changes': False
    }
    write_json('art/review/session-capabilities.json', inventory)
    for name in ('reference.png', 'reference-b.png'):
        result = json.loads(cli('asset-check', ROOT / name))
        write_json('art/review/' + Path(name).stem + '-pixl-check.json', result)
    for id,path,lines in [
        ('src.brief','art/brief.md',[1,5]),
        ('src.observations','art/review/observations.md',[1,13]),
        ('src.a','reference.png',None),('src.b','reference-b.png',None),
        ('src.measurements','art/review/reference-measurements.json',None),
        ('src.capabilities','art/review/session-capabilities.json',None),
        ('src.method','.agents/skills/pixl-kit/resources/knowledge/pixel-art.json',None),
        ('src.deep.clusters','.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-DEEP-RESEARCH.md',[857,867]),
        ('src.deep.motion','.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-DEEP-RESEARCH.md',[1563,1573]),
        ('src.archive.ui','.agents/skills/pixl-kit/resources/training/original-docs/PIXEL-ART-ASSETS.md',[11,15])
    ]: source(id,path,lines)
    for id,path in [('ref.a','reference.png'),('ref.b','reference-b.png')]:
        add(id,'X',nm=path,ur=path,dg=digest(path),kd=sym('reference'),mt={'origin':'user-supplied reference; not a family candidate'})
    choice('roles','members','confirmed',['scout','medic'],'The user explicitly requests these two roles.',['src.brief'],'user')
    choice('projection','vw','confirmed',sym('side'),'Side-view gameplay is explicit in the brief; references themselves appear frontal.',['src.brief'],'user')
    choice('canvas','px','unresolved',None,'The user has not chosen final frame dimensions; source dimensions do not establish this choice.',['src.brief'],'user')
    choice('edges','edge_treatment','conflict',['A: navy exterior band, typically two pixels, with navy upper projections','B: same silhouette with teal outer edges and no contrasting navy border'],'Preserve both supplied alternatives until a sample comparison or user selection resolves the conflict.',['src.a','src.b','src.observations'],'user')
    choice('source_canvas','reference_canvas','observed',[32,32],'Measured in both reference PNGs; not adopted as final output size.',['src.measurements'])
    choice('source_palette','reference_colors','observed',['#56B5BC','#F4DDA2','#25354A (A only)'],'Both references are flat teal and cream; A also uses navy. No family-wide exact palette lock is inferred.',['src.measurements','src.observations'])
    choice('source_alpha','reference_alpha','observed',sym('binary'),'Both references have only zero/255 alpha; output alpha policy still requires a concrete sample contract.',['src.measurements'])
    choice('sample_trial','sample_trial','proposed',{'canvas':[32,32],'facing':'right','pose':'idle','treatments':['A','B']},'Smallest proposed comparison: same scout pose, proportions and landmarks with two edge treatments. Trial size does not settle final canvas.',['src.observations'])
    choice('role_cues','role_cues','proposed',{'scout':'compact rear field pack and forward-facing eye landmark','medic':'larger aid satchel with a cream patch; shared underlying body'},'Separate role silhouettes while retaining the simple teal body and cream detail language. Equipment and side-facing adaptation are proposals, not source facts.',['src.brief','src.observations'])
    choice('destination','destination_engine','unresolved',None,'No engine, target project, or version was supplied; eventual import acceptance remains unverified.',['src.brief'],'user')
    choice('display','display_scale_backgrounds','unresolved',None,'The intended display scale and gameplay backgrounds are unknown. Diagnostic light/dark/patterned backgrounds cannot establish game-scene readability.',['src.brief'],'user')
    choice('motion','animation_scope','unresolved',None,'Animation counts, directions and timing were not requested. Begin with a proposed static pose; defer motion planning.',['src.brief'],'user')
    choice('provider','provider_access','observed','No connected PixelLab provider tool exposed','Local PIXL operations are present; no remote generation, polling or download request was made.',['src.capabilities'])
    add('method.readability','K',nm='Proposed scout silhouette and background comparison',ap=[sym('characters_25d939ff')],op=['Render a mask and color view of a representative side-facing scout.','Compare the two proposed edge treatments without changing pose, landmarks or canvas.','Inspect native-scale role landmarks and negative spaces on actual gameplay backgrounds when supplied; enlarged views supplement native inspection.'],ck=['Facing and compact scout equipment remain identifiable.','Role landmarks and gaps remain distinct on the tested backgrounds.','Preserve any ambiguous observation rather than selecting an outline from component counts.'],so=refs('src.method','src.deep.clusters','src.deep.motion','src.archive.ui'),rq=['Usable trial canvas and edge contracts','Actual scout candidate','Identity landmarks','Intended display scale and representative backgrounds'],rk=['The bundled proof is a key-shaped fixture, not a character proof.','Deep-research citations concern cluster constraints and motion differences; archive citation is about UI consistency. They do not directly prove this outline choice.','No component count or local fixture establishes artistic quality.'])
    criterion('q.research','Resumable source review','other','local','The retained report identifies both references and their hashes, exact researched method source ranges, reference observations versus proposals and unresolved choices, fixture limitations, and the next sample and provider blockers.',('src.brief','src.observations','src.measurements','src.capabilities','src.method','src.deep.clusters','src.deep.motion','src.archive.ui'))
    criterion('q.raster','Candidate file measurements','mechanical','local','The actual candidate decodes and matches its saved trial contract canvas and alpha policy; apply an exact palette test only if a palette is explicitly adopted. Measure bounds and placement without treating them as visual acceptance.')
    criterion('q.scout','Scout style and role readability','visual','visual','At native scale and integer-nearest enlargement, the side-facing idle scout retains the reference body language and readable cream face landmark; its compact field-pack silhouette and forward direction are legible on declared diagnostic backgrounds. Compare outline alternatives with pose and proportions held fixed. Record diagnostic-background and viewing limits.')
    criterion('q.medic','Medic style and role readability','visual','visual','At native scale and integer-nearest enlargement, the medic reads as a distinct aid carrier through the proposed satchel silhouette and patch after those cues are selected, while matching the accepted scout proportions, chosen edge treatment and color language.')
    criterion('q.continuity','Family consistency','continuity','visual','Compare the exact accepted scout and medic together at native and enlarged scales: body volume, ground contact, facing convention, face placement, palette use and edge treatment agree; equipment distinguishes the roles without relying only on recoloring.')
    criterion('q.engine','Destination import','engine','live','In the named target engine/project, import the retained sprites and demonstrate agreed sampling, display scale, transparency and contact/pivot placement against representative gameplay backgrounds. If later animation is added, declare slicing and timing criteria before review.')
    task('research','Retain reference findings and proposed sample proof','research',['out.research'],state='active',methods=('method.readability',))
    output('out.research','Reference review and representative-sample plan','report','research',['q.research'])
    task('scout.sample','Prove representative scout before family production','sample',['out.scout'],dependencies=('research',),methods=('method.readability',))
    output('out.scout','Representative side-facing scout idle; raster plan awaiting concrete trial contract','sprite','scout.sample',['q.raster','q.scout'])
    task('medic.production','Extend the accepted scout baseline into a medic','production',['out.medic'],dependencies=('scout.sample',),methods=('method.readability',))
    output('out.medic','Side-facing medic idle; exact baseline to be bound after scout acceptance','sprite','medic.production',['q.raster','q.medic'])
    task('family.delivery','Retain and review the scout and medic family','delivery',['out.family'],dependencies=('scout.sample','medic.production'))
    output('out.family','Planned family package; membership and baseline to be bound when actual candidates exist','report','family.delivery',['q.continuity','q.engine'])
    records['project']['fields']['in'] = refs(*[r['id'] for r in records.values() if r['kind']=='I'])
    records['project']['fields']['sc'] = refs('src.brief','src.a','src.b','src.observations')
    add('handoff','N',wh=ref('actor'),fo=refs('canvas','edges','sample_trial','provider','out.scout','out.medic','out.family'),nx=refs('research'),bl=refs('scout.sample','medic.production','family.delivery'),rv=1)
elif sys.argv[1] == 'finish':
    if before['revision'] != 1: raise ValueError('Expected saved pre-review plan at revision 1')
    path='art/research.md'
    report=(ROOT/path).read_text(encoding='utf-8')
    required=['d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7','e76b40ce38aeb436d0f5f0e433c4ac1eb4519bf93a7b29cd7a81a4609914a12a','857-867','1563-1573','11-15','silhouette-readability','fixture','unresolved','PixelLab']
    checks={token:token in report for token in required}
    if not all(checks.values()): raise ValueError(checks)
    add('report.research','X',nm='Retained reference research and sample plan',ur=path,dg=digest(path),kd=sym('report'),of=ref('out.research'))
    semantic={'A','S','R','C','K','D','X','I','F','Q'}
    def links(value):
        if isinstance(value,dict):
            if '$ref' in value: yield value['$ref']
            else:
                for v in value.values(): yield from links(v)
        elif isinstance(value,list):
            for v in value: yield from links(v)
    pending=['report.research','q.research']; scope=set()
    while pending:
        id=pending.pop()
        if id in scope or records[id]['kind'] not in semantic: continue
        scope.add(id);pending.extend(links(records[id]['fields']))
    # Ask the actual encoder/validator for record hashes, including the new report.
    probe={'format':2,'revision':2,'records':list(records.values())}
    write_json('.pixl/candidates/research-probe.json',probe)
    cli('encode',STORE/'candidates/research-probe.json','--out',STORE/'candidates/research-probe.px')
    hashed=json.loads(cli('validate',STORE/'candidates/research-probe.px','--root',ROOT))['record_hashes']
    receipt={'observed_at':now,'criterion':'q.research','outcome':'pass','mode':'local','report_sha256':digest(path),'checks':checks,'observations':'The agent read the report and source slices and checked retained identities, distinction of observations/proposals, proof limitations and next blockers. This accepts the research report only.','visual_asset_acceptance':False,'engine_acceptance':False,'remote_generation':False}
    write_json('art/review/research-retention-check.json',receipt)
    add('e.research','E',nm='Local retention review of research report',ur='art/review/research-retention-check.json',dg=digest('art/review/research-retention-check.json'),rs=sym('pass'),md=sym('local'),at=now,bs=[{'rf':ref(id),'dg':hashed[id]} for id in sorted(scope)])
    add('v.research','V',tk=ref('research'),rq=ref('q.research'),xr=ref('report.research'),st=sym('pass'),wh=ref('actor'),wy='Report retains source identities, exact citations, observations, proposals, unknowns, fixture limits and concrete next actions; no asset acceptance is claimed.',at=now,ev=refs('e.research'))
    records['research']['fields'].update(st=sym('done'),ca=refs('report.research'),vr=refs('v.research'))
    records['handoff']['fields'].update(fo=refs('report.research','canvas','edges','sample_trial','provider','out.scout','out.medic','out.family'),nx=refs('scout.sample'),rv=2)
else:
    raise ValueError('Use plan or finish')

doc.update(revision=before['revision']+1,records=list(records.values()),format=2)
candidate=STORE/'candidates'/f'revision-{doc["revision"]}.json'
write_json(candidate,doc)
wire=candidate.with_suffix('.px')
cli('encode',candidate,'--out',wire)
validated=json.loads(cli('validate',wire,'--root',ROOT))
print(json.dumps({'candidate':str(wire),'valid':validated['valid'],'revision':validated['revision'],'records':validated['records']}))
print(cli('commit',STORE,wire,'--expect',before['hash'],'--root',ROOT))
