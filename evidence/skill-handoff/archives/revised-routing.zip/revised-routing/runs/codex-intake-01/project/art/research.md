# Scout and medic: reference research and first sample

The project has two explicit members, scout and medic, for a side-view game. Final canvas is unresolved. The edge-treatment conflict is preserved; no finished character, adopted family contract, or generated candidate exists yet.

## Inspected sources

| Source | SHA-256 | Findings |
| --- | --- | --- |
| reference.png | d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7 | 32x32, teal and cream with navy exterior band; 3 visible colors |
| reference-b.png | e76b40ce38aeb436d0f5f0e433c4ac1eb4519bf93a7b29cd7a81a4609914a12a | 32x32, teal outer edges; 2 visible colors |

Both have the same alpha mask and 390 visible pixels, with the same cream marks. A's 180 navy pixels become teal in B. Both have binary alpha and visible bounds [7,3,25,28]. Originals and 8x nearest-neighbor views were opened through the host image viewer. The viewer's physical pixel mapping is unknown; nominal native/enlarged files are retained. See `review/observations.md`, `review/reference-measurements.json`, and the two PIXL asset-check JSON files. Mechanical checks do not supply an aesthetic verdict.

The references suggest a simple block body with two upper projections and sparse cream face details. They appear frontal; a side-facing pose is a new adaptation to prove. There is no observed directional shading, limb rig, animation, ground-contact rule, or engine setup to inherit.

## Proposed design experiment

Use one right-facing idle scout as the representative sample. Preserve the simple body mass, upper projections and a visible cream face landmark where they work in profile. Propose a compact rear field pack as the scout role cue. Later propose a larger aid satchel and cream patch for the medic, using the scout's accepted underlying proportions. These equipment choices are design proposals, not details present in the references.

The proposed first comparison uses a trial 32x32 canvas and two scout candidates: A with a navy exterior band informed by reference A; B with teal outer edges informed by reference B. Hold pose, body proportions, equipment, landmark placement and canvas constant. Do not silently convert A into a conventional one-pixel outline or call B selective outlining. Trial dimensions are separate from final output dimensions. No trial contract was activated while the user's canvas and edge questions remained unanswered.

Inspect the candidate mask and colored version at native size and an integer enlargement on light, dark and patterned diagnostic backgrounds. Check facing readability, face landmark separation, role cue visibility and remaining negative spaces. Review against actual gameplay backgrounds and display scale when available. These diagnostic backgrounds are not evidence of readability in the target game.

Acceptance criteria were saved in PIXL revision 1 before evaluating this report or any future candidate: file measurements; scout visual readability; medic visual readability; family continuity; and separate live destination import. Scout sample acceptance concerns its declared diagnostic trial only; final engine acceptance belongs to delivery.

## Method and exact source review

Selected installed method: `silhouette-readability`, “Evaluate identity using silhouette and target backgrounds.” The local method inventory and full compiled `k.silhouette-readability` context were read. The candidate method calls for a flat opaque mask, native-scale landmark and gap inspection, and colored comparisons on representative backgrounds. Its prerequisite is the intended viewing scale, representative backgrounds and identity landmarks. Only proposed role landmarks and source images are available here; actual game backgrounds and scale remain unresolved.

Installed source inventory was locally hash-verified. The following exact cited slices were retrieved with expected hashes through `pixl_source` in library scope:

| Bundled source under `.agents/skills/pixl-kit/resources/` | SHA-256 | Inclusive lines | Applicability |
| --- | --- | --- | --- |
| training/original-docs/PIXEL-ART-DEEP-RESEARCH.md | 7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28 | 857-867 | Cluster constraints: preserve identifying features, approved color behavior and intentional hard edges; context is animation candidate rejection. |
| training/original-docs/PIXEL-ART-DEEP-RESEARCH.md | 7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28 | 1563-1573 | Separates silhouette, shade, detail and effects changes; example concerns breathing versus explosion animation. Limited transfer to this static comparison. |
| training/original-docs/PIXEL-ART-ASSETS.md | 450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900 | 11-15 | An archived UI request about appropriate scale, clarity and application-wide consistency. It is not an instruction for this character project or evidence for either outline. |

The first slice explicitly says “destroys identifying facial feature” and “creates edge AA on an edge that should remain hard” among rejection cases. Those restrictions depend on an agreed contract; they are not universal bans on antialiasing. The second warns that low pixel difference is not automatically good. None of these passages resolves the supplied A/B outline conflict. The project comparison is therefore an unproven proposed method, not a source-established aesthetic decision.

The compiled method's retained POC is a bounded key-silhouette fixture: a positive key with ring hole, shaft and teeth and a negative example that merges landmarks. Its receipt is local and concerns that fixture. It proves neither a side-facing scout, a medic, outline preference, PixelLab capability nor engine behavior. It was inspected as context, not rerun or imported as project acceptance. No D adoption record or project proof pass was fabricated. The project K deliberately has no proof receipt.

## Saved dependency plan

1. Complete the retained source review (`research` / `out.research`).
2. Resolve a usable trial canvas and edge comparison scope, save concrete trial contract(s), and execute the representative scout sample (`scout.sample` / `out.scout`). If both treatments are selected, split the experiment into separately contracted output plans and save their criteria before generating either. Preserve all alternatives and failed candidates.
3. After the exact scout nominee passes the declared sample criteria, confirm the family production choices and retain an applicable adoption decision/proof. Bind the actual sample X as `F.bs` and as an input to `medic.production`; create and inspect the medic (`out.medic`).
4. Once real eligible baseline/member candidates exist, amend `out.family` with the exact baseline, ordered scout/medic outputs and destination choices. Retain a family snapshot, compare the exact members together, and separately perform destination import checks. Until then it is an open delivery plan, not a snapshot-enabled family manifest.

Planned raster outputs have no invented X path/hash or contract. No accepted baseline exists. Future family membership is intentionally not fabricated from supplied reference images. Static poses are the initial proposed scope; no animation count, frame timing or direction batch is assumed.

## Capability and resumption boundary

The session exposes local PIXL state, research, measurements, inspection and job-journal tools. It exposes no connected PixelLab provider generation tool, input schema, polling or result-retrieval surface. There were zero remote submissions, jobs, downloads or paid retries. The generic image generator is a different provider and was not substituted for the requested PIXL production route. No packages were installed and no host settings were changed.

The next useful input is the trial choice: compare both edge treatments at 32x32, select one treatment, or specify another trial canvas. Final canvas can remain unresolved during an explicitly scoped experiment. Before actual generation, the session also needs the real PixelLab tool and schema. Discover it then; do not manufacture a provider request from cached capability documentation. Follow the packaged provider recovery operation to prepare intent, claim one dispatch, observe a real result and import actual candidate bytes.

Cold resumption starts with `workflow`, `family` and `jobs` for `.pixl/state.px` with this project root, then context for `scout.sample`. The family report may have no snapshot-enabled families because no real baseline exists. No provider attempt needs reconciliation in this revision. Read the retained observations before repeating reference work. Keep final canvas, edge conflict, game backgrounds/display scale and destination limitations explicit. Actual candidate visual review and live engine import are unperformed, not passing and not failed.
