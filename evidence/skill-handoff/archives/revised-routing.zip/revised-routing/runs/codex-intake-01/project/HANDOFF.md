# Scout and medic project handoff

Started with the packaged PIXL skill and local runtime. All writes are within this isolated project; no packages were installed or host settings changed.

## Saved progress

- [Reference comparison](art/review/index.html): original A/B references, native/integer zoom, diagnostic backgrounds, measured colors and dimensions. Open locally in a browser. The controls have not been exercised in a browser in this session; the actual PNGs were inspected through the host image viewer.
- [Reference observations](art/review/observations.md) and [research/sample plan](art/research.md).
- [Reference measurements](art/review/reference-measurements.json), actual PIXL checks (`art/review/reference-pixl-check.json`, `art/review/reference-b-pixl-check.json`), and [pixel equivalence check](art/review/reference-equivalence.json).
- [Authoritative state](.pixl/state.px), PX2 revision 2, canonical SHA-256 `fffa7c95c694d1ab897c7257befeca4adcb5de94f26817d6bf7093b716da8197`. Validation verifies all 47 records and referenced files. Earlier revisions remain in `.pixl/history/`.
- Snapshot reports: `.pixl/reports/validate.json`, `workflow.json`, `family.json`, `jobs.json`. Regenerate these after any state change.

Research is done, with a local retention verdict for the report only. Scout, medic and delivery output plans exist; no raster candidate, accepted representative sample, generation job, family snapshot or engine verdict exists. Planned files have no invented artifact identities. The family report currently lists no snapshot-enabled families because no actual baseline can be bound yet.

## Open choices and next action

Both sources are 32x32, but final canvas remains **unresolved**. A has a navy border generally two pixels thick; B replaces exactly those 180 navy pixels with teal. Edge treatment remains **conflicting**. Their alpha masks, shape and cream face marks match. The references appear frontal; side-facing gameplay comes from the brief.

The user was asked which outline treatment and trial canvas to explore; no answer was received before this handoff. Proposed experiment: compare both treatments on the same right-facing idle scout at a **trial 32x32**, preserving final size as unresolved. Proposed scout cue: compact field pack. Proposed medic cue: larger aid satchel and cream patch. These proposals are not confirmed style decisions. Do not interpret silence as approval.

The immediate sample blocker is `out.scout` having no concrete raster contract. Clarify the trial choices and then save usable proposed/confirmed trial choices and contract(s). If comparing both treatments, add separately contracted output plans before generation; keep the final `canvas` unresolved and original `edges` conflict preserved until a reviewed choice resolves them. The saved scout output can remain the first experiment output; additional alternatives need distinct stable F/X identities. Save revised criteria before evaluating candidates.

The session exposes local PIXL but **no connected PixelLab generator with its input schema or result-retrieval/polling tools**. No remote request was prepared or dispatched. The generic image generator was not used as a PixelLab substitute. A future session must discover actual provider tools and schemas; cached `pixl_capabilities` is not live discovery. Then follow `.agents/skills/pixl-kit/skills/pixl/references/provider-recovery.md`. Never invent a request, remote ID or provider status. There is currently no pending job to reconcile.

After an actual scout candidate is retained, prepare native/enlarged candidate-and-reference views with the PIXL inspection operation. Open those views and retain explicit criterion observations. Measurements alone cannot accept a sprite. Preserve failures and revise with new X identities. A scout sample's declared diagnostic visual criteria are distinct from final gameplay/engine validation.

Once the exact nominated sample passes, confirm the production contract and retain applicable method proof and adoption decision. Bind that exact X to the medic plan through `F.bs`, `T.ip` and the direct sample prerequisite before production. After medic acceptance, configure `out.family` with the exact baseline, ordered scout and medic member outputs and destination choices, save the plan, then use the family snapshot operation. Missing engine/project, display scale/backgrounds and import settings must stay explicit. An unavailable engine verdict can only be attached when an actual candidate exists; until then its criterion is unperformed.

## Cold resume

Use the selected interpreter and the installed runner from this project root:

```powershell
$pixlPython = 'C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe'
$pixlRunner = '.agents/skills/pixl-kit/scripts/pixl.py'
& $pixlPython $pixlRunner workflow .pixl/state.px --root .
& $pixlPython $pixlRunner family .pixl/state.px --root .
& $pixlPython $pixlRunner jobs .pixl/state.px --root .
& $pixlPython $pixlRunner context .pixl/state.px scout.sample --root . --budget 40000
```

Read `art/research.md` and the original reference views before repeating research. Respect the current revision/hash on every commit. `art/update_state.py` records how revisions 1 and 2 were published and intentionally refuses replay against a later revision; resume through decode/encode/validate/commit rather than rerunning the intake helper. No broad package tests, provider tests or target-engine tests were performed; verification covered PIXL publication/file identities, reference measurements and exact nearest-neighbor review copies.
