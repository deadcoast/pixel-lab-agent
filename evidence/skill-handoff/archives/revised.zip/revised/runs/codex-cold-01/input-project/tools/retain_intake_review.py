"""Retain this session's explicit reference review; no generation or art approval."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
RUNNER=ROOT/".agents/skills/pixl-kit/scripts/pixl.py"
def cli(*args):
    result=subprocess.run([sys.executable,str(RUNNER),*map(str,args)],cwd=ROOT,capture_output=True,text=True,encoding="utf-8")
    if result.returncode: raise RuntimeError(result.stdout+result.stderr)
    return result.stdout
def ref(x): return {"$ref":x}
def refs(*xs): return [ref(x) for x in xs]
def sym(x): return {"$symbol":x}
def digest(path): return sha256((ROOT/path).read_bytes()).hexdigest()
def save(path,value): (ROOT/path).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8")

current=json.loads(cli("validate",".pixl/state.px","--root",ROOT))
doc=json.loads(cli("decode",".pixl/state.px"))
if doc["revision"]!=1: raise RuntimeError("Review belongs to saved revision 1. Reconcile before another publication.")
doc["revision"]+=1
records=doc["records"]
def add(id,kind,**fields): records.append({"id":id,"kind":kind,"fields":fields})
index={r["id"]:r for r in records}
measurements=json.loads((ROOT/"art/reference-review/measurements.json").read_text())
checks=[]
board=Image.open(ROOT/"art/reference-review/comparison.png").convert("RGB")
backgrounds=["#f4efdf","#17202b","#487878"]
for row,item in enumerate(measurements["references"]):
    im=Image.open(ROOT/item["path"]).convert("RGBA")
    checks.append({"name":item["path"]+" source identity and dimensions","pass":digest(item["path"])==item["sha256"] and list(im.size)==item["size"]})
    y=44+row*316
    for col,color in enumerate(backgrounds):
        x=20+col*288
        bg=Image.new("RGBA",im.size,color)
        bg.alpha_composite(im)
        enlarged=bg.resize((256,256),Image.Resampling.NEAREST).convert("RGB")
        checks.append({"name":item["path"]+" background "+str(col)+" native and 8x retained pixels","pass":board.crop((x,y+38,x+256,y+294)).tobytes()==enlarged.tobytes() and board.crop((x+212,y+1,x+244,y+33)).tobytes()==bg.convert("RGB").tobytes()})
checks.append({"name":"Final canvas remains unknown and outline remains conflicting","pass":index["i.canvas"]["fields"]["st"]==sym("unresolved") and index["i.canvas"]["fields"]["vl"] is None and index["i.outline"]["fields"]["st"]==sym("conflict")})
checks.append({"name":"No generated sprite, adopted decision or provider job","pass":not any(r["kind"] in {"D","J"} or (r["kind"]=="X" and r["fields"]["kd"]==sym("sprite")) for r in records)})
if not all(x["pass"] for x in checks):
    save("art/research/review-failed.json",checks)
    raise RuntimeError("Reference retention check failed; retained report and stopped acceptance.")
at=datetime.now(timezone.utc).isoformat()
local={"at":at,"reviewer":"PIXL assistant","candidate":"art/PROJECT.md","criterion":"q.research_trace","outcome":"pass","checks":checks,"review":"Read the retained project report, measurement inventory, source observations, exact method slices and applicability assessment. The report distinguishes the requested roles and side-view from source observations and proposed equipment. It preserves final canvas and edge conflict, cites the exact local source identities, limits the UI citation and fixture claims, and names the missing PixelLab surface and remaining scout proof.","limits":"Acceptance is for a traceable intake report, not a proven character method or generated family."}
visual={"at":at,"reviewer":"PIXL assistant","candidate":"art/PROJECT.md","criterion":"q.research_view","outcome":"pass","host_tool":"view_image","viewed_files":["reference.png","reference-b.png","art/reference-review/comparison.png"],"coverage":"Both actual 32x32 sources, native 32x32 board insets and 8x nearest views on light, dark and muted teal diagnostic backgrounds.","observations":"Shared angular teal face-like forms, squared upper protrusions, top notch and cream eyes. A has navy perimeter and upper protrusions; B fills the same silhouette teal. A separates more explicitly on light and muted teal; its dark perimeter has weaker separation on dark. B's teal perimeter reads more clearly on dark. Neither source establishes side-facing body construction.","limits":"Host-rendered static views only; physical device pixel mapping, real game background readability, generated scout/medic quality, animation and engine behavior were not checked. No outline alternative is accepted as the production winner."}
save("art/research/intake-local-review.json",local)
save("art/research/intake-visual-review.json",visual)
add("x.intake_report","X",nm="Completed intake reference review and sample plan",ur="art/PROJECT.md",dg=digest("art/PROJECT.md"),kd=sym("report"),of=ref("f.intake"),mt={"comparison":ref("x.reference_board"),"observations":ref("s.observations"),"research":ref("s.assessment"),"methods":refs("k.silhouette-readability","k.edge-rhythm"),"limits":"Reference review only; no generated character acceptance"})
save(".pixl/candidates/review-draft.json",doc)
cli("encode",".pixl/candidates/review-draft.json","--out",".pixl/candidates/review-draft.px")
validation=json.loads(cli("validate",".pixl/candidates/review-draft.px","--root",ROOT))
hashes=validation["record_hashes"]
index={r["id"]:r for r in records}
semantic={"A","S","R","C","K","D","X","I","F","Q"}
def mentioned(value):
    if isinstance(value,dict):
        if set(value)=={"$ref"}: yield value["$ref"]
        else:
            for item in value.values(): yield from mentioned(item)
    elif isinstance(value,list):
        for item in value: yield from mentioned(item)
def closure(*ids):
    found=set()
    def visit(id):
        if id in found or index[id]["kind"] not in semantic:return
        found.add(id)
        for child in mentioned(index[id]["fields"]):visit(child)
    for id in ids:visit(id)
    return sorted(found)
for suffix,qid,mode,path in [("trace","q.research_trace","local","art/research/intake-local-review.json"),("view","q.research_view","visual","art/research/intake-visual-review.json")]:
    eid="e.intake_"+suffix
    vid="v.intake_"+suffix
    add(eid,"E",nm="Intake report "+suffix+" review",ur=path,dg=digest(path),rs=sym("pass"),md=sym(mode),at=at,bs=[{"rf":ref(x),"dg":hashes[x]} for x in closure("x.intake_report",qid)])
    add(vid,"V",tk=ref("t.intake"),rq=ref(qid),xr=ref("x.intake_report"),st=sym("pass"),wh=ref("actor"),wy="Actual source review and retained report satisfy this research criterion; this does not accept character production or engine use.",at=at,ev=refs(eid))
index["t.intake"]["fields"].update(st=sym("done"),ca=refs("x.intake_report"),vr=refs("v.intake_trace","v.intake_view"))
index["n.handoff"]["fields"].update(fo=refs("x.intake_report","i.canvas","i.outline","i.provider","f.scout","f.medic","f.delivery"),nx=refs("t.scout"),rv=doc["revision"])
save(".pixl/candidates/intake-review.json",doc)
cli("encode",".pixl/candidates/intake-review.json","--out",".pixl/candidates/intake-review.px")
validated=json.loads(cli("validate",".pixl/candidates/intake-review.px","--root",ROOT))
print(json.dumps({k:validated[k] for k in ["valid","revision","records","files_verified"]}))
print(cli("commit",".pixl",".pixl/candidates/intake-review.px","--expect",current["hash"],"--root",ROOT))
