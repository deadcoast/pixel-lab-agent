The scout/medic project has begun in PIXL. Reference inspection and method research are complete; the two character sprites remain planned outputs. Final canvas size and outline treatment are still open.

[View the reference comparison](reference-review/comparison.png). It contains actual source art at native size and 8x nearest enlargement on three diagnostic backgrounds. It contains no generated characters.

| Source property | reference.png | reference-b.png |
| --- | --- | --- |
| Canvas | 32x32 | 32x32 |
| Visible bounding box, exclusive max | [7, 3, 25, 28] | [7, 3, 25, 28] |
| Opaque pixels | 390 | 390 |
| Teal #56B5BC | 186 pixels | 366 pixels |
| Cream #F4DDA2 | 24 pixels | 24 pixels |
| Navy #25354A | 180 pixels | absent |
| Alpha | 0 or 255 | 0 or 255 |

The silhouettes are identical. Every changed pixel switches from navy to teal. Reference A uses a dark band around the face and dark upper protrusions; B uses teal through the outer edge. Neither image establishes a full side-facing body, a species, equipment or an animation contract. The user explicitly requested a side-view game, so the first character must test that adaptation.

At native size and 8x, I observed angular teal forms, squared upper protrusions, a wide top notch and cream eye marks in both. A's boundary separates more explicitly on light and muted teal backgrounds; its navy edge and upper protrusions have weaker separation on the dark background. B's teal boundary is clearer against the dark background. These backgrounds were chosen for diagnosis; the actual game scene and display scale are unknown. Neither alternative is declared the winner.

The source hashes and detailed counts are retained in [measurements.json](reference-review/measurements.json); viewing coverage and limits are in [observations.txt](reference-review/observations.txt). The reference image bytes remain unchanged.

| Family member | Proposed identifying features | Planned output |
| --- | --- | --- |
| Scout | Forward-looking cream eye/visor, compact field pack, attentive side-facing stance | f.scout: representative standing sprite |
| Medic | Cream medical satchel, calmer standing stance, shared head/body construction | f.medic: sprite based on the exact accepted scout |

These features are proposals. They retain the teal/cream vocabulary and let equipment shape distinguish the roles without assuming a red accent, human anatomy or a military setting. A readable full body must be designed and inspected in the sample.

The proposed first experiment is one right-facing standing scout at a provisional 32x32, comparing the two edge treatments while holding pose, silhouette and color landmarks steady. The final canvas stays unresolved. If 32x32 cannot carry a readable pack and side-facing eye, preserve that failed result and propose a larger trial. Do not adopt 48x48 or upscale the references as a substitute for that test. A user preference question about outline and trial canvas was issued; no response has been recorded in this report.

Candidate methods are `silhouette-readability` and `edge-rhythm`. Their exact source slices, prerequisites, source applicability assessment and fixture limitations are retained in [assessment.txt](research/assessment.txt), [exact-source-slices.json](research/exact-source-slices.json), and the corresponding method JSON files. The narrow source paragraphs support preserving identifying clusters and distinguishing outline from eye/shading; they do not select a dark outline or a canvas. The asset archive citation concerns another project's keyboard UI and is not imported as a character requirement. The bundled key and staircase proofs are reference fixtures, not proof for these characters. No production design decision or project character proof has been adopted.

[review-plan.txt](review-plan.txt) defines the tests before candidate evaluation:

- Scout: measure the chosen trial canvas/alpha and inspect side-facing identity, role landmarks and edge separation at native size and integer zoom.
- Medic: measure agreement with the accepted scout contract and inspect distinctive satchel shape with shared head, eye and edge treatment.
- Family: inspect the exact selected pair together for volume, color relationships, lighting, ground alignment and distinct roles.
- Engine: test sampling, scale, alpha, orientation and ground pivots in the actual destination scene. No engine or target project was supplied; import remains unperformed.

The session exposes local PIXL operations but no actual PixelLab generation, polling or download tool. [tool-discovery.json](research/tool-discovery.json) retains that discovery. No remote request, charge, job ID, character candidate or generation success is claimed. The isolated project and plugin remain separate: generated state and review files live outside the packaged runtime; no packages or host settings were changed.

Continue from [.pixl/state.px](../.pixl/state.px). Read `workflow`, `family` and `jobs` first. Resolve a concrete trial canvas and edge experiment, discover an actual PixelLab tool/schema, and save provider intent against `t.scout` / `f.scout` before any dispatch. After the scout passes its saved criteria, confirm the production choices and record an applicable proof-backed decision. Then attach that exact nominated scout X as `f.medic.bs`, add it to the medic task inputs, and produce the medic.

The planned final member order is scout, then medic. After a real baseline exists, bind `f.delivery.bs`, `f.delivery.mb=[f.scout,f.medic]`, and the relevant destination choices through `ds`. These fields are intentionally pending because no baseline bytes exist. The current generic delivery plan is not a retained family package. Generate the actual family snapshot only after member acceptance, then review continuity and destination import separately.
