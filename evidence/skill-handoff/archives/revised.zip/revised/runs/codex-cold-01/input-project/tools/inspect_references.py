"""Create inspection views and measurements; never alter source art."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "art" / "reference-review"
OUT.mkdir(parents=True, exist_ok=True)
names = ["reference.png", "reference-b.png"]
report = {"observed_at": datetime.now(timezone.utc).isoformat(), "purpose": "Source inspection only; no character candidate or style acceptance", "references": []}
board = Image.new("RGB", (888, 700), "#ece7db")
draw = ImageDraw.Draw(board)
draw.text((20, 12), "SOURCE COMPARISON | native + 8x nearest | display backgrounds are diagnostic proposals", fill="#20232b")
backgrounds = [("LIGHT", "#f4efdf"), ("DARK", "#17202b"), ("TEAL", "#487878")]
images = []
for row, name in enumerate(names):
    im = Image.open(ROOT / name).convert("RGBA")
    images.append(im)
    y = 44 + row * 316
    draw.text((20, y), name + " | source canvas 32 x 32", fill="#20232b")
    colors = Counter(p for p in im.getdata() if p[3])
    entry = {"path": name, "sha256": sha256((ROOT / name).read_bytes()).hexdigest(), "size": list(im.size), "bbox": list(im.getbbox()), "visible_pixels": sum(colors.values()), "rgba_counts": [{"rgba": list(c), "count": n} for c, n in colors.most_common()], "alpha_values": sorted(set(im.getchannel("A").getdata()))}
    report["references"].append(entry)
    for col, (label, color) in enumerate(backgrounds):
        x = 20 + col * 288
        draw.text((x, y + 20), label + " / 8x", fill="#20232b")
        bg = Image.new("RGBA", im.size, color)
        bg.alpha_composite(im)
        board.paste(bg.resize((256, 256), Image.Resampling.NEAREST).convert("RGB"), (x, y + 38))
        board.paste(bg.convert("RGB"), (x + 212, y + 1))
        draw.text((x + 166, y + 11), "native", fill="#20232b")
report["same_alpha_mask"] = images[0].getchannel("A").tobytes() == images[1].getchannel("A").tobytes()
report["changed_rgba_pixels"] = sum(a != b for a, b in zip(images[0].getdata(), images[1].getdata()))
board.save(OUT / "comparison.png")
(OUT / "measurements.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
