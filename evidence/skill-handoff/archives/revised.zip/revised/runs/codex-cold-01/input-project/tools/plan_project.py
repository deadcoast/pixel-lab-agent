"""Publish the initial project plan through the packaged PIXL CLI."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / ".agents/skills/pixl-kit/scripts/pixl.py"
def cli(*args):
    r = subprocess.run([sys.executable, str(RUNNER), *map(str, args)], cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    if r.returncode:
        raise RuntimeError(r.stdout + r.stderr)
    return r.stdout
def ref(x): return {"$ref": x}
def refs(*xs): return [ref(x) for x in xs]
def sym(x): return {"$symbol": x}
def digest(path): return sha256((ROOT / path).read_bytes()).hexdigest()

current = json.loads(cli("validate", ".pixl/state.px", "--root", ROOT))
doc = json.loads(cli("decode", ".pixl/state.px"))
if doc["revision"] != 0:
    raise RuntimeError("Initial planning already published. Decode current state and reconcile instead of rerunning.")
doc["revision"] += 1
records = doc["records"]
def add(id, kind, **fields):
    records.append({"id": id, "kind": kind, "fields": fields})
def source(id, path, lines=None):
    add(id, "S", ur=path, dg=digest(path), ln=lines if lines is not None else [1, len((ROOT/path).read_text(encoding="utf-8").splitlines())], at="2026-09-14", au=sym("local"))
source("s.brief", "art/brief.txt")
source("s.plan", "art/review-plan.txt")
source("s.reference_a", "reference.png", [])
source("s.reference_b", "reference-b.png", [])
source("s.observations", "art/reference-review/observations.txt")
source("s.measurements", "art/reference-review/measurements.json")
source("s.discovery", "art/research/tool-discovery.json")
source("s.assessment", "art/research/assessment.txt")
source("s.slices", "art/research/exact-source-slices.json")
base = ".agents/skills/pixl-kit/resources/"
source("s.clusters", base + "training/original-docs/PIXEL-ART-DEEP-RESEARCH.md", [857,867])
source("s.temporal", base + "training/original-docs/PIXEL-ART-DEEP-RESEARCH.md", [1563,1573])
source("s.edges", base + "training/original-docs/PIXEL-ART-DEEP-RESEARCH.md", [1402,1431])
source("s.ui_scope", base + "training/original-docs/PIXEL-ART-ASSETS.md", [11,15])
source("s.applicability", base + "knowledge/applicability.json")
for id, name in [("x.reference_a","reference.png"),("x.reference_b","reference-b.png"),("x.reference_board","art/reference-review/comparison.png")]:
    add(id,"X",nm=name,ur=name,dg=digest(name),kd=sym("reference"))
choice_ids=[]
def choice(id,key,status,value,why,who="actor",sources=("s.brief",)):
    choice_ids.append(id)
    add(id,"I",pr=ref("project"),wh=ref(who),ky=key,st=sym(status),vl=value,so=refs(*sources),wy=why)
choice("i.roles","family_roles","confirmed",["scout","medic"],"Both roles are explicitly requested.","user")
choice("i.view","vw","confirmed",sym("side"),"The target game is side-view; source pose does not override the brief.","user")
choice("i.canvas","px","unresolved",None,"The user explicitly has not chosen the final canvas. Reference dimensions do not confirm output dimensions.","user")
choice("i.outline","edge_treatment","conflict",["reference.png: navy #25354A outer band and upper protrusions","reference-b.png: teal #56B5BC outer edge; no contrasting dark border"],"Identical silhouettes disagree about contrasting dark treatment. Await source precedence or a controlled comparison.","user",("s.brief","s.reference_a","s.reference_b","s.observations"))
choice("i.source_size","reference_canvas","observed",[32,32],"Both actual input PNGs measure 32x32.",sources=("s.reference_a","s.reference_b","s.measurements"))
choice("i.source_palette","reference_colors","observed",["#56B5BC","#F4DDA2","#25354A (A only)"],"Source colors only; no exact output palette has been adopted.",sources=("s.measurements",))
choice("i.source_alpha","reference_alpha","observed","binary: 0 or 255","Observed in both references; no final output alpha policy is confirmed.",sources=("s.measurements",))
choice("i.vocabulary","shared_forms","observed","Angular teal face-like form, cream eye marks, square upper protrusions, wide central notch","References share these features; species, body and side-view anatomy remain unspecified.",sources=("s.observations","s.reference_a","s.reference_b"))
choice("i.trial_canvas","trial_canvas","proposed",[32,32],"A 32x32 scout test would preserve the source scale and expose role-detail constraints. It is not the final canvas choice.",sources=("s.plan","s.measurements"))
choice("i.trial_pose","trial_pose","proposed","one right-facing standing scout","Smallest useful side-view proof before directions or animation.",sources=("s.plan",))
choice("i.role_landmarks","role_landmarks","proposed",["scout: cream visor/eye and compact field pack","medic: cream medical satchel with shared body construction"],"Distinguish equipment shape at native scale without assuming a new accent color.",sources=("s.plan","s.observations"))
choice("i.palette_policy","palette_policy","unresolved",None,"Decide whether output color membership is fixed or allows related shades after the sample; observed color counts are not a production rule.","user")
choice("i.alpha_policy","alpha_policy","proposed","transparent PNG with binary alpha for the first test","Matches the measured source edges; remains a proposal until a concrete trial is saved.",sources=("s.measurements","s.plan"))
choice("i.lighting","lighting","unresolved",None,"Flat source fills do not establish a lighting direction.","user")
choice("i.backgrounds","game_backgrounds","unresolved",None,"No real side-view scene backgrounds were supplied. Comparison board colors are diagnostic only.","user")
choice("i.display","target_display_scale","unresolved",None,"No gameplay display scale was supplied; native source inspection cannot establish final screen readability.","user")
choice("i.engine","destination_engine","unresolved",None,"No engine, version or destination project is present.","user")
choice("i.pivot","ground_pivot","unresolved",None,"The source face-like form has no proven feet; define contact and pivot after side-view body construction.","user")
choice("i.animation","animation_scope","unresolved",None,"No action list, frame timing or direction set was requested. The first proposed proof is static.","user")
choice("i.provider","pixellab_availability","observed","No remote PixelLab tools exposed; local PIXL tools are available","Tool metadata was inspected in this session. No provider schema, job, submission or authentication test exists.",sources=("s.discovery",))
for row in records:
    if row["id"]=="project":
        row["fields"]["in"]=refs(*choice_ids)
        row["fields"]["sc"]=refs("s.brief","s.reference_a","s.reference_b","s.observations")
for name, aps, sos in [("silhouette-readability",["characters_25d939ff","inventory_icons_f7812ea4","interactive_props_25a44283"],["s.clusters","s.temporal","s.ui_scope"]),("edge-rhythm",["clean_linework_08dea3fe","small_curved_forms_e37a2e1c","hard_silhouettes_99485584"],["s.edges","s.clusters"])]:
    path="art/research/"+name+".json"
    source("s.method."+name,path)
    method=json.loads((ROOT/path).read_text(encoding="utf-8"))
    add("k."+name,"K",nm=method["title"]+" (candidate; project proof pending)",ap=[sym(x) for x in aps],op=method["procedure"],ck=method["checks"],rq=method["requires"],rk=method["pitfalls"]+["Bundled fixture receipts do not prove this character contract; source transfer is limited as recorded."],so=refs(*sos,"s.method."+name,"s.applicability","s.assessment"))
def criterion(id,name,domain,mode,check,sources=("s.plan",)):
    add(id,"Q",nm=name,dm=sym(domain),md=sym(mode),ck=check,wh=ref("actor"),so=refs(*sources))
criterion("q.research_trace","Reference and method traceability","other","local","Retain actual source identities, measurements, conflicting alternatives, exact method sources and transfer limits, capability boundary and next sample action; keep confirmed, observed, proposed and unknown choices distinct.",("s.plan","s.brief","s.reference_a","s.reference_b","s.measurements","s.assessment","s.discovery"))
criterion("q.research_view","Actual reference viewing","visual","visual","Open both reference PNGs and saved native/8x comparison; describe shared form and edge differences on displayed backgrounds, naming display limits without accepting a generated character.",("s.plan","s.reference_a","s.reference_b"))
criterion("q.scout_mechanical","Scout file contract","mechanical","local","Retained single-frame PNG matches the saved trial canvas and selected alpha policy without clipping required landmarks; enforce palette membership only if the contract requires it.")
criterion("q.scout_visual","Side-view scout and edge proof","visual","visual","Inspect actual scout at native size and integer zoom on target backgrounds: side-facing eye/visor and compact field pack are legible, shared angular teal/cream identity survives; compare edge alternatives with other variables held stable and retain confounds or unavailable context.")
criterion("q.medic_mechanical","Medic matches baseline dimensions","mechanical","local","Retained medic PNG matches the accepted scout baseline canvas and selected alpha policy without clipping its medical satchel.")
criterion("q.medic_visual","Medic identity and shared style","visual","visual","At native scale the cream medical satchel makes the medic distinct from the scout without relying only on recolor; head proportions, eye treatment, palette relationships and edge logic agree with the exact approved baseline.")
criterion("q.family_continuity","Collective character continuity","continuity","visual","View the exact scout baseline and medic together at native size and integer zoom on the same backgrounds; compare volume, eye scale, edges, lighting and ground contact while preserving distinct role landmarks. Static review does not verify animation.")
criterion("q.engine","Destination scene import","engine","live","Import both selected files into the actual destination engine/project and verify chosen sampling, display scale, alpha compositing, side-view orientation and ground pivots in the game scene. No target project is currently available.")
def task(id,name,phase,state,deps,outputs,inputs=(),knowledge=()):
    add(id,"T",nm=name,ow=ref("actor"),pr=ref("project"),dp=refs(*deps),dc=[],kn=refs(*knowledge),st=sym(state),ph=sym(phase),ip=refs(*inputs),op=refs(*outputs),ca=[],vr=[])
methods=("k.silhouette-readability","k.edge-rhythm")
task("t.intake","Inspect references and research representative proof","research","active",(),("f.intake",),("x.reference_a","x.reference_b","x.reference_board"),methods)
task("t.scout","Prove one side-view scout after resolving trial canvas and edges","sample","blocked",("t.intake",),("f.scout",),("x.reference_a","x.reference_b"),methods)
task("t.medic","Extend exact accepted scout baseline into a medic","production","blocked",("t.scout",),("f.medic",),(),methods)
task("t.delivery","Compare scout and medic and verify destination import","delivery","blocked",("t.scout","t.medic"),("f.delivery",))
for id,taskid,name,kind,requirements in [
    ("f.intake","t.intake","Reference review and source-grounded sample plan","report",("q.research_trace","q.research_view")),
    ("f.scout","t.scout","Representative side-view scout","sprite",("q.scout_mechanical","q.scout_visual")),
    ("f.medic","t.medic","Medic derived from accepted scout","sprite",("q.medic_mechanical","q.medic_visual")),
    ("f.delivery","t.delivery","Future scout/medic delivery report; exact baseline pending","report",("q.family_continuity","q.engine"))]:
    add(id,"F",tk=ref(taskid),nm=name,kd=sym(kind),rq=refs(*requirements))
add("n.handoff","N",wh=ref("actor"),fo=refs("i.canvas","i.outline","i.provider","f.scout","f.medic","f.delivery"),nx=refs("t.intake"),bl=refs("t.scout","t.medic","t.delivery"),rv=doc["revision"])
candidate=ROOT/".pixl/candidates/plan.json"
candidate.parent.mkdir(parents=True,exist_ok=True)
candidate.write_text(json.dumps(doc,indent=2)+"\n",encoding="utf-8")
wire=candidate.with_suffix(".px")
cli("encode",candidate,"--out",wire)
validated=json.loads(cli("validate",wire,"--root",ROOT))
print(json.dumps({k:validated[k] for k in ["valid","revision","records","files_verified"]}))
print(cli("commit",".pixl",wire,"--expect",current["hash"],"--root",ROOT))
