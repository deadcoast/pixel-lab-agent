Start with [the project review](art/PROJECT.md) and [the source comparison](art/reference-review/comparison.png).

Authoritative PIXL state: `.pixl/state.px`, PX2 revision 2, canonical SHA-256 `eb3af18a5e5fae4769d6768dcb6a2e09546fc59def8ff23957a603972c46ee7a`. Structural, reference, receipt and retained-file validation passed.

Completed: `t.intake`, with nominated report `x.intake_report` and separate local traceability and visual reference-review receipts. These verdicts accept the intake report only.

Next: `t.scout` / `f.scout`. Final canvas `i.canvas` remains unresolved; `i.outline` retains both reference alternatives as a conflict. A 32x32 right-facing scout trial and role equipment are proposals. No concrete raster contract has been published. Resolve the trial canvas/edge experiment before dependent execution; a trial need not settle the final delivery canvas.

Capability boundary: this session exposed local PIXL tools and no callable PixelLab submit, poll or download tool/schema. There are zero saved provider jobs and zero generated character candidates. Rediscover actual tools in the next session; do not invent or dispatch a provider request using cached capability names.

The medic task depends on the accepted scout. Save the exact nominated scout baseline, production decision and proof before medic generation. The delivery plan has separate continuity and engine criteria, but no family manifest or baseline exists yet. Target engine, game backgrounds, display scale and ground pivot remain unknown.

From this project directory, read the current reports before acting:

```powershell
$pixlPython = 'C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe'
$pixlRunner = (Resolve-Path '.agents/skills/pixl-kit/scripts/pixl.py').Path
& $pixlPython $pixlRunner workflow '.pixl/state.px' --root '.'
& $pixlPython $pixlRunner family '.pixl/state.px' --root '.'
& $pixlPython $pixlRunner jobs '.pixl/state.px' --root '.'
& $pixlPython $pixlRunner context '.pixl/state.px' 't.scout' --budget 40000
```

Derived status snapshots are in `art/status/`; regenerate them from authoritative state after changes. Use decode/edit/encode/validate/commit with the current expected hash for state changes. Preserve the retained reference-review files and prior evidence; create new paths and revisions when observations change. The session scripts in `tools/` document the performed work, and the state-publishing scripts refuse blind reruns.

Keep work in this project. Do not install packages or change host configuration. Before any real PixelLab action, use the packaged provider-recovery operation to save the exact discovered request against its task/output plan, claim dispatch once, observe the actual result and import returned bytes as unaccepted candidates. No generation or engine testing has already occurred.
