# Proposed first proof — not a confirmed style contract

Start with a single right-facing scout idle pose. Preserve the references' compact angular body, upright extensions, teal mass and cream focal detail while exploring a side-facing silhouette. Propose a low-profile field pouch and a forward-looking monocular as scout landmarks. Avoid relying on an emblem alone to convey the role.

After scout acceptance, build the medic from the exact nominated scout baseline. Propose a broader medical satchel with a cream bandage motif and a small visible dressing roll. Keep shared body proportions, eye treatment, ground contact, lighting and selected outline behavior. Role props should distinguish the two characters before fine detail is read. These equipment choices are agent proposals, not user-confirmed facts.

Suggested canvas investigation: 32×32, matching observed reference dimensions, and 48×48, allowing more room for side-facing equipment. These are distinct authored trial canvases, not a 1.5× resampling instruction and not the final game size. Compare equivalent poses and normalized proportions so extra canvas area is not mistaken for a better design.

Suggested outline investigation: source-like navy border versus unoutlined teal edges on the same pose and canvas. Keep shared geometry fixed as far as possible to isolate edge treatment. Determine the border's trial thickness explicitly at each canvas; the reference uses roughly two pixels around its body. There is no selected winner.

Smallest initial proof: one scout pose at one explicitly scoped trial canvas and edge treatment. If the user chooses comparison, use a controlled two-outline/two-canvas matrix of four scout candidates before producing the medic. Final canvas and outline choices remain unresolved until the user supplies a preference or reviews the samples.

Before generation, instantiate concrete trial C records from proposed choices and save a separate F for every intended trial candidate. Keep final canvas and final outline choices separate. Save conditions before evaluating results; do not fabricate output files or adopted D records.
