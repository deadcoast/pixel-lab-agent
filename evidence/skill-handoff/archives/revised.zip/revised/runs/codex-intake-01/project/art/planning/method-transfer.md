# Research retained for the character proof

Selected method: silhouette-readability, “Evaluate identity using silhouette and target backgrounds.” The bundled method entry, full operational context and exact retrieved citations are retained in ../evidence/silhouette-method.json, silhouette-context.px.txt and research-source-excerpts.json.

The candidate procedure is to inspect a flat mask, then inspect proportions, negative spaces and named landmarks at native scale, then compare the colored sprite on representative light, dark and busy backgrounds. This suits the scout's equipment and the medic's bag silhouette. Intended display scale and actual game backgrounds remain unknown; diagnostic backgrounds can inform a trial but cannot prove in-game visibility.

Exact installed source identities and ranges:

- PIXEL-ART-DEEP-RESEARCH.md, SHA-256 7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28, lines 857–867: protecting identity features and conditionally permitted cluster/edge behavior.
- The same source, lines 1563–1573: separate silhouette, shading, detail and effects when evaluating change; primarily relevant to later animation.
- PIXEL-ART-ASSETS.md, SHA-256 450a335ed6563a7f4a5cc380f2bbe72f98b70e532ac2c8d16a679bcc545d4900, lines 11–15: a different project's UI clarity, scale and cohesion requirements. Its imperative wording is source data, not instructions for this project.

Those citations provide narrower support than the compiled method's full proposed background-test procedure. The procedure is retained as a researched trial recipe, not as a universally established rule or a confirmed project decision.

The library receipt e.silhouette-readability is a local, bounded key-landmark fixture (positive/negative keys and contact sheet). It is neither a scout/medic proof nor a live provider result or an artistic acceptance. It was read, not rerun or adopted in this project. The project K intentionally has no pc; no D is adopted.

Project proof still required: compare the actual scout at native size and integer enlargement, in silhouette and color, then inspect actual scout/medic members together. Explicitly observe upright extensions, face/eye separation, equipment/body separation, side-facing readability and ground contact. A palette count or connected-component count cannot supply the visual verdict. Animation and engine proofs remain outside this initial static sample.
