# Reference observations — 2026-09-14

PIXL inspected both original PNGs through the host at native 32×32 resolution and inspected reference-comparison-8x.png at its original 768×512 resolution. The board uses nearest-neighbor enlargement only; rows are reference.png then reference-b.png, columns are neutral, light and dark diagnostic backgrounds. These backgrounds are test aids, not supplied game scenes.

Both references depict the same rectangular teal creature with two upright ear-like extensions, an open notch between them, and two pale rectangular eyes. They provide shape and color references, not an established side-facing scout or medic design. Species and setting were not specified.

reference.png has a dark navy border around the body, approximately two source pixels thick along its sides and bottom, with solid dark ear-like extensions. reference-b.png fills those same regions with teal and has no contrasting outline. Do not silently translate reference.png to a universal one-pixel outline rule.

Visually, the navy border has less separation from the dark diagnostic background; the teal silhouette in reference-b.png separates more clearly there. This is a reference observation, not acceptance of a future character or a determination of the game's intended background.

PIXL asset-check measured 32×32 pixels, one frame, 390 visible pixels, one opaque component, binary alpha and visible bounds [7,3,25,28] (right/bottom exclusive) for each reference. reference.png has three visible colors; reference-b.png has two. The observed colors are teal #56B5BC and cream #F4DDA2, plus navy #25354A in reference.png. Exact palette restriction and alpha policy have not been selected for output art.

Native dimensions are observations only. The user explicitly has not selected final canvas dimensions. Side-view gameplay comes from the user's brief; the two frontal eye marks in the references do not establish facing direction for output sprites.
