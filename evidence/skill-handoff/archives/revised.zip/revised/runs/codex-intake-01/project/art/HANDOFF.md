# Resume the scout and medic family

Project root: `C:/Users/ryanf/github/TODO/pixel-lab-docsuite/build/handoff-projects/pixl-host-trial-p4eas2ne`

Authoritative production state: `.pixl/state.px` (PX2). Historical committed snapshots are under `.pixl/history/`. JSON adapters and candidate files are editing aids, not the state authority. Work only in this project; do not install packages or change host settings.

Useful retained files: [family brief](planning/family-brief.md), [interactive source viewer](reference-review.html), [inspected 8× comparison](evidence/reference-comparison-8x.png), [reference observations](evidence/reference-observations.md), [method transfer](planning/method-transfer.md), and [tool inventory](evidence/tool-discovery.json).

The references were viewed at native scale and 8× nearest enlargement. Mechanical checks and the pixel comparison show identical 32×32 alpha silhouettes; 180 visible pixels differ from navy to teal. These are source observations only. The HTML viewer has not been exercised in a browser; its source paths are checked locally. No character samples or engine project exist.

Start cold sessions with local `pixl_family`, `pixl_workflow`, and `pixl_jobs`, each using `{ "path": ".pixl/state.px" }`. Read `pixl_context` for `t.scout` after inspecting those reports. The equivalent PowerShell commands use the selected interpreter and bundled runner:

```powershell
$pixlPython = 'C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe'
$pixlRunner = '.agents/skills/pixl-kit/scripts/pixl.py'
& $pixlPython $pixlRunner family .pixl/state.px --root .
& $pixlPython $pixlRunner workflow .pixl/state.px --root .
& $pixlPython $pixlRunner jobs .pixl/state.px --root .
& $pixlPython $pixlRunner context .pixl/state.px t.scout --budget 48000
```

State intent: finish `t.intake` only against the retained report's local completeness criterion. `t.scout` remains open with `f.scout` planned and no C/X; `t.medic` depends on scout acceptance; `t.delivery` depends on both members and actual destination review. Open does not mean ready: read reported blockers. `family` returns no eligible family until an actual accepted sample can be bound. `jobs` returns no jobs; no provider submission or remote identifier exists.

The pending user questions are the outline direction (navy border, unoutlined edges, or compare both) and trial canvas (32×32, 48×48, or compare). The final canvas stays unresolved unless explicitly chosen. No response arrived before this handoff. The canvas comparison and equipment landmarks in `proposals.md` remain proposals. The user already authorized project work; do not ask for general permission again.

Next concrete operation: retain any user answer as a source, update the appropriate I statuses, and save proposed trial C records and the required per-trial F plans. If no preference is supplied, a future available sample operation may investigate an explicitly proposed controlled trial without claiming a confirmed final style. Missing final size does not block unrelated research. The present sample has no concrete contract, so it cannot activate as saved.

The current session has no authenticated PixelLab generation/status/download tools. Discover the real exposed schemas in a future session; a cached catalog does not establish availability. Then read the packaged provider-recovery operation, check workflow/jobs, prepare exact intent, claim dispatch, execute once through the real provider, retain real observations and import the downloaded candidate. Do not substitute elapsed time, local fixtures, this comparison board or another tool's output for a PixelLab result.

For the actual candidate, use the packaged inspection operation: save native/enlarged views and measurements, view them through the host, retain honest criterion reviews, and keep failed candidates. The method K is researched but unproven for this asset. It has no adopted D or borrowed fixture E. Do not skip the representative proof before production.

After scout acceptance and confirmation of production choices, publish the adopted decision with actual applicable proof. Set `f.medic.bs` and `t.medic.ip` to the exact still-nominated scout X; retain `t.scout` as a direct dependency. Complete the family output with the same `bs`, ordered `mb=[f.scout,f.medic]`, and same-project destination `ds` choices. Save these semantic plans before producing/evaluating dependent results. The current plain delivery plan is intentionally not a retained family package.

Inspect the accepted scout/medic files together for collective continuity, then retain the delivery snapshot through PIXL. Engine/project, display scale, backgrounds, paths and pivot choices still require destination context. Actual import remains unperformed. Once there is a candidate, use an unavailable engine V with no E if the engine is still inaccessible, and leave delivery unfinished.

For every state change decode, amend, increment the revision, encode and validate a candidate, then commit with the hash freshly returned by validation. Preserve failed or superseded evidence. Read the final validation/workflow/job/family reports in `evidence/` for the last recorded snapshot; re-run them before changing state.
