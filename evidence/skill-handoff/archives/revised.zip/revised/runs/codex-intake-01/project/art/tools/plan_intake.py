"""Build a candidate adapter; publish only through PIXL's expected-hash commit."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
RUNNER = ROOT / '.agents/skills/pixl-kit/scripts/pixl.py'

def cli(*args):
    return subprocess.check_output([sys.executable, str(RUNNER), *map(str, args)], cwd=ROOT, text=True, encoding='utf-8')

def digest(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()

def ref(value):
    return {'$ref': value}

def sym(value):
    return {'$symbol': value}

def main():
    doc = json.loads(cli('decode', '.pixl/state.px'))
    if doc['revision'] != 0:
        raise SystemExit('Initial plan already prepared; resume the saved state instead.')
    records = doc['records']
    def add(identifier, kind, **fields):
        records.append({'id': identifier, 'kind': kind, 'fields': fields})
    def source(identifier, path, lines=None):
        line_range = lines if lines is not None else [1, len((ROOT / path).read_text(encoding='utf-8').splitlines())]
        add(identifier, 'S', ur=path, dg=digest(path), ln=line_range, at='2026-09-14', au=sym('local'))
    for identifier, path in [
        ('s.brief', 'art/evidence/user-brief.txt'),
        ('s.observations', 'art/evidence/reference-observations.md'),
        ('s.measurements', 'art/evidence/pixl-reference-checks.json'),
        ('s.tools', 'art/evidence/tool-discovery.json'),
        ('s.proposals', 'art/planning/proposals.md'),
        ('s.transfer', 'art/planning/method-transfer.md'),
        ('s.method', 'art/evidence/silhouette-method.json'),
        ('s.excerpts', 'art/evidence/research-source-excerpts.json'),
    ]:
        source(identifier, path)
    for identifier, path in [('s.reference.a', 'reference.png'), ('s.reference.b', 'reference-b.png')]:
        source(identifier, path, [])
    base = '.agents/skills/pixl-kit/resources/training/original-docs/'
    source('s.identity', base + 'PIXEL-ART-DEEP-RESEARCH.md', [857,867])
    source('s.temporal', base + 'PIXEL-ART-DEEP-RESEARCH.md', [1563,1573])
    source('s.ui.scope', base + 'PIXEL-ART-ASSETS.md', [11,15])
    for identifier, path in [('x.reference.a', 'reference.png'), ('x.reference.b', 'reference-b.png'), ('x.comparison', 'art/evidence/reference-comparison-8x.png')]:
        add(identifier, 'X', nm=path, ur=path, dg=digest(path), kd=sym('reference'))
    choices=[]
    def choice(identifier, key, status, value, sources, why, actor='actor'):
        choices.append(ref(identifier))
        add(identifier, 'I', pr=ref('project'), wh=ref(actor), ky=key, st=sym(status), vl=value, so=list(map(ref,sources)), wy=why)
    choice('i.members','members','confirmed',['scout','medic'],['s.brief'],'The user requested both roles.','user')
    choice('i.view','vw','confirmed',sym('side'),['s.brief'],'The family is for a side-view game; pose direction is a separate proposal.','user')
    choice('i.canvas','px','unresolved',None,['s.brief'],'The final canvas has not been chosen. Reference dimensions are not a decision.','user')
    choice('i.outline','edge_treatment','conflict',['source-like navy body border','unoutlined teal edges'],['s.brief','s.reference.a','s.reference.b','s.observations'],'The references disagree. Ask which to follow or whether to compare; retain both until resolved.','user')
    choice('i.reference.size','reference_canvas','observed',[32,32],['s.measurements'],'Both source files are 32×32; this does not set output dimensions.')
    choice('i.reference.colors','reference_colors','observed',['#56B5BC','#F4DDA2','#25354A'],['s.observations','s.reference.a','s.reference.b'],'Teal and cream occur in both; navy occurs only in reference.png. No fixed output palette has been adopted.')
    choice('i.shape','shared_form','observed','compact rectangular teal form, two upright extensions, pale rectangular eyes',['s.observations','s.reference.a','s.reference.b'],'Observed shared visual vocabulary; adapting it to side view needs a sample.')
    choice('i.trial','trial_canvas_options','proposed',[[32,32],[48,48]],['s.proposals'],'Compare the source-size option with a larger equipment-readability option; not final canvases.')
    choice('i.pose','initial_pose','proposed','one right-facing static idle',['s.proposals'],'A bounded pose tests side-view identity before any animation or batch.')
    choice('i.roles','role_landmarks','proposed',{'scout':'field pouch and forward-looking monocular','medic':'broader satchel, cream bandage motif and dressing roll'},['s.proposals'],'Different role silhouettes without inventing a faction, species or approved equipment design.')
    choice('i.display','display_scale','unresolved',None,['s.brief'],'Intended in-game display size has not been supplied.','user')
    choice('i.backgrounds','game_backgrounds','unresolved',None,['s.brief'],'No game backgrounds were supplied; reference test backgrounds are diagnostic only.','user')
    choice('i.engine','destination_engine','unresolved',None,['s.brief'],'No target engine/project/version is supplied. Future import acceptance requires the actual destination.','user')
    choice('i.provider','pixel_lab_availability','observed','unavailable in session tool inventory',['s.tools'],'Local PIXL tools do not generate. No authenticated PixelLab generation/status/download tool is exposed.')
    project = next(r['fields'] for r in records if r['id']=='project')
    project['in']=choices
    project['sc']=list(map(ref,['s.brief','s.reference.a','s.reference.b','s.observations']))
    method=json.loads((ROOT/'art/evidence/silhouette-method.json').read_text(encoding='utf-8'))
    add('k.silhouette','K',nm=method['title'],ap=[sym('characters_25d939ff')],op=method['procedure'],ck=method['checks'],rq=method['requires'],rk=method['pitfalls'],so=list(map(ref,['s.method','s.identity','s.temporal','s.ui.scope','s.transfer'])))
    def criterion(identifier, name, domain, mode, check, sources):
        add(identifier,'Q',nm=name,dm=sym(domain),md=sym(mode),ck=check,wh=ref('actor'),so=list(map(ref,sources)))
    criterion('q.intake','Retained intake and actionable plan','other','local','The report links both hash-verified references and their native/enlarged observations; distinguishes user requirements, observations, conflicts and proposals; records method source ranges and proof limits; names scout/medic output plans, predeclared review criteria, missing capabilities and the next concrete action. It does not claim generated or accepted character art.',['s.brief','s.observations','s.measurements','s.tools','s.proposals','s.transfer'])
    criterion('q.raster','Chosen raster constraints','mechanical','local','Measure the actual candidate and check dimensions against its saved trial or production contract; verify all frames decode, no visible content clips the canvas, and any explicitly selected palette/alpha rules. Source counts do not impose a universal palette or alpha rule.',['s.brief','s.proposals'])
    criterion('q.scout','Scout identity at viewing size','visual','visual','Inspect actual scout and both references at native scale and integer zoom. Observe side-facing readability, retained shared form and cream focal detail, a readable scout equipment landmark and open equipment/body gaps. Inspect silhouette and colored views on declared trial backgrounds. Record limits if display scale/game backgrounds are unknown.',['s.brief','s.observations','s.proposals','s.transfer'])
    criterion('q.edges','Explicit outline trial','visual','visual','The candidate uses its saved trial edge treatment consistently. Inspect upright extensions, face, outer contour and equipment separation at native scale and integer zoom on light, dark and neutral/busy declared backgrounds. Compare both treatments only when both actual candidates exist; do not invent a winner from reference measurements.',['s.observations','s.proposals'])
    criterion('q.medic','Medic identity and baseline consistency','visual','visual','Inspect the actual medic beside the exact accepted scout baseline at native scale and integer zoom. Medical bag/bandage landmarks distinguish its role; shared proportions, teal/cream identity, lighting, edge treatment and side-facing semantics remain coherent.',['s.brief','s.proposals','s.transfer'])
    criterion('q.family','Collective character continuity','continuity','visual','View the actual selected scout and medic together with the nominated baseline on a shared ground line at native scale and integer enlargement. Compare body volume, scale, face, equipment placement, role separation, palette relationship and edges; record actual defects and comparisons.',['s.brief','s.proposals'])
    criterion('q.engine','Destination import behavior','engine','live','In the supplied target project/version import the exact delivered files and observe side-view scale, sampling, transparency and shared ground/pivot alignment in a representative scene. Verify slicing/timing only if animation is later in scope. Missing engine access is unavailable, never a pass.',['s.brief'])
    def task(identifier,name,phase,state,dependencies,inputs,outputs,knowledge=()):
        add(identifier,'T',nm=name,ow=ref('actor'),pr=ref('project'),dp=list(map(ref,dependencies)),dc=[],kn=list(map(ref,knowledge)),st=sym(state),ph=sym(phase),ip=list(map(ref,inputs)),op=list(map(ref,outputs)),ca=[],vr=[])
    def output(identifier,task_id,name,kind,criteria):
        add(identifier,'F',tk=ref(task_id),nm=name,kd=sym(kind),rq=list(map(ref,criteria)))
    task('t.intake','Inspect sources and retain the family proof plan','research','active',[],['x.reference.a','x.reference.b','x.comparison'],['f.intake'],['k.silhouette'])
    output('f.intake','t.intake','Reference review and scout/medic sample brief','report',['q.intake'])
    task('t.scout','Resolve trial choices and prove one scout pose','sample','open',['t.intake'],['x.reference.a','x.reference.b'],['f.scout'],['k.silhouette'])
    output('f.scout','t.scout','Representative side-view scout idle','sprite',['q.raster','q.scout','q.edges'])
    task('t.medic','Extend the exact approved scout into a medic','production','open',['t.scout'],['x.reference.a','x.reference.b'],['f.medic'],['k.silhouette'])
    output('f.medic','t.medic','Side-view medic idle from approved scout baseline','sprite',['q.raster','q.medic','q.edges'])
    task('t.delivery','Compare and retain the accepted two-member family','delivery','open',['t.scout','t.medic'],[],['f.delivery'])
    output('f.delivery','t.delivery','Future scout/medic family manifest and import handoff','report',['q.family','q.engine'])
    add('handoff','N',wh=ref('actor'),fo=list(map(ref,['i.canvas','i.outline','i.provider','f.scout','f.medic','f.delivery'])),nx=[ref('t.intake'),ref('t.scout')],bl=[ref('t.scout'),ref('t.medic'),ref('t.delivery')],rv=1)
    doc['revision']=1
    doc['format']=2
    path=ROOT/'.pixl/planning-adapter.json'
    path.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(cli('encode',path,'--out','.pixl/planning-candidate.px'))
    print(cli('validate','.pixl/planning-candidate.px','--root',ROOT))

if __name__=='__main__':
    main()
