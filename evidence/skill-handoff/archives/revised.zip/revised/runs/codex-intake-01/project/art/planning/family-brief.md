# Scout and medic — PIXL project start

The local intake and research are complete. Character generation has not run: the session has local PIXL tools but no authenticated PixelLab generation/status/download tools. The final canvas is unresolved and the outline references conflict. No character candidate, accepted baseline or delivery package exists yet.

## Reference review

Open the [interactive reference review](../reference-review.html) or [saved 8× comparison](../evidence/reference-comparison-8x.png). The comparison shows reference.png in the top row and reference-b.png below, on neutral, light and dark diagnostic backgrounds. Both original PNGs were inspected at native size; the saved board was inspected at 8× nearest-neighbor enlargement. These are reference views, not scout/medic studies.

| Source | Native canvas | Visible colors | Edge treatment | SHA-256 |
| --- | --- | --- | --- | --- |
| [reference.png](../../reference.png) | 32×32 | 3 | Navy body border, roughly 2 pixels on sides/bottom; dark upright extensions | d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7 |
| [reference-b.png](../../reference-b.png) | 32×32 | 2 | Unoutlined teal silhouette | e76b40ce38aeb436d0f5f0e433c4ac1eb4519bf93a7b29cd7a81a4609914a12a |

Each source has one frame, 390 visible pixels, binary alpha and visible bounds [7,3,25,28] with exclusive right/bottom coordinates. Their alpha silhouettes match exactly; 180 visible pixels change from navy to teal. The shared colors are teal #56B5BC and cream #F4DDA2, with navy #25354A in reference.png. These measurements describe inputs and do not impose output dimensions, a fixed palette or binary alpha.

The shared visual vocabulary is a compact angular body, two upright ear-like extensions and pale rectangular eyes. The dark edge becomes less distinct against the dark diagnostic background. Neither source establishes a side-facing pose or role equipment. Detailed [observations](../evidence/reference-observations.md), [PIXL checks](../evidence/pixl-reference-checks.json) and [pixel comparison](../evidence/reference-difference.json) retain the evidence.

## What is known and what is proposed

| Choice | Status | Current meaning |
| --- | --- | --- |
| Members and gameplay view | Confirmed by user | Scout and medic for a side-view game |
| Final canvas | Unresolved | Source 32×32 size is an observation only |
| Outline treatment | Conflict | Source-like navy border versus unoutlined teal edges |
| Initial pose | Proposed | One right-facing static scout idle |
| Trial canvases | Proposed | 32×32 and 48×48; separately authored, not resampled |
| Scout cues | Proposed | Low-profile field pouch and forward-looking monocular |
| Medic cues | Proposed | Broader medical satchel, cream bandage motif and dressing roll |
| Display scale, game backgrounds, engine | Unresolved | Diagnostic views cannot establish in-game behavior |

The two role designs should share body proportions, eye treatment, palette relationships, edge behavior and ground contact. Equipment should distinguish their silhouettes before tiny symbols are read. See the [proposed proof](proposals.md) for the controlled comparison and its limits.

## Planned outputs and review

The authoritative [PX2 state](../../.pixl/state.px) contains output plans before any character file exists:

| Output | Purpose | Required acceptance | Dependency |
| --- | --- | --- | --- |
| f.scout | Representative side-view scout idle | q.raster mechanical dimensions/content; q.scout visual identity; q.edges visual edge behavior | Intake complete; explicit trial contract and real generation capability |
| f.medic | Medic idle from accepted scout | q.raster; q.medic visual identity and baseline match; q.edges | Exact still-nominated accepted scout, confirmed production choices and applicable proof |
| f.delivery | Future family manifest and import handoff | q.family collective visual continuity; q.engine actual engine import | Both members accepted, exact baseline/member plan and destination choices saved |

Criteria were saved before any candidate verdict. The smallest first proof is one scout pose in a stated trial contract. If comparing both sizes and both edge treatments, create four separately planned scout outputs before requesting those trials. Judge native-scale readability, negative spaces and equipment separation, then enlarged clusters and edges on diagnostic backgrounds. Keep dimensions, visual quality, collective continuity and engine behavior as separate verdicts. No animation has been requested; a static pose does not prove walk cycles.

The selected research method is silhouette-readability. Its [applicability review](method-transfer.md) records exact source hashes/ranges, incomplete prerequisites and limits. The compiled method's key fixture is not a proof for these characters. Research is retained without an adopted design decision or borrowed passing receipt.

## Next action

Choose the outline direction or an A/B trial, and the trial canvas or 32×32/48×48 comparison. These answers define the representative sample without forcing a final canvas decision. No answer has been received during this session.

An authenticated PixelLab generation tool with its actual schema, plus result/status retrieval, must be available to execute the packaged workflow. The [observed tool inventory](../evidence/tool-discovery.json) is retained; no packages or host settings were changed and no provider job was dispatched. A separate image-generation tool was not substituted for a PixelLab result.

Once sample choices and capability are available, save concrete proposed C records and per-trial F plans, then follow durable job prepare/dispatch/observe/import. Inspect the real saved candidate through PIXL inspection preparation and host viewing before recording visual acceptance. After sample acceptance, bind the medic's F.bs and task input to that exact X; add the delivery F.bs, ordered F.mb=[f.scout,f.medic] and F.ds destination choices before family production/review. Those fields are intentionally absent until a real eligible baseline exists.

Engine acceptance remains unperformed because there are no candidate files or target engine project. When actual files exist and import access is still missing, retain an unavailable verdict with a concrete reason. Do not create a fictional candidate merely to attach an unavailable verdict.

Resume using the [handoff](../HANDOFF.md). No visual character acceptance, provider completion or game readiness is claimed by this intake report.
