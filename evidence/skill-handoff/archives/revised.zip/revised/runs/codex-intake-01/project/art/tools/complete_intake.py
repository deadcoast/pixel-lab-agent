"""Check retained local intake artifacts, create a reviewed candidate, never publish directly."""
from pathlib import Path
from datetime import datetime, timezone
import json
import re
from urllib.parse import unquote
from plan_intake import ROOT, cli, digest, ref, sym

def main():
    doc=json.loads(cli('decode','.pixl/state.px'))
    if doc['revision'] != 1:
        raise SystemExit('Expected the saved revision-1 intake plan; reload and reconcile.')
    previous=json.loads(cli('validate','.pixl/state.px','--root',ROOT))
    if not previous['valid'] or not previous['files_verified']:
        raise SystemExit('Saved plan failed validation.')
    records=doc['records']
    by_id={r['id']:r for r in records}
    def add(identifier,kind,**fields):
        record={'id':identifier,'kind':kind,'fields':fields}
        records.append(record)
        by_id[identifier]=record
    report='art/planning/family-brief.md'
    links=[]
    for path in [report,'art/HANDOFF.md','art/reference-review.html']:
        body=(ROOT/path).read_text(encoding='utf-8')
        targets=re.findall(r'(?:src|href)="([^"]+)"',body) if path.endswith('.html') else re.findall(r'\]\(([^)]+)\)',body)
        for target in targets:
            if '://' in target or target.startswith('#'):
                continue
            resolved=((ROOT/path).parent/unquote(target.split('#')[0])).resolve()
            if not resolved.is_relative_to(ROOT) or not resolved.is_file():
                raise SystemExit(f'Missing or outside-project link in {path}: {target}')
            links.append({'from':path,'to':target,'sha256':digest(resolved.relative_to(ROOT).as_posix())})
    checks=json.loads((ROOT/'art/evidence/pixl-reference-checks.json').read_text())
    for name,measurement in checks.items():
        if digest(name)!=measurement['sha256'] or not measurement['pass']:
            raise SystemExit(f'Reference identity/measurement failure: {name}')
    delta=json.loads((ROOT/'art/evidence/reference-difference.json').read_text())
    if not delta['same_size'] or not delta['identical_alpha'] or delta['changed_visible_pixels']!=180:
        raise SystemExit('The report does not match the retained pixel comparison.')
    if by_id['i.canvas']['fields']['st']!=sym('unresolved') or by_id['i.outline']['fields']['st']!=sym('conflict'):
        raise SystemExit('Unresolved choices unexpectedly changed.')
    if any(r['kind'] in {'C','D','J'} for r in records):
        raise SystemExit('Unexpected contract, adopted decision or provider job in unresolved intake.')
    for name in ['f.scout','f.medic','f.delivery']:
        if any(r['kind']=='X' and r['fields'].get('of')==ref(name) for r in records):
            raise SystemExit('Unexpected character/delivery candidate.')
    add('x.viewer','X',nm='Interactive original-reference comparison',ur='art/reference-review.html',dg=digest('art/reference-review.html'),kd=sym('report'))
    add('x.delta','X',nm='Exact source pixel comparison',ur='art/evidence/reference-difference.json',dg=digest('art/evidence/reference-difference.json'),kd=sym('report'))
    add('x.intake','X',nm='Scout and medic reference review and proof brief',ur=report,dg=digest(report),kd=sym('report'),of=ref('f.intake'),mt={'support':list(map(ref,['x.reference.a','x.reference.b','x.comparison','x.viewer','x.delta']))})
    task=by_id['t.intake']['fields']
    task['ca']=[ref('x.intake')]
    doc['revision']=2
    stage=ROOT/'.pixl/review-adapter.json'
    stage.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    cli('encode',stage,'--out','.pixl/review-stage.px')
    validated=json.loads(cli('validate','.pixl/review-stage.px','--root',ROOT))
    if not validated['valid']:
        raise SystemExit('Review-stage validation failed.')
    def references(value):
        if isinstance(value,dict):
            if set(value)=={'$ref'}:
                yield value['$ref']
            else:
                for child in value.values(): yield from references(child)
        elif isinstance(value,list):
            for child in value: yield from references(child)
    semantic=set('ASRCKDXIFQ')
    scope=set()
    def visit(identifier):
        if identifier in scope or by_id[identifier]['kind'] not in semantic:
            return
        scope.add(identifier)
        for child in references(by_id[identifier]['fields']): visit(child)
    visit('x.intake')
    visit('q.intake')
    bindings=[{'rf':ref(identifier),'dg':validated['record_hashes'][identifier]} for identifier in sorted(scope)]
    now=datetime.now(timezone.utc).isoformat()
    evidence={
        'reviewed_at':now,'reviewer':'PIXL acting agent','mode':'local','outcome':'pass',
        'criterion':'q.intake','candidate':'x.intake','prior_saved_revision':1,'prior_saved_hash':previous['hash'],
        'bindings':bindings,'local_links_checked':links,
        'checks':[
            'Both original reference file hashes match PIXL measurements; source byte identities verified.',
            'Native and 8x viewing observations, exact outline disagreement, pixel comparison and diagnostic background limits are linked.',
            'Confirmed side-view scout/medic requirement is separate from unresolved canvas and conflicting edges.',
            'Trial sizes and equipment landmarks are explicitly proposals; no final contract or adopted decision exists.',
            'Method, exact source ranges, narrow applicability and fixture limitations are retained.',
            'Scout, medic and delivery plans have saved criteria and ordered dependencies without fictional candidate files.',
            'Missing PixelLab capability, absent jobs, absent engine context and next concrete steps are explicit.',
        ],
        'limits':['This is completeness/consistency review of the intake report, not artistic acceptance.',
                  'Original references and saved comparison were viewed through the host; the HTML controls have not been browser-tested.',
                  'No provider submission, generated character, family comparison or target-engine import has occurred.'],
    }
    evidence_path='art/evidence/intake-review.json'
    (ROOT/evidence_path).write_text(json.dumps(evidence,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    add('e.intake','E',nm='Local intake completeness and identity review',ur=evidence_path,dg=digest(evidence_path),rs=sym('pass'),md=sym('local'),at=now,bs=bindings)
    add('v.intake','V',tk=ref('t.intake'),rq=ref('q.intake'),xr=ref('x.intake'),st=sym('pass'),wh=ref('actor'),wy='The linked report preserves the inspected references, epistemic statuses, sourced method limits, future output criteria and concrete blockers. Local reference identities and report links were checked. This verdict accepts intake completeness only.',at=now,ev=[ref('e.intake')])
    task['vr']=[ref('v.intake')]
    task['st']=sym('done')
    handoff=by_id['handoff']['fields']
    handoff['rv']=2
    handoff['nx']=[ref('t.scout')]
    handoff['fo'].append(ref('x.intake'))
    stage.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    cli('encode',stage,'--out','.pixl/review-candidate.px')
    final=json.loads(cli('validate','.pixl/review-candidate.px','--root',ROOT))
    print(json.dumps({k:final[k] for k in ['valid','format','revision','hash','records','files_verified']},indent=2))
    print(f'Checked {len(links)} local links; {len(bindings)} semantic bindings. Ready for expected-hash commit.')

if __name__=='__main__':
    main()
