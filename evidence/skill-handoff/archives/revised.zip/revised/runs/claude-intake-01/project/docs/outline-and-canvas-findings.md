# Outline treatment and canvas size: findings for the user's decision

Task `t_edge_study`, 2026-09-14. This document reports measurements and the
source-grounded considerations behind two open choices. It selects neither
treatment nor canvas size; both remain the user's decision, recorded as intake
choices `edge_treatment` (conflict) and `px` / `display_scale` (unresolved).

## 1. The references disagree about exactly one thing

Measured locally from the supplied files:

| | reference.png | reference-b.png |
|---|---|---|
| SHA-256 | `d997cade…70aa7` | `e76b40ce…4a12a` |
| Canvas | 32x32 | 32x32 |
| Occupied area | 18x25 at origin (7,3) | 18x25 at origin (7,3) |
| Visible pixels | 390 | 390 |
| Alpha | binary, no fractional pixels | binary, no fractional pixels |
| Opaque components | 1 | 1 |
| Colours | #56B5BC, #25354A, #F4DDA2 | #56B5BC, #F4DDA2 |

The alpha channels are byte-identical and the visor pixels are identical: two
3x4 blocks at rows 14-17, columns 11-13 and 18-20. So the silhouettes are the
same shape and the disagreement is isolated to edge treatment. That is a
deliberate A/B, not two drafts that drifted apart.

reference.png's border is not a 1 px outline. Its 180 dark pixels are exactly
the 2 px boundary band computed under 8-connectivity, verified by erosion.

## 2. Measured cost of each treatment

At the occupancy the references actually use (18x25, 390 visible pixels):

| Treatment | Border px | Border share | Interior px | Interior bounding box |
|---|---|---|---|---|
| No border (reference-b.png) | 0 | 0% | 390 | 18x25 |
| 1 px border (proposal, not supplied) | 92 | 23.6% | 298 | 16x23 |
| 2 px border (reference.png) | 180 | 46.2% | 210 | 14x15 |

Two consequences worth naming before the decision:

- With the 2 px border, the two head stubs are 4 px wide and therefore carry no
  body colour at all. They become pure silhouette. Any role marking placed on
  the head is not available at this size.
- The interior is where a scout and a medic have to differ. At 14x15 there is
  room for a small insignia and little else; at 18x25 there is room for a
  distinct pose, kit shape or silhouette-internal detail.

## 3. How the cost changes with sprite size

Computed by integer-scaling the supplied silhouette and re-deriving the boundary
band. This is arithmetic on the reference shape, not authored art at those
sizes, and it does not predict how a redrawn larger character would look.

| Occupancy | Smallest square canvas | Visible px | 1 px border | 2 px border |
|---|---|---|---|---|
| 18x25 (as supplied) | 32 | 390 | 92 px, 23.6% | 174 px, 44.6% |
| 36x50 | 64 | 1560 | 190 px, 12.2% | 370 px, 23.7% |
| 54x75 | 96 | 3510 | 288 px, 8.2% | 566 px, 16.1% |

(The 2 px figures here use 4-connectivity, so they are slightly below
reference.png's 180 px 8-connectivity band at the same occupancy.)

This is why the two open choices are one coupled decision. A 2 px border is
expensive at 32x32 and ordinary at 64x64. A canvas answer that does not account
for the border answer can make the family harder to differentiate than intended.

## 4. What the supplied sources do and do not settle

Source inventory verified through `pixl_sources` (`files_verified: true`) at
resource root `.agents/skills/pixl-kit/resources`. All citations below are to
`training/original-docs/PIXEL-ART-DEEP-RESEARCH.md`, sha256
`7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`, 1713 lines,
retrieved at the stated line ranges. The full quoted text is retained in
`sources/method-notes.md`.

**Lines 714-732, "Outline pressure".** The source describes a dark outline pixel
at small sizes as carrying both boundary and depth, and as a resource for
animation: the outline's *value* can change before its *coordinate* does, so a
contour can appear to advance or retreat without moving. Applied here: a
bordered family keeps that resource for later animation; an unbordered family
gives it up and must carry motion in the interior instead. This project has not
confirmed an animation set, so this does not select a treatment — but it is the
consideration most likely to matter later.

**Lines 907-919, integer presentation.** Point/nearest sampling preserves texels;
bilinear blurs them. Method `integer-presentation` requires the logical
resolution, camera convention and target viewport before a grid decision can be
checked. Applied here: the canvas question cannot be closed without the intended
display scale, because the canvas only has meaning relative to the viewport it
is drawn into. `sa=nearest` is recorded as a proposal for that reason, not as a
confirmed choice.

**Lines 857-867, candidate rejection constraints.** Includes "creates edge AA on
an edge that should remain hard" and "changes palette outside approved ramp".
Applied here: these become the concrete checks for generated candidates once the
palette and edge policy are confirmed. They cannot be applied yet, because
neither is confirmed.

**Method `edge-rhythm`** records the pitfalls "Not every uneven run is a jaggy"
and "Mechanical contour smoothing can erase style and identity." Applied here:
this is the reason the conflict is preserved as a conflict rather than resolved
by whichever contour a validator prefers. Both references are internally
consistent; neither is defective.

**Method `silhouette-readability`** supplies the background comparison procedure
executed in `study/outline-study.png`. Its own pitfall applies: since both
references share one silhouette, silhouette analysis cannot choose between them,
and no measurement in this document proves aesthetic quality.

Caveat retained from the knowledge operation: this research document contains
historical citation tokens (`citeturn…`) that are not retrievable primary
sources. Claims resting on them are treated as unverified.

## 5. What is not decided here

- `edge_treatment` stays `conflict` with both supplied alternatives preserved.
  The 1 px border shown in the study sheet is a measured proposal introduced by
  this task, not a third supplied reference.
- `px` and `display_scale` stay `unresolved`.
- `pl` stays `observed`, not confirmed: #25354A exists only in the bordered
  reference, so the palette cannot be confirmed before the border is.
- `destination_engine` stays `unresolved`, so every engine criterion in this
  project is currently unperformable rather than failing.
