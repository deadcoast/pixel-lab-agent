"""Build the outline/canvas study sheet and its measurements.

Deterministic local composition from the two supplied references. This script
generates no art from a model; the only derived variant is an explicitly
proposed 1px border produced by recoloring the silhouette's boundary band.
"""

import json
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
OUT_PNG = ROOT / "study" / "outline-study.png"
OUT_JSON = ROOT / "study" / "outline-measurements.json"

BODY = (86, 181, 188, 255)
DARK = (37, 53, 74, 255)
VISOR = (244, 221, 162, 255)
CLEAR = (0, 0, 0, 0)
MASK = (128, 128, 128, 255)

BG_LIGHT = (232, 228, 218, 255)
BG_DARK = (26, 29, 38, 255)
BG_BUSY_A = (60, 110, 90, 255)
BG_BUSY_B = (78, 132, 104, 255)
GUTTER = (255, 0, 255, 255)

NEIGHBORS = ((1, 0), (-1, 0), (0, 1), (0, -1))


def solid_cells(img):
    px = img.load()
    w, h = img.size
    return {(x, y) for y in range(h) for x in range(w) if px[x, y][3] > 0}


def boundary_band(cells, width):
    """Cells within `width` steps of the outside, by 4-connectivity erosion."""
    remaining = set(cells)
    band = set()
    for _ in range(width):
        edge = {c for c in remaining
                if any((c[0] + dx, c[1] + dy) not in remaining for dx, dy in NEIGHBORS)}
        band |= edge
        remaining -= edge
    return band, remaining


def scaled(cells, k):
    return {(x * k + i, y * k + j) for x, y in cells for i in range(k) for j in range(k)}


def occupancy(cells):
    xs = [x for x, _ in cells]
    ys = [y for _, y in cells]
    return min(xs), min(ys), max(xs) - min(xs) + 1, max(ys) - min(ys) + 1


def interior_box(cells):
    """Largest full-width/full-height rectangle of the body block, measured
    as the bounding box of cells whose whole row and column runs are solid."""
    x0, y0, w, h = occupancy(cells)
    rows = {}
    for x, y in cells:
        rows.setdefault(y, set()).add(x)
    full_rows = [y for y, xs in rows.items() if len(xs) == w]
    if not full_rows:
        return None
    return w, max(full_rows) - min(full_rows) + 1


def variant_image(base_cells, visor_cells, border_width, canvas):
    img = Image.new("RGBA", canvas, CLEAR)
    px = img.load()
    band = set()
    if border_width:
        band, _ = boundary_band(base_cells, border_width)
    for cell in base_cells:
        px[cell] = DARK if cell in band else BODY
    for cell in visor_cells:
        if cell not in band:
            px[cell] = VISOR
    return img


def mask_image(cells, canvas):
    img = Image.new("RGBA", canvas, CLEAR)
    px = img.load()
    for cell in cells:
        px[cell] = MASK
    return img


def background(canvas, kind):
    img = Image.new("RGBA", canvas, CLEAR)
    px = img.load()
    w, h = canvas
    for y in range(h):
        for x in range(w):
            if kind == "light":
                px[x, y] = BG_LIGHT
            elif kind == "dark":
                px[x, y] = BG_DARK
            else:
                px[x, y] = BG_BUSY_A if ((x // 2) + (y // 2)) % 2 == 0 else BG_BUSY_B
    return img


def main():
    ref_a = Image.open(ROOT / "reference.png").convert("RGBA")
    ref_b = Image.open(ROOT / "reference-b.png").convert("RGBA")
    canvas = ref_a.size
    cells = solid_cells(ref_b)
    pb = ref_b.load()
    visor = {c for c in cells if pb[c] == VISOR}

    columns = [
        ("silhouette", mask_image(cells, canvas)),
        ("reference_a_border2", ref_a),
        ("reference_b_border0", ref_b),
        ("proposed_border1", variant_image(cells, visor, 1, canvas)),
    ]
    rows = ["light", "dark", "busy"]

    cw, ch = canvas
    gap = 2
    sheet = Image.new(
        "RGBA",
        (len(columns) * cw + (len(columns) + 1) * gap,
         len(rows) * ch + (len(rows) + 1) * gap),
        GUTTER,
    )
    for r, kind in enumerate(rows):
        for c, (_, cell_img) in enumerate(columns):
            x = gap + c * (cw + gap)
            y = gap + r * (ch + gap)
            tile = background(canvas, kind)
            tile.alpha_composite(cell_img)
            sheet.paste(tile, (x, y))
    OUT_PNG.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(OUT_PNG)

    # Measurements.
    x0, y0, occ_w, occ_h = occupancy(cells)
    band1, inner1 = boundary_band(cells, 1)
    band2, inner2 = boundary_band(cells, 2)
    pa = ref_a.load()
    ref_a_dark = {c for c in cells if pa[c] == DARK}

    costs = []
    for k in (1, 2, 3):
        up = scaled(cells, k)
        b1, i1 = boundary_band(up, 1)
        b2, i2 = boundary_band(up, 2)
        costs.append({
            "occupancy_scale": k,
            "occupancy_px": [occ_w * k, occ_h * k],
            "smallest_square_canvas": min(s for s in (32, 48, 64, 96, 128)
                                          if s >= max(occ_w * k, occ_h * k)),
            "visible_pixels": len(up),
            "border1_pixels": len(b1),
            "border1_share_pct": round(100 * len(b1) / len(up), 1),
            "border1_interior_pixels": len(i1),
            "border2_pixels": len(b2),
            "border2_share_pct": round(100 * len(b2) / len(up), 1),
            "border2_interior_pixels": len(i2),
        })

    measurements = {
        "measured_at": "2026-09-14",
        "method": "local deterministic measurement of the supplied references",
        "references": {
            "reference.png": {
                "canvas": list(canvas),
                "visible_pixels": len(solid_cells(ref_a)),
                "colors": {"body": list(BODY), "border": list(DARK), "visor": list(VISOR)},
                "border_pixels": len(ref_a_dark),
                "border_share_pct": round(100 * len(ref_a_dark) / len(cells), 1),
                "border_is_2px_band": sorted(ref_a_dark) == sorted(band2),
                "border_is_1px_band": sorted(ref_a_dark) == sorted(band1),
            },
            "reference-b.png": {
                "canvas": list(canvas),
                "visible_pixels": len(solid_cells(ref_b)),
                "colors": {"body": list(BODY), "visor": list(VISOR)},
                "border_pixels": 0,
                "border_share_pct": 0.0,
            },
        },
        "silhouettes_identical": solid_cells(ref_a) == cells,
        "visor_pixels_identical": {c for c in solid_cells(ref_a) if pa[c] == VISOR} == visor,
        "occupancy": {
            "origin": [x0, y0],
            "size": [occ_w, occ_h],
            "body_block": interior_box(cells),
        },
        "border_cost_by_occupancy": costs,
        "sheet": {
            "path": "study/outline-study.png",
            "size": list(sheet.size),
            "columns": [name for name, _ in columns],
            "rows": rows,
            "cell": list(canvas),
            "gutter_px": gap,
        },
        "limitations": [
            "border_cost_by_occupancy scales the supplied silhouette by integer factors "
            "to quantify how much of a larger sprite a border would consume. It is "
            "arithmetic on the reference shape, not authored art at those sizes.",
            "proposed_border1 is a derived proposal, not a supplied reference.",
            "No visual or engine acceptance is established by this file.",
        ],
    }
    OUT_JSON.write_text(json.dumps(measurements, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(measurements, indent=2))


if __name__ == "__main__":
    main()
