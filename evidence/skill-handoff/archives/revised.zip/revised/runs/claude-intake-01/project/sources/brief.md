# Retained user instruction

Session date: 2026-09-14. Retained verbatim from the user, then annotated.

## Verbatim instruction

> Make a character family matching this project, using PIXL. The supplied references
> disagree about outline treatment and I have not chosen the final canvas size. The
> family will have a scout and a medic for a side-view game. References are
> reference.png and reference-b.png. Begin the project and make the progress possible
> in this session.

## Retained session constraints

> This is an isolated PIXL evaluation project. Work only in this project. The packaged
> PIXL skill and runtime are available under .agents/skills/pixl-kit. The selected
> Python interpreter is C:/Users/ryanf/github/TODO/pixel-lab-docsuite/.venv/Scripts/python.exe.
> Local PIXL tools are supplied by the session MCP configuration. Input images are in
> the project root. Do not install packages or change host settings.

## What the instruction establishes

- Family members: a scout and a medic. Stated directly by the user.
- View: side-view game. Stated directly by the user.
- Outline treatment: explicitly unresolved; the two references disagree.
- Canvas size: explicitly not chosen by the user.
- Authorized scope: begin the project and carry it as far as it can go without the
  two missing decisions.

## What the instruction does not establish

- Final canvas dimensions and target display scale.
- Outline/edge policy.
- Palette policy (whether the reference colors are a fixed project palette or only a
  sample of one).
- Animation set, frame counts, timing, pivots.
- Destination engine and import route.
