"""Author the PX2 intake revision for this project.

Reads the committed state through the adapter, adds sources, references, intake
choices, knowledge, tasks, planned outputs and acceptance criteria, and writes a
candidate for validation and commit. It records no candidate and no verdict.
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = sys.executable
RUNNER = str(ROOT / ".agents/skills/pixl-kit/scripts/pixl.py")
AT = "2026-09-14"


def run(*args, stdin=None):
    proc = subprocess.run([PY, RUNNER, *args], capture_output=True, text=True,
                          cwd=ROOT, input=stdin)
    if proc.returncode != 0:
        raise SystemExit(f"{' '.join(args)} failed:\n{proc.stdout}\n{proc.stderr}")
    return proc.stdout


def source(path):
    data = (ROOT / path).read_bytes()
    lines = data.decode("utf-8").splitlines()
    return {"dg": hashlib.sha256(data).hexdigest(), "ln": [1, len(lines)]}


def digest(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def sym(name):
    return {"$symbol": name}


def ref(name):
    return {"$ref": name}


def refs(*names):
    return [ref(n) for n in names]


def rec(rid, kind, **fields):
    return {"id": rid, "kind": kind, "fields": fields}


SOURCES = [
    rec("s_brief", "S", au=sym("local"), at=AT, ur="sources/brief.md",
        **source("sources/brief.md")),
    rec("s_refobs", "S", au=sym("local"), at=AT, ur="sources/reference-observations.md",
        **source("sources/reference-observations.md")),
    rec("s_methods", "S", au=sym("study"), at=AT, ur="sources/method-notes.md",
        **source("sources/method-notes.md")),
]

REFERENCES = [
    rec("x_ref_a", "X", nm="Supplied reference with a 2 px dark border",
        ur="reference.png", dg=digest("reference.png"), kd=sym("reference"),
        mt={"canvas": "32x32", "border": "2px #25354A", "role": "contested reference A"}),
    rec("x_ref_b", "X", nm="Supplied reference with no border",
        ur="reference-b.png", dg=digest("reference-b.png"), kd=sym("reference"),
        mt={"canvas": "32x32", "border": "none", "role": "contested reference B"}),
]

CHOICES = [
    rec("i_view", "I", pr=ref("project"), wh=ref("user"), ky="vw",
        st=sym("confirmed"), vl=sym("side"), so=refs("s_brief"),
        wy="The user stated the family is for a side-view game."),
    rec("i_members", "I", pr=ref("project"), wh=ref("user"), ky="family_members",
        st=sym("confirmed"), vl=["scout", "medic"], so=refs("s_brief"),
        wy="The user named both members directly."),
    rec("i_canvas", "I", pr=ref("project"), wh=ref("user"), ky="px",
        st=sym("unresolved"), vl=None, so=refs("s_brief", "s_refobs"),
        wy="The user has not chosen the final canvas size. Observed: the references "
           "occupy 18x25 inside a 32x32 canvas. The choice is coupled to display_scale "
           "and to edge_treatment, because a border consumes 23.6% of the visible "
           "pixels at 1 px and 44.6% at 2 px at the supplied occupancy."),
    rec("i_scale", "I", pr=ref("project"), wh=ref("user"), ky="display_scale",
        st=sym("unresolved"), vl=None, so=refs("s_brief", "s_methods"),
        wy="integer-presentation requires the logical resolution, camera convention "
           "and target viewport; none were supplied. A canvas size has no meaning "
           "without the scale it is drawn at."),
    rec("i_edges", "I", pr=ref("project"), wh=ref("user"), ky="edge_treatment",
        st=sym("conflict"),
        vl=["2 px dark border in #25354A, the 8-connectivity boundary band, as in "
            "reference.png; head stubs carry no body colour and the interior drops "
            "to 14x15",
            "no border, flat body colour over the whole 18x25 silhouette, as in "
            "reference-b.png"],
        so=refs("s_brief", "s_refobs", "s_methods"),
        wy="The two supplied references have pixel-identical silhouettes, alpha and "
           "visors and differ only here, so this is a deliberate unresolved choice "
           "rather than a drafting inconsistency. The user flagged it and has not "
           "resolved it. A 1 px border is a measured third option carried in the "
           "study; it is a proposal, not a supplied reference."),
    rec("i_palette", "I", pr=ref("project"), wh=ref("user"), ky="pl",
        st=sym("observed"), vl=["#56B5BC", "#25354A", "#F4DDA2"], so=refs("s_refobs"),
        wy="Measured from the references. #25354A occurs only in the bordered "
           "reference, so the palette cannot be confirmed before edge_treatment is. "
           "Whether these three are the whole project palette is not established."),
    rec("i_alpha", "I", pr=ref("project"), wh=ref("user"), ky="al",
        st=sym("observed"), vl=sym("binary"), so=refs("s_refobs"),
        wy="Both references contain zero fractional-alpha pixels. Recorded as an "
           "observation of the references, not yet as confirmed project policy."),
    rec("i_lighting", "I", pr=ref("project"), wh=ref("user"), ky="li",
        st=sym("observed"), vl="flat; no shading, ramp or directional light present",
        so=refs("s_refobs"),
        wy="Neither reference contains any value variation inside the body, so no "
           "light direction can be inferred. Whether the family stays flat is open."),
    rec("i_sampling", "I", pr=ref("project"), wh=ref("actor"), ky="sa",
        st=sym("proposed"), vl=sym("nearest"), so=refs("s_methods"),
        wy="Proposed from integer-presentation. Not confirmed, because the "
           "destination engine and display scale are unknown."),
    rec("i_engine", "I", pr=ref("project"), wh=ref("user"), ky="destination_engine",
        st=sym("unresolved"), vl=None, so=refs("s_brief"),
        wy="No destination engine or import route was supplied, so every engine "
           "criterion in this project is currently unperformable."),
]

KNOWLEDGE = [
    rec("k_silhouette", "K", nm="Evaluate identity using silhouette and target backgrounds",
        ap=[sym("characters_25d939ff"), sym("interactive_props_25a44283")],
        op=["Render a flat opaque mask before detailing.",
            "Inspect major proportions, negative spaces and landmark separation at native logical scale.",
            "Compare the colored asset on representative light, dark and busy backgrounds."],
        ck=["Named identity landmarks remain visible at the target size.",
            "Required gaps stay open and interactive forms separate from their surroundings."],
        so=refs("s_methods"),
        rq=["Intended viewing scale, representative backgrounds and identity landmarks"],
        rk=["Silhouette alone cannot validate faces, materials or fine symbols.",
            "No contrast ratio or component count proves aesthetic quality.",
            "Both references share one silhouette, so this method cannot choose between them; "
            "only its background comparison applies to the outline question."]),
    rec("k_edge_rhythm", "K", nm="Audit stair-step runs without imposing one contour style",
        ap=[sym("clean_linework_08dea3fe"), sym("hard_silhouettes_99485584")],
        op=["Trace boundary runs and highlight sudden run-length changes.",
            "Regularize only contours intended to read as smooth.",
            "Preserve corners, damage and organic asymmetry identified in the brief."],
        ck=["A supplied straight diagonal retains its declared repeating step pattern.",
            "No protected corner changes during cleanup."],
        so=refs("s_methods"),
        rq=["A contour mask and declared intentional corners or irregular regions"],
        rk=["Not every uneven run is a jaggy; shape can require an abrupt change.",
            "Mechanical contour smoothing can erase style and identity.",
            "Read here as the reason not to resolve edge_treatment by validator preference."]),
    rec("k_integer", "K", nm="Render at a declared logical grid and inspect device pixels",
        ap=[sym("strict_grid_games_a7cd2a47"), sym("sprite_delivery_638f99a7"),
            sym("pixel_previews_014b1177")],
        op=["Render or sample at the logical grid, then use a declared integer scale where required.",
            "Apply nearest sampling to image scaling and account for browser device pixel ratio.",
            "Inspect the final output, not only a CSS property or import setting."],
        ck=["A logical pixel expands into a uniform scale-by-scale block in the fixture.",
            "No new colors appear during opaque nearest-neighbor enlargement."],
        so=refs("s_methods"),
        rq=["Logical resolution, camera convention and target viewport dimensions"],
        rk=["Nearest filtering alone does not constrain lighting resolution.",
            "Noninteger scaling, arbitrary rotation and browser zoom can change displayed pixel widths.",
            "Its required inputs are exactly what this project has not chosen."]),
]

CRITERIA = [
    rec("q_study_mech", "Q", nm="study sheet mechanics", dm=sym("mechanical"),
        md=sym("local"), wh=ref("actor"), so=refs("s_refobs"),
        ck="study/outline-study.png is a single 138x104 frame containing only the "
           "three reference colours, the silhouette mask grey, the three declared "
           "background colours and the gutter marker."),
    rec("q_study_visual", "Q", nm="study sheet coverage", dm=sym("visual"),
        md=sym("visual"), wh=ref("actor"), so=refs("s_methods"),
        ck="Viewed at native scale and at integer enlargement, the sheet shows the "
           "shared silhouette and all three border treatments on light, dark and "
           "busy backgrounds, and for each treatment the visor and both head stubs "
           "can be judged as separable or not separable from the background."),
    rec("q_report_grounded", "Q", nm="findings are grounded", dm=sym("other"),
        md=sym("local"), wh=ref("actor"), so=refs("s_methods"),
        ck="The findings document states, for every border treatment, the measured "
           "border pixel share and remaining interior, cites the exact source path, "
           "hash and line range behind each method claim, and selects no treatment "
           "on the user's behalf."),
    rec("q_canvas_match", "Q", nm="canvas and alpha", dm=sym("mechanical"),
        md=sym("local"), wh=ref("user"), so=refs("s_brief"),
        ck="The candidate file matches the confirmed canvas size, the confirmed "
           "alpha policy and the confirmed palette."),
    rec("q_readability", "Q", nm="role readability", dm=sym("visual"),
        md=sym("visual"), wh=ref("user"), so=refs("s_brief", "s_methods"),
        ck="At the confirmed canvas and display scale, on the game's own "
           "backgrounds, the character reads as its intended role and the visor and "
           "both head stubs stay separable from the background."),
    rec("q_engine_import", "Q", nm="engine import", dm=sym("engine"), md=sym("live"),
        wh=ref("user"), so=refs("s_brief"),
        ck="The destination engine imports the sprite with the intended sampling, "
           "integer scale, pivot and transparency."),
    rec("q_family_continuity", "Q", nm="family continuity", dm=sym("continuity"),
        md=sym("visual"), wh=ref("user"), so=refs("s_brief"),
        ck="Scout and medic, viewed together at native scale, share silhouette mass, "
           "border treatment, palette and lighting, with no unintended volume or "
           "anchor drift between them."),
    rec("q_role_distinct", "Q", nm="roles are distinguishable", dm=sym("visual"),
        md=sym("visual"), wh=ref("user"), so=refs("s_brief", "s_refobs"),
        ck="Viewed together at native scale, scout and medic are tellable apart by "
           "shape or insignia rather than by colour alone, inside whatever interior "
           "the confirmed border treatment leaves."),
]

OUTPUTS = [
    rec("f_study_sheet", "F", tk=ref("t_edge_study"), kd=sym("reference"),
        nm="Outline treatment comparison sheet",
        rq=refs("q_study_mech", "q_study_visual")),
    rec("f_study_report", "F", tk=ref("t_edge_study"), kd=sym("report"),
        nm="Outline and canvas findings for the user's decision",
        rq=refs("q_report_grounded")),
    rec("f_scout_sample", "F", tk=ref("t_scout_sample"), kd=sym("sprite"),
        nm="Representative scout pose, side view",
        rq=refs("q_canvas_match", "q_readability", "q_engine_import")),
    rec("f_medic", "F", tk=ref("t_medic_production"), kd=sym("sprite"),
        nm="Medic matching the accepted scout sample",
        rq=refs("q_canvas_match", "q_readability", "q_engine_import")),
    rec("f_family_manifest", "F", tk=ref("t_family_delivery"), kd=sym("report"),
        nm="Scout and medic family delivery manifest",
        rq=refs("q_family_continuity", "q_role_distinct")),
]

TASKS = [
    rec("t_edge_study", "T", nm="Measure and show the contested outline treatment",
        ow=ref("actor"), pr=ref("project"), ph=sym("research"), st=sym("active"),
        dp=[], dc=[], kn=refs("k_silhouette", "k_edge_rhythm", "k_integer"),
        ip=refs("x_ref_a", "x_ref_b"),
        op=refs("f_study_sheet", "f_study_report"), ca=[], vr=[]),
    rec("t_scout_sample", "T", nm="Prove the scout as the representative sample",
        ow=ref("actor"), pr=ref("project"), ph=sym("sample"), st=sym("open"),
        dp=refs("t_edge_study"), dc=[], kn=refs("k_silhouette", "k_integer"),
        ip=refs("x_ref_a", "x_ref_b"), op=refs("f_scout_sample"), ca=[], vr=[]),
    rec("t_medic_production", "T", nm="Produce the medic from the accepted scout",
        ow=ref("actor"), pr=ref("project"), ph=sym("production"), st=sym("open"),
        dp=refs("t_scout_sample"), dc=[], kn=refs("k_silhouette"),
        ip=[], op=refs("f_medic"), ca=[], vr=[]),
    rec("t_family_delivery", "T", nm="Deliver the scout and medic family together",
        ow=ref("actor"), pr=ref("project"), ph=sym("delivery"), st=sym("open"),
        dp=refs("t_scout_sample", "t_medic_production"), dc=[], kn=[],
        ip=[], op=refs("f_family_manifest"), ca=[], vr=[]),
]


def main():
    adapter = json.loads(run("decode", ".pixl/state.px"))
    by_id = {r["id"]: r for r in adapter["records"]}

    project = by_id["project"]["fields"]
    project["sc"] = refs("s_brief", "s_refobs", "s_methods")
    project["in"] = refs(*[c["id"] for c in CHOICES])

    adapter["records"].extend(
        SOURCES + REFERENCES + CHOICES + KNOWLEDGE + CRITERIA + OUTPUTS + TASKS)
    adapter["revision"] = adapter["revision"] + 1

    candidate = ROOT / "build" / "intake-candidate.px"
    candidate.parent.mkdir(parents=True, exist_ok=True)
    tmp = ROOT / "build" / "intake-adapter.json"
    tmp.write_text(json.dumps(adapter, indent=2), encoding="utf-8")
    print(run("encode", str(tmp), "--out", str(candidate)))
    print(run("validate", str(candidate), "--root", "."))


if __name__ == "__main__":
    main()
