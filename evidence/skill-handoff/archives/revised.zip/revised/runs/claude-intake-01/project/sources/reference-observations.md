# Reference observations

Local measurements of the two supplied references, 2026-09-14. These are
measurements and observations only. They do not establish a project style.

## Identity

| File | SHA-256 | Canvas | Visible px | Colors |
|---|---|---|---|---|
| reference.png | d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7 | 32x32 | 390 | 3 |
| reference-b.png | e76b40ce38aeb436d0f5f0e433c4ac1eb4519bf93a7b29cd7a81a4609914a12a | 32x32 | 390 | 2 |

## What the two references share

- Identical alpha channel: the silhouettes are pixel-for-pixel the same.
- Occupancy 18x25 at origin (7,3) inside a 32x32 canvas. 7 px of padding at the
  left/right, 3 px above, 4 px below.
- Identical visor pixels: two 3x4 blocks at rows 14-17, columns 11-13 and 18-20,
  colour #F4DDA2.
- Body colour #56B5BC. No fractional alpha in either file; alpha is binary.
- Both are a single 4-connected opaque component.

## Where they disagree

The disagreement is isolated to edge treatment. Nothing else differs.

- reference.png: a 2 px dark border, colour #25354A, covering 180 of 390 visible
  pixels (46.2%). The border set is exactly the 2 px boundary band under
  8-connectivity, verified by erosion. The two head stubs are 4 px wide and are
  therefore rendered entirely in border colour with no body colour at all. The
  remaining interior is 210 px in a 14x15 region.
- reference-b.png: no border. The full 18x25, 390 px silhouette is body colour
  except the visor.

## Border cost as a function of sprite size

Computed by integer-scaling the supplied silhouette and re-deriving the boundary
band. This is arithmetic on the reference shape, not authored art at those sizes.

| Occupancy | Smallest square canvas | Visible px | 1 px border | 2 px border |
|---|---|---|---|---|
| 18x25 (as supplied) | 32 | 390 | 92 px, 23.6% | 174 px, 44.6% |
| 36x50 | 64 | 1560 | 190 px, 12.2% | 370 px, 23.7% |
| 54x75 | 96 | 3510 | 288 px, 8.2% | 566 px, 16.1% |

Interior left for character detail at the supplied 18x25 occupancy:

| Treatment | Interior px | Interior bounding box |
|---|---|---|
| No border (reference-b) | 390 | 18x25 |
| 1 px border (proposed) | 298 | 16x23 |
| 2 px border (reference) | 210 | 14x15 |

## Consequence for this brief

The family needs a scout and a medic that read as different characters. All role
differentiation has to live inside the interior. At the supplied occupancy the
2 px border leaves a 14x15 interior, and the head stubs carry no body colour,
so the two roles would have to be distinguished almost entirely by interior
colour rather than by shape. The canvas choice and the border choice are
therefore one coupled decision, not two independent ones.
