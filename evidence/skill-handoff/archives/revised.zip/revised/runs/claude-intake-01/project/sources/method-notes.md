# Method notes retained for this project

Source-grounded notes selected 2026-09-14 for two questions: how to decide the
outline treatment, and how to decide the canvas size. Retained in the project so
a later session can identify the same methods and text without the installed
plugin.

## Source inventory actually used

`pixl_sources` reported `files_verified: true` against resource root
`.agents/skills/pixl-kit/resources`.

- `training/original-docs/PIXEL-ART-DEEP-RESEARCH.md`
  sha256 `7efc4789ca70dfd9964abc2bc1100af318306236400e3496f7a0a5654f725e28`, 1713 lines.

Caveat retained from the knowledge operation: this local research document
contains historical citation tokens (`citeturn...`) that are not retrievable
primary sources. Claims that depend on them are treated as unverified.

## Methods selected

### silhouette-readability

"Evaluate identity using silhouette and target backgrounds." Applies to
characters. Requires the intended viewing scale, representative backgrounds and
identity landmarks. Procedure: render a flat opaque mask before detailing;
inspect major proportions, negative spaces and landmark separation at native
logical scale; compare the coloured asset on representative light, dark and busy
backgrounds. Checks: named identity landmarks remain visible at the target size;
required gaps stay open. Pitfalls: silhouette alone cannot validate faces,
materials or fine symbols, and no contrast ratio or component count proves
aesthetic quality.

Why it applies here: the two references have identical silhouettes, so the
silhouette cannot decide between them. The method's background comparison is the
part that does apply, and it is what `study/outline-study.png` executes.

### edge-rhythm

"Audit stair-step runs without imposing one contour style." Pitfalls recorded in
the method: "Not every uneven run is a jaggy; shape can require an abrupt
change" and "Mechanical contour smoothing can erase style and identity."

Why it applies here: it is the explicit instruction not to resolve the outline
conflict by picking whichever contour a validator prefers. The choice is the
user's.

### integer-presentation

"Render at a declared logical grid and inspect device pixels." Requires logical
resolution, camera convention and target viewport dimensions. Checks: a logical
pixel expands into a uniform scale-by-scale block; no new colours appear during
opaque nearest-neighbour enlargement.

Why it applies here: the canvas choice cannot be made without the intended
display scale, because the canvas only has meaning relative to the viewport it
is drawn into.

Cited text, `PIXEL-ART-DEEP-RESEARCH.md` lines 907-919, retrieved against the
hash above:

> ### Do not confuse sub-pixel art with runtime bilinear filtering
>
> Current engine documentation makes the distinction operationally important.
> Unity describes point filtering as preserving block-like texels, while bilinear
> filtering blurs neighboring samples; its Pixel Perfect Camera similarly exposes
> a trade-off between sharper point filtering and filtered modes intended to
> reduce shimmering. [citation token]
>
> For handcrafted sub-pixelling:
>
> ```text
> sprite sampling     = nearest / point
> logical coordinates = integer at final raster
> fractional effect   = encoded in authored colors/clusters
> ```
>
> Otherwise the GPU's interpolation destroys the controlled decisions the artist
> made.

## Directly relevant source text on outlines

`PIXEL-ART-DEEP-RESEARCH.md` lines 714-732, retrieved against the hash above:

> A visible movement does **not** require every term to change.
>
> ### Outline pressure
>
> For very small sprites, one dark outline pixel can represent both boundary and
> depth. Change its value before its coordinate:
>
> ```text
> rest:      DARK
> leaning:   MID-DARK
> handoff:   MID
> moved:     new outline pixel becomes DARK
> ```
>
> This makes the contour appear to approach or retreat gradually.
>
> Andersen's workflow reinforces the importance of deliberately coordinated shade
> colors rather than treating each color in isolation. [citation token]

Applicability assessment: the source describes an outline as a carrier of both
boundary and depth at small sizes, and as an animation resource. Both matter for
this brief, because the family is intended for a side-view game and will need
animation. A bordered family (reference.png) keeps that resource; an unbordered
family (reference-b.png) gives it up and must carry motion in the interior
instead. The source does not state that either is correct, and this project has
not confirmed animation requirements, so nothing here selects a treatment.

`PIXEL-ART-DEEP-RESEARCH.md` lines 857-867 records a rejection constraint that
will apply to generated candidates later:

> ```text
> Reject candidate if:
>     creates isolated 1-pixel noise not intentionally permitted;
>     destroys identifying facial feature;
>     changes palette outside approved ramp;
>     creates edge AA on an edge that should remain hard;
>     produces more temporal flicker than geometric motion;
>     changes sprite volume without corresponding pose change.
> ```

## Stopping condition

The sources supply the criteria for evaluating an outline treatment and the
prerequisites for a canvas decision. They do not supply the decision. Both remain
open user choices, recorded as intake choices `edge_treatment` (conflict) and
`canvas_px` (unresolved).
