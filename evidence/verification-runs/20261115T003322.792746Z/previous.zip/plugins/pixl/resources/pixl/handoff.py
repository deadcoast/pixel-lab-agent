"""Preserve a selected production continuation alongside the agent's own judgments."""

import json
from hashlib import sha256
from pathlib import Path

from . import graph, plar, store
from .codec import PixlError


def save(root, asset_id, requirements_hash, expect, details, path="plar.txt", view="receipt"):
    root = Path(root).resolve()
    if view not in ("receipt", "caller"):
        raise PixlError("caller_result_input", "handoff view must be receipt or caller")
    if not isinstance(details, dict) or details.get("status") not in (
        "delivered", "partial", "needs_input", "blocked"
    ):
        raise PixlError("handoff_details", "details needs the agent's assignment status")
    if {"resume", "next", "asset_id", "requirements_hash", "version"} & details.keys():
        raise PixlError("handoff_details", "Derived fields belong to the snapshot; use caller_actions and future_work for commentary")
    if view == "caller":
        from . import caller_result

        caller = caller_result.prepare(root, details)
    selected = plar.read(root, path, asset_id)
    if selected["requirements_hash"] != requirements_hash:
        raise PixlError("handoff_stale", "Selected requirements changed or wrong identity supplied; requirements_hash must match plar read.requirements_hash; reread the asset")
    production = selected.get("production") or {}
    continuation = production.get("continuation")
    if not continuation:
        raise PixlError("handoff_state", "No production continuation is available; retain the allocation diagnostic in the ordinary result")
    if continuation["state_hash"] != expect:
        raise PixlError("handoff_stale", "Production state changed or wrong identity supplied; expect must match the canonical production state hash at production.continuation.state_hash; reread selected PLAR, not its top-level file hash")
    document = {
        "version": 1,
        "asset_id": asset_id,
        "requirements_hash": requirements_hash,
        "resume": continuation,
        "next": continuation["action"],
        "selection": {
            "path": graph.confined(root, path).relative_to(root).as_posix(),
            "hash": selected["hash"],
            "current": production["selection_current"],
        },
        "details": details,
        "scope": "Snapshot of derived state plus agent-authored observations. No automatic contract, art or delivery acceptance; reread current PLAR before acting.",
    }
    data = (json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    digest = sha256(data).hexdigest()
    target = graph.confined(root, f".pixl/handoffs/{digest}.json")
    receipt = {
        "path": target.relative_to(root).as_posix(),
        "sha256": digest,
        "asset_id": asset_id,
        "requirements_hash": requirements_hash,
        "state_hash": expect,
        "next": document["next"],
        "scope": document["scope"],
    }
    # Finish validation/presentation before publishing any new handoff bytes.
    result = caller_result.project(receipt, document, selected, data, caller) if view == "caller" else receipt
    folder = graph.confined(root, ".pixl/handoffs")
    with store.lock(folder):
        target = graph.confined(root, f".pixl/handoffs/{digest}.json")
        if target.exists():
            if target.read_bytes() != data:
                raise PixlError("handoff_corrupt", "Retained snapshot bytes changed")
        else:
            store._atomic(target, data)
    return result
