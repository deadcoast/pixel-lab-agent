"""Retain UTF-8 receipts for ordinary public PIXL operations in this CF-09 run."""

import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT.parents[2]
WORK = Path(__file__).resolve().parent
STORE = ROOT / ".pixl/assets/robot.idle"
PYTHON = REPO / ".venv/Scripts/python.exe"
sys.path.insert(0, str(REPO))
from pixl import codec, store


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    path = Path(path)
    return {"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path)}


def save(path, value):
    path = Path(path)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    return path


def state_hash():
    return codec.digest(store.load(STORE))


def cli(name, arguments):
    output = WORK / f"{name}.stdout.json"
    command_record = WORK / f"{name}.command.json"
    if output.exists() or command_record.exists():
        raise ValueError(f"Receipt already exists: {name}")
    command = [str(PYTHON), "-m", "pixl", *map(str, arguments)]
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1",
               PYTHONDONTWRITEBYTECODE="1")
    result = subprocess.run(command, cwd=REPO, env=env, capture_output=True,
                            text=True, encoding="utf-8")
    output.write_text(result.stdout, encoding="utf-8")
    save(command_record, {"argv": command, "returncode": result.returncode,
                          "stderr": result.stderr})
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return json.loads(result.stdout) if result.stdout.strip() else None


def amend(name, change):
    """Amend decoded JSON, encode/validate, then expected-hash public commit."""
    expected = state_hash()
    original = cli(name + "-decode", ["decode", STORE / "state.px"])
    candidate = copy.deepcopy(original)
    change(candidate)
    candidate["revision"] = original["revision"] + 1
    candidate_path = save(WORK / f"{name}.candidate.json", candidate)
    wire = WORK / f"{name}.candidate.px"
    cli(name + "-encode", ["encode", candidate_path, "--out", wire])
    cli(name + "-validate", ["validate", wire, "--root", ROOT])
    return cli(name + "-commit", ["commit", STORE, wire, "--expect", expected,
                                  "--root", ROOT])
