# TM-09: decide how to resume/import the actual delivered idle

This is a NEW read-only decision over retained CF-09 art, not a new art revision.
Use the actual named `pixl:pixl` specialist (Codex: agent_type="pixl", fork_turns="none")
and wait for its completion. Installed kit: `C:/github/pixel-lab-agent/evidence/knowledge-decisions/20261113/native/claude-01/installed pixl`. It is deliberately
outside consumer `C:/Users/ryanf/AppData/Local/Temp/pixl readiness claude clean l_sz01tb/consumer`. Only local PIXL MCP is configured.
Keep every input, art file, source, production record and kit unchanged. Write only
under `work/knowledge-decisions`. No provider calls, installation, credentials/global/memory changes,
state acceptance or repainting. Human acceptance and M1/M2/broader M3/M4 stay open.

Specialist reads the complete installed skills/pixl/SKILL.md,
resources/agent/PROFILE.md and skills/pixl/references/knowledge.md, then
CF-09-ROBOT-IDLE.md, src/animation.ts, work/knowledge-inputs/IMPORT-PROPOSAL.json,
work/knowledge-inputs/provider-inspect.json, work/knowledge-inputs/criteria.json, and the raw/corrected capture/check files under
work/cf09-production-01. The proposal is an unadopted import shortcut, not an owner
requirement: should the retained provider preview's uniform100ms timing replace
the project's authored sequence? Also decide how to check fixed contact without
treating equal pivots as proof, and whether CSS blur/translation or source-example
durations transfer to this robot. Defer unsupported event/audio/other-engine claims.

Use actual MCP pixl_sources, pixl_knowledge (index and all three methods:
animation-anchors, frame-timing, silhouette-readability), pixl_context with scope="library",
path="knowledge/library.px", focus="k.<method>", and complete dependency closure.
Retrieve every cited method.sources range using pixl_source scope="library" with
the discovered source hash. Read the actual executed POC entries from the context
E.ur receipt (matching E.dg) using exact source slices too. The method's proposed
poc recipe is not necessarily the executed receipt. Save each actual operation
through its result_path under work/knowledge-decisions; retain full returned data, not transcription.
Use the explicit library-context MCP route; do not copy the library into the
consumer or replace that call with CLI/shell parsing. Tool schema discovery and
small read-only calculations are allowed. Do not omit dependency closure for budget.

View these exact actual PNGs through an image tool (not path listings):
- work/knowledge-inputs/returned/inspection-light-1x.png
- work/knowledge-inputs/returned/inspection-light-8x.png
- work/knowledge-inputs/corrected-02/inspection-light-1x.png
- work/knowledge-inputs/corrected-02/inspection-light-8x.png
- work/cf09-production-01/raw-capture-01/live-east-idle-1x-2.png
- work/cf09-production-01/raw-capture-01/live-east-idle-3x-2.png
- work/cf09-production-01/corrected-capture-01/live-east-idle-1x-2.png
- work/cf09-production-01/corrected-capture-01/live-east-idle-3x-2.png
The native/light views cover every raw/final frame; actual1x/3x destination samples
show frame2 in context. Retained capture timing establishes recorded playback;
viewing its stills does not mean continuous motion was watched live in this trial.

Write work/knowledge-decisions/SPECIALIST-RESULT.json containing:
- operations: list of {tool,arguments,result:{path,sha256}} for every saved MCP result;
- methods: one row per unprefixed method ID (for example animation-anchors), with
  method, question, applicability (holds/unknown/
  unsuitable facts), disposition (support/adapt/reject/defer), decision, authority,
  proof (executed check_id and limits), evidence refs, next_action;
- import_decision: verdict (retain_authored, reject_uniform or adopt_uniform),
  durations_ms, total_ms, boundary_times_ms,
  boundary_frames. Evaluate times [0, 799, 800, 919, 920, 1079, 1080, 1199, 1200, 1599, 1600] against the actual adapter.
  Contrast the proposed uniform timeline; do not change the authored source;
- transfer_decisions: rows for provider_uniform_timing, css_blur_translation,
  source_example_durations, event_audio_engine, each with id (that exact name),
  disposition (support/adapt/reject/defer) and reason;
- authority_notes distinguishing explicit assignment choices, source suggestions,
  actual observations and specialist construction choices. Light-background
  inspection originated as expert curation and is now explicitly required by this
  assignment; neither fact makes the library source prescribe that diagnostic.
- viewed_images exact path/sha refs, production_unchanged=true,
  acceptance_created=false, retrospective_causality_claimed=false, limitations,
  and next_action. State that this new review cannot prove retrieval caused CF09's
  earlier repair. Pixel counts and fixture passes cannot accept artistic quality.

Caller independently reads the COMPLETE specialist report, all saved operation
results, the actual assignment/adapter/proposal, actual POC receipt entries and
capture checks. View the same required PNGs. Compare exact source bytes/hash/ranges,
method conditions, context closure and executed POC limits with this fresh decision.
Write work/knowledge-decisions/CALLER-RESULT.json with native_child (actual id/role), specialist_result
ref, operations (same exact result refs), viewed_images, independent_checks,
import_decision, transfer_decisions, authority_notes, production_unchanged=true,
acceptance_created=false, retrospective_causality_claimed=false, limitations and
next_action. Do not change accepted CF09 state or rerun generation to make counts.
Every ref is {"path":"consumer-relative/path","sha256":"actual digest"}.
