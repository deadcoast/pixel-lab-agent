---
name: pixl
description: Load the installed PIXL workflow.
---

Read `C:/github/pixel-lab-agent/evidence/knowledge-decisions/20261113/native/codex-01/installed pixl/skills/pixl/SKILL.md` and resolve its links from that file.
