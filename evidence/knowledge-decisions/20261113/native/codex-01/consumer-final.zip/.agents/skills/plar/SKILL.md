---
name: plar
description: Load the installed PLAR workflow.
---

Read `C:/github/pixel-lab-agent/evidence/knowledge-decisions/20261113/native/codex-01/installed pixl/skills/plar/SKILL.md` and resolve its links from that file.
