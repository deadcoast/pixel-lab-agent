---
name: plar
description: Load the installed PLAR production workflow.
---

Read [the shared skill](../role-kit/skills/plar/SKILL.md), resolving its links from that file.
