---
name: pixl
description: Load the installed PIXL production workflow.
---

Read [the shared skill](../role-kit/skills/pixl/SKILL.md), resolving its links from that file.
