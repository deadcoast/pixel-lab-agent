This is the explicit CF-05 named Codex role evaluation.
Follow NAMED-ROLE-ASSIGNMENT.md in this retained asset consumer. The current kit is
.agents/skills/role-kit; its shared entrypoint is .agents/skills/role-kit/skills/pixl/SKILL.md.
Old assignments and kits remain history. New reports and result exports belong
under work/named-role. The assigned public PLAR handoff may additionally create its new
immutable files under .pixl/handoffs; preserve all existing files in that directory.
Consumer root: C:/github/pixel-lab-agent/build/named-role-consumer-04. Selected Python: C:/github/pixel-lab-agent/.venv/Scripts/python.exe.
Preserve existing sources, assets, production state, reviews and historical files.
No remote generation, new art acceptance, package installs, global settings or memory edits.
The caller owns independent verification; PIXL owns the delegated specialist work.
