# Qualify the registered specialist with a useful retained-asset handoff

You are a cold calling agent. Use the native registered `pixl` role for one child
by explicitly selecting agent_type="pixl" and fork_turns="none" in the available
native spawn tool. Supply the actual assignment and paths in its delegated brief.
Keep actual returned child identity. If the host rejects or omits that role,
retain the exact failure in work/named-role/CALLER-RESULT.json; a generic fallback does
not satisfy this assignment. Do not change the role file or host configuration.
The repository role is copied unchanged; it leads through the consumer wrappers
to the current shared skill/profile. Reading a role file alone is not invoking it.

The asset is queue.working in authoring-plar.txt, plan provenance-correction.plan,
store .pixl/assets/queue.ready, candidate native.provenance.delivery.candidate.01, existing family
review native.family.review.01. The old plar.txt is another generation. This is a
bounded recovery/handoff of existing accepted work. No fresh visual or renderer
observation, new state adoption, provider call or art production is assigned.

Round 1: delegate to that registered child. It should follow the shared everyday
workflow and identities/path guidance; use public CLI/MCP operations to read the
selected asset, export exact candidate/family context to fresh files under
work/named-role, and retrieve a precise original source range supporting one current
requirement. Read only relevant context; parse large exports programmatically.
Have it return work/named-role/SPECIALIST-ROUND1.json with actual consumer/install/store
roots, exact result paths and file hashes, canonical state/requirements identities,
current versus creation-time acceptance, source locator and literal excerpt,
reused evidence limits and the useful continuation. Also retain the skill/profile
entrypoints it actually read and their byte hashes. Those read observations are
separate from the evaluator's native role-loading proof.

Independently verify the returned files and source excerpt, selected generation,
and current acceptance. Save work/named-role/CALLER-REVIEW.json with your actual findings
and a concrete follow-up. Then send that follow-up to the SAME native child using
the host's continuation/follow-up tool, without spawning a replacement. Ask it to
address any findings and verify unchanged-review recovery: replay
work/export-review/identical-review.json with candidate native.provenance.delivery.candidate.01
and review ID native.family.review.01, using the current public state hash and a new
result path. It must report actual reuse/publication results and preserve the
original review. Save a public PLAR handoff for authoring-plar.txt / queue.working
with honest retained findings and exact continuation, plus SPECIALIST-ROUND2.json.
The second round's root, scope and state must remain tied to round 1. Do not
pretend a follow-up message alone proves completed continuation.

Independently verify the second round and handoff, all named file hashes, the
unchanged original input files and production history, and zero new production-state publications
or provider attempts. Write work/named-role/CALLER-RESULT.json with actual child identity,
role selection/continuation observations, round results, corrections, useful
handoff locators and exact next action. Keep reports concise and reference the
exact large exports instead of repeating them. Keep the child available when
finished. This qualifies the observed route only; M1/M2 and broader reliability,
generated quality and native end-to-end production remain open.
