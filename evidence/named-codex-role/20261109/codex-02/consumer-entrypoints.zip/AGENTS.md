This is the explicit CF-05 named Codex role evaluation.
Follow NAMED-ROLE-ASSIGNMENT.md in this retained asset consumer. The current kit is
.agents/skills/role-kit; old assignments and kits remain history. New files belong under work/named-role.
Consumer root: C:/github/pixel-lab-agent/build/named-role-consumer-02. Selected Python: C:/github/pixel-lab-agent/.venv/Scripts/python.exe.
Preserve existing sources, assets, production state, reviews and historical files.
No remote generation, new art acceptance, package installs, global settings or memory edits.
The caller owns independent verification; PIXL owns the delegated specialist work.
