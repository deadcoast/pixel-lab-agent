from pathlib import Path
import copy, hashlib, json, shutil, sys, uuid
repo=Path(r"C:\github\pixel-lab-agent")
base=repo/"build/handoff-forward-88ac3f329c07"
sys.path.insert(0,str(repo))
run=base/("cross-layer-"+uuid.uuid4().hex[:10])
run.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v): p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8")
modules=["pixl/request_review.py","pixl/plar_workflow.py","pixl/plar_prepare.py"]
before={p:sha(repo/p) for p in modules}
for p in modules:
 target=run/"source-snapshot"/p
 target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(repo/p,target)
from pixl import jobs, plar, request_review, plar_prepare
manifest=json.loads((base/"source-copy-manifest.json").read_text())
def case(name):
 root=run/name
 for row in manifest["files"]:
  p=root/row["path"]
  p.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(base/"project"/row["path"],p)
 return root
packet_path="work/queue.ready/revised/request-review.json"
results={"runtime_modules_before":before,"scope":"Synthetic local copy probes only; no host/provider calls, generation or acceptance."}
root=case("owner-drift")
with (root/"OWNER.md").open("a",encoding="utf-8") as f: f.write("\nProbe only: no further controlled request is authorized.\n")
report=request_review.report(root,packet_path,"queue.ready")
save(run/"owner-drift-report.json",report)
results["owner_drift"]={"diagnostics":report["diagnostics"],"source_rows":report.get("sources")}
root=case("schema-drift")
schema=json.loads((root/"provider-schemas.json").read_text())
schema["create_image_pro_flash"]["properties"]["width"]["minimum"]=32
save(root/"provider-schemas.json",schema)
report=request_review.report(root,packet_path,"queue.ready")
save(run/"schema-drift-report.json",report)
results["schema_drift"]={"diagnostics":report["diagnostics"],"source_rows":report.get("sources")}
root=case("connection-drift")
packet=json.loads((root/packet_path).read_text())
connection_path=packet["request"]["connection"]["path"]
connection=json.loads((root/connection_path).read_text())
connection["provider"]="isolated-other-provider"
save(root/connection_path,connection)
try:
 report=request_review.report(root,packet_path,"queue.ready")
except Exception as e:
 report={"diagnostics":[{"error":str(e)}]}
save(run/"connection-drift-report.json",report)
try:
 selected,plan,sources,identity=plar_prepare._inputs(root,"plar.txt","queue.ready",packet["requirements_hash"],packet_path,connection)
 prepared={"accepted":True,"identity_provider":identity["request"]["provider"],"identity_tool":identity["request"]["tool"]}
except Exception as e:
 prepared={"accepted":False,"error":str(e)}
results["connection_drift"]={"packet_provider":packet["request"]["provider"],"packet_connection_sha256":packet["request"]["connection"]["sha256"],"actual_connection_sha256":sha(root/connection_path),"diagnostics":report["diagnostics"],"reported_request":report.get("request"),"prepare_inputs":prepared}
for name,field in [("supplied-provider-only","provider"),("same-provider-authorization-drift","authorization")]:
 root=case(name)
 packet=json.loads((root/packet_path).read_text())
 conn=json.loads((root/packet["request"]["connection"]["path"]).read_text())
 if field=="provider": conn["provider"]="isolated-other-provider"
 else: conn["authorization"]["scope"]="Synthetic probe altered authorization while preserving provider name"
 try:
  checked=plar_prepare._inputs(root,"plar.txt","queue.ready",packet["requirements_hash"],packet_path,conn)
  results[name]={"accepted":True,"identity_provider":checked[-1]["request"]["provider"]}
 except Exception as e:
  results[name]={"accepted":False,"error":str(e)}
root=case("continuation")
selected=plar.read(root,asset_id="queue.ready")
results["pending_continuation"]={"continuation":selected["production"]["continuation"],"job_discovery":selected["production"]["jobs"][-1]["discovery"],"new_request_allowed":selected["production"]["new_request_allowed"]}
folder=root/selected["production"]["store"]
job="r.e3924db2642e50c7.request"
changed=jobs.observe(folder,selected["production"]["hash"],job,"succeeded",{"synthetic_local_probe":True,"provider_simulated":True,"note":"Counterfactual status for isolated continuation probe; not a real provider observation."},root=root)
selected=plar.read(root,asset_id="queue.ready")
save(run/"synthetic-success-report.json",selected)
results["synthetic_success_continuation"]={"continuation":selected["production"]["continuation"],"new_request_allowed":selected["production"]["new_request_allowed"],"candidates":selected["production"]["outputs"][0]["candidates"]}
after={p:sha(repo/p) for p in modules}
results["runtime_modules_after"]=after
results["source_modules_unchanged_during_probe"]=before==after
save(run/"probe-results.json",results)
print(json.dumps({"run":str(run),"modules":before,"unchanged":before==after,"owner_diagnostics":results["owner_drift"]["diagnostics"],"schema_diagnostics":results["schema_drift"]["diagnostics"],"connection_drift":results["connection_drift"],"pending_continuation":results["pending_continuation"]["continuation"],"success_continuation":results["synthetic_success_continuation"],"supplied-provider-only":results["supplied-provider-only"],"same-provider-authorization-drift":results["same-provider-authorization-drift"]},indent=2))
