# CF-10 native production assignment

Explicit CF-10 native real-provider production evaluation: robot-directions.
Consumer root: C:/Users/ryanf/AppData/Local/Temp/pixl readiness claude clean h0x5smz6/consumer. Current kit: C:/Users/ryanf/AppData/Local/Temp/pixl readiness claude clean h0x5smz6/consumer/installed pixl.
Python: C:/github/pixel-lab-agent/build/readiness-setup-01/runtime/Scripts/python.exe. Follow NATIVE-PRODUCTION.md as the current assignment.
Historical briefs and assignments remain evidence; this later addendum authorizes
only the specified useful production. Invoke the actual named pixl:pixl specialist.
Official PixelLab MCP and local PIXL are separately configured. Discover actual tools.
Do not inspect credential files/environment, change settings or persistent memory,
install packages, modify the installed kit, or work outside this consumer.
M1/M2 and broader M3 remain open. Retain all failures and actual provider identities.

## Useful assignment: complete missing robot directions

The existing examples/delegation consumer has an approved identity fixture and
missing directional files. This later CF-10 addendum explicitly authorizes actual
official production, superseding only the old BRIEF.md plan-only/no-runner scope.
Keep the original brief, controller, source image and original plar.txt unchanged.
The old approval is within this representative fixture, not a real-game art claim.

Select robot.directions from production-plar.txt, including robot.base's identity reference.
Inspect assets/robot-base.png first. Preserve its exact south PNG bytes as
assets/robot/south.png. Use the actual source pixels as the provider's existing
identity/south input, not a filename in a text description or a redesigned robot.
Generate the useful missing east, north and west views, separate transparent
32x32 PNGs at the controller's exact assets/robot/<direction>.png paths.
Inspect subject identity, proportions, palette, volume, direction and anchor/alignment
at native size and 3x nearest. Extra returned directions may be retained but are
not required delivered work. Do not regenerate the approved south for counts.

Use fresh .pixl/assets/robot.directions with ordinary public plan/job/review/family
operations. Multi-output plans require an explicit family delivery output/link;
do not declare the first single direction to satisfy the whole assigned family.
The bounded renderer-native/ imports actual src/robot.ts and observes all four
controller states. Run the copied renderer with these consumer-root paths:
`node renderer-native/capture.mjs --project . --out work/native-production/render-01`
`"C:/github/pixel-lab-agent/build/readiness-setup-01/runtime/Scripts/python.exe" renderer-native/check.py --project . --capture work/native-production/render-01 --out work/native-production/renderer-check-01.json`
Read renderer-native/README.md for its contract. Save exact returned reports and
inspect destination.png and all actual 1x/3x cells
with the host image tool. It is a supporting CF-10 renderer, not broad TM-08 or
game-engine qualification. Current acceptance requires actual visual judgment.

## Scope, payment and source authority

This is authorized useful official PixelLab work in the existing representative
consumer. Use the current official platform docs https://www.pixellab.ai/docs and
MCP reference https://api.pixellab.ai/mcp/docs and actual discovered declarations.
The scoped evaluation spending limit is **20 subscription generations for this
host assignment**, including revisions. It is an execution budget, not an aesthetic
rule. Discover current operation cost before each paid call; keep actual reported
usage and starting/ending balance. Free reference upload, discovery, retrieval and
deterministic PixelLab corrections are authorized. No unrelated account changes,
deletion, publication or repeated calls just for test counts. Stop new paid work
if the remaining limit cannot cover it; preserve a useful partial continuation.
Never silently retry an ambiguous paid submission; reconcile its actual identifier.

Do not read tokens, auth configuration or secret environment variables. The host
connection supplies authentication. Save tool schemas/discovery with the observed
clock, exact arguments and authorization scope, without credentials. Preserve
failed results, mistaken calls and revisions rather than rewriting receipts.

## Native caller and specialist collaboration

The caller must invoke one actual named `pixl:pixl` specialist with this whole
assignment, consumer root, kit and Python. Codex uses agent_type="pixl" with
fork_turns="none". A generic substitute is not qualification. Retain the actual
child identity, wait for it, and use the same child for feedback/recovery.
The specialist reads the installed shared skill C:/Users/ryanf/AppData/Local/Temp/pixl readiness claude clean h0x5smz6/consumer/installed pixl/skills/pixl/SKILL.md
and profile, then the relevant public workflow references and actual consumer.

First the specialist saves a concrete source-bound request/criteria packet and
literal review context for the caller, including actual provider image inputs and
the full delivered scope. Before paid dispatch, the caller independently reads
the original sources/reference pixels and exact packet, compares **every criterion**
and source/choice interpretation, writes work/native-production/COMPARISON.json, and sends its
findings to the same child. Correct contradictions before dispatch. Scope expert
choices honestly; do not promote a sample recipe into an owner requirement.
The caller must remain active through the complete result. A background child
launch plus a final 'waiting' message is an incomplete assignment.

The specialist then completes the authorized useful production: durable local
preparation and dispatch claim BEFORE each official host call, actual returned ID
and observations, retrieval/import of exact downloaded bytes, native/enlarged
inspection, appropriate revision if required, actual consumer rendering, explicit
candidate/family review and acceptance only when justified, PLAR and caller handoff.
Use `--help`/actual MCP schemas; only supply result_path where advertised. Existing
CLI stdout capture is a valid full-result route. Read full exact report locators.
The host's actual official call establishes provider execution; local J records or
handwritten assertions do not. Do not create fake provider IDs or fixture responses.

Write work/native-production/SPECIALIST-RESULT.json with: status, scope, source_refs,
comparison_ref, provider_operations (tool, actual_id, job, arguments_ref,
response_ref, observed_usage), delivered_files (path/sha256 and role),
state_ref, plar_ref, review_refs, renderer_report_ref, renderer_check_ref,
viewed_images (path/sha256), handoff_ref, lineage_findings, preservation,
failures_and_recovery, limitations, next_action. Use exact file references;
include actual operations only, and keep generated/edited/reused members distinct.
All fresh work reports/art candidates belong under work/native-production or the fresh .pixl store;
only assigned delivered destinations and production-plar.txt may change outside those folders.

Caller: independently inspect the specialist result, provider receipts, actual
files and renderer evidence. Use an image tool to inspect the final generated
files/reference and rendered destination at 1x/3x, compare actual identities and
source mapping, and consume the compact public caller handoff including exact
full retrievals where needed. Do not duplicate paid work for verification. Write
work/native-production/CALLER-RESULT.json with native_child, specialist_result, comparison_ref,
provider_operations, delivered_files, viewed_images, renderer_report_ref,
renderer_check_ref, handoff_ref, independent_checks, status, preservation,
guided_recovery, limitations and next_action. A status of delivered requires the
whole assignment and actual consumption. Honest incomplete output retains its
specific missing acceptance and resumable next action. Do not close M1/M2 or
broader M3, general artistic quality or host reliability.
