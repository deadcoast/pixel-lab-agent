# CF-10 native production assignment

Explicit CF-10 native real-provider production evaluation: queue-ready.
Consumer root: C:/Users/ryanf/AppData/Local/Temp/pixl readiness codex clean ejarrjfy/consumer. Current kit: C:/Users/ryanf/AppData/Local/Temp/pixl readiness codex clean ejarrjfy/consumer/installed pixl.
Python: C:/github/pixel-lab-agent/build/readiness-setup-01/runtime/Scripts/python.exe. Follow NATIVE-PRODUCTION.md as the current assignment.
Historical briefs and assignments remain evidence; this later addendum authorizes
only the specified useful production. Invoke the actual named pixl specialist.
Official PixelLab MCP and local PIXL are separately configured. Discover actual tools.
Do not inspect credential files/environment, change settings or persistent memory,
install packages, modify the installed kit, or work outside this consumer.
M1/M2 and broader M3 remain open. Retain all failures and actual provider identities.

## Useful assignment: official Ready replacement

The accepted queue has real generated/revised Working, Retry and Paused but its
Ready member is still a controlled-fixture sample. Produce a useful official Ready
replacement for this existing consumer. This addendum supersedes only the old
PRODUCTION-STAGE.md preserve-Ready exclusion, within this isolated copy. The old
Ready bytes are preserved at work/native-production-inputs/original-ready.png with their origin identity.
The prospective queue's approved-ready source/requirement locator points to that
unchanged snapshot so delivering a new Ready cannot rewrite its style authority.
Preserve BRIEF.md, src/*, Start, Working, Retry and Paused exactly. Replace only
assets/ready-confirmed.png after preserving every candidate under work/native-production or the
new store. Original plar.txt and historical receipts remain unchanged.

Read the full current BRIEF.md and actual src/queue-view.ts. Ready remains a static
transparent 16x16 asymmetric check mark conveying success, coherent with the cool
blue queue family, distinguishable from Working/activity and Retry without color
alone. No fixed palette is imposed. Use actual uploaded reference pixels when
conditioning style. The existing Ready is a style/meaning reference, not evidence
that its historical simulated job was real. Preserve the distinction.

Select queue.ready from production-plar.txt; create fresh production in .pixl/assets/queue.ready.
No historical producer state is reconstructed. Use the existing local public
operations for request preparation, durable jobs, candidate inspection/review,
delivery and handoff. The original source closure and art identities are in
work/native-production-inputs/origin.json. Existing accepted sibling art is destination context, not
newly generated work. Judge this Ready in both real queue consumers at 1x and 3x
nearest on #172336, including grayscale distinction and collective appearance.

The bounded actual renderer is renderer-native/. Run its existing capture and check:
`node renderer-native/capture.mjs --project . --out work/native-production/render-01`
`"C:/github/pixel-lab-agent/build/readiness-setup-01/runtime/Scripts/python.exe" renderer-native/check.py --project . --capture work/native-production/render-01`
Save full check stdout to a fresh JSON file. Inspect actual destination.png and
relevant retained native/3x cell PNGs with the host image tool; mechanical success
does not supply visual acceptance. Retain rejected captures; retry to a new output.
This directly exercises the existing renderer; do not invent a queue-motion
family manifest merely to fit a one-member production assignment.

## Scope, payment and source authority

This is authorized useful official PixelLab work in the existing representative
consumer. Use the current official platform docs https://www.pixellab.ai/docs and
MCP reference https://api.pixellab.ai/mcp/docs and actual discovered declarations.
The scoped evaluation spending limit is **20 subscription generations for this
host assignment**, including revisions. It is an execution budget, not an aesthetic
rule. Discover current operation cost before each paid call; keep actual reported
usage and starting/ending balance. Free reference upload, discovery, retrieval and
deterministic PixelLab corrections are authorized. No unrelated account changes,
deletion, publication or repeated calls just for test counts. Stop new paid work
if the remaining limit cannot cover it; preserve a useful partial continuation.
Never silently retry an ambiguous paid submission; reconcile its actual identifier.

Do not read tokens, auth configuration or secret environment variables. The host
connection supplies authentication. Save tool schemas/discovery with the observed
clock, exact arguments and authorization scope, without credentials. Preserve
failed results, mistaken calls and revisions rather than rewriting receipts.

## Native caller and specialist collaboration

The caller must invoke one actual named `pixl` specialist with this whole
assignment, consumer root, kit and Python. Codex uses agent_type="pixl" with
fork_turns="none". A generic substitute is not qualification. Retain the actual
child identity, wait for it, and use the same child for feedback/recovery.
The specialist reads the installed shared skill C:/Users/ryanf/AppData/Local/Temp/pixl readiness codex clean ejarrjfy/consumer/installed pixl/skills/pixl/SKILL.md
and profile, then the relevant public workflow references and actual consumer.

First the specialist saves a concrete source-bound request/criteria packet and
literal review context for the caller, including actual provider image inputs and
the full delivered scope. Before paid dispatch, the caller independently reads
the original sources/reference pixels and exact packet, compares **every criterion**
and source/choice interpretation, writes work/native-production/COMPARISON.json, and sends its
findings to the same child. Correct contradictions before dispatch. Scope expert
choices honestly; do not promote a sample recipe into an owner requirement.
The caller must remain active through the complete result. A background child
launch plus a final 'waiting' message is an incomplete assignment.

The specialist then completes the authorized useful production: durable local
preparation and dispatch claim BEFORE each official host call, actual returned ID
and observations, retrieval/import of exact downloaded bytes, native/enlarged
inspection, appropriate revision if required, actual consumer rendering, explicit
candidate/family review and acceptance only when justified, PLAR and caller handoff.
Use `--help`/actual MCP schemas; only supply result_path where advertised. Existing
CLI stdout capture is a valid full-result route. Read full exact report locators.
The host's actual official call establishes provider execution; local J records or
handwritten assertions do not. Do not create fake provider IDs or fixture responses.

Write work/native-production/SPECIALIST-RESULT.json with: status, scope, source_refs,
comparison_ref, provider_operations (tool, actual_id, job, arguments_ref,
response_ref, observed_usage), delivered_files (path/sha256 and role),
state_ref, plar_ref, review_refs, renderer_report_ref, renderer_check_ref,
viewed_images (path/sha256), handoff_ref, lineage_findings, preservation,
failures_and_recovery, limitations, next_action. Use exact file references;
include actual operations only, and keep generated/edited/reused members distinct.
All fresh work reports/art candidates belong under work/native-production or the fresh .pixl store;
only assigned delivered destinations and production-plar.txt may change outside those folders.

Caller: independently inspect the specialist result, provider receipts, actual
files and renderer evidence. Use an image tool to inspect the final generated
files/reference and rendered destination at 1x/3x, compare actual identities and
source mapping, and consume the compact public caller handoff including exact
full retrievals where needed. Do not duplicate paid work for verification. Write
work/native-production/CALLER-RESULT.json with native_child, specialist_result, comparison_ref,
provider_operations, delivered_files, viewed_images, renderer_report_ref,
renderer_check_ref, handoff_ref, independent_checks, status, preservation,
guided_recovery, limitations and next_action. A status of delivered requires the
whole assignment and actual consumption. Honest incomplete output retains its
specific missing acceptance and resumable next action. Do not close M1/M2 or
broader M3, general artistic quality or host reliability.
