# Observe actual fresh-consumer readiness

You are the calling agent in claude; observed executable version is 2.1.318 (Claude Code).
Assess the actual available native specialist, installation, root, local runtime
and official-tool visibility. Do not treat files or supplied assertions as proof
of host loading, tool execution, authentication or successful production.

Inspect available native delegation declarations. If the configured `pixl:pixl`
specialist is actually selectable, invoke that exact role with this consumer root,
kit and assignment (Codex: agent_type="pixl", fork_turns="none"). Ask it to read
the actual common skill/profile and BRIEF.md, perform the read-only runtime checks
below, and return work/readiness/SPECIALIST-RESULT.json with their exact identities and
its useful readiness findings. Wait for completion and retain its actual child ID.
If that role is not available or cannot be observed, record the precise evidence
and distinguish unavailable from not_observed. Do not invent a specialist, use a
generic replacement, or change registration. A role may be exposed by a route
other than the evaluator's intended route; report what you actually observe.

Whether a specialist is available or not, obtain these actual local MCP results:
- pixl_source: BRIEF.md, exact SHA-256 5ebd3276eb2dc61da4594ae3c351e18b2adf0184a3b2c497001aa902f1183c5e, lines1-3,
  scope project. Retain the full result under work/readiness/source.json.
- pixl_sources: inspect the installed source inventory; retain the full result
  under work/readiness/library.json. This is local library retrieval, not remote research.
- pixl_readiness: host=claude, installation="C:/Users/ryanf/AppData/Local/Temp/pixl readiness claude clean e69go7kd/consumer/installed pixl", with
  observations derived from this session's actual declarations/results. Retain
  the full result under work/readiness/readiness.json. Use the tool's actual schema and
  result_path when available; do not forge returned data. Write the exact supplied
  observations to work/readiness/observations.json. Read the installed readiness reference
  for its schema. Its numeric host_version excludes product-name text. Inventory
  completeness must be justified; a subset of observed tools is not a complete list.
  Do not call a remote tool to probe availability or authentication. The local
  capabilities catalog is dated documentation, not current official tool discovery.

Independently compare returned source text/hash and root with the actual BRIEF.md,
and readiness installation identities with the copied kit. For a real specialist,
read its result and compare it rather than accepting its self-description as proof.
Write work/readiness/CALLER-RESULT.json with host, status, root, target_role,
role_observation (available/unavailable/not_observed), native_child (actual ID or
null), observations_file, readiness, source, library, specialist_result (or null),
role_evidence, checks, limitations and next_action. File references use
{"path":"consumer-relative/path","sha256":"actual hash"}. This report may
honestly complete while describing incomplete setup. Separate file presence,
advertised role/tools, actual role invocation, returned runtime observations and
provider authentication. No broad production-readiness or host-reliability pass.
