---
name: plar
description: Load the installed PLAR workflow.
---

Read `C:/Users/ryanf/AppData/Local/Temp/pixl readiness codex clean t8vl_9bd/consumer/installed pixl/skills/plar/SKILL.md` and resolve its links from that file.
