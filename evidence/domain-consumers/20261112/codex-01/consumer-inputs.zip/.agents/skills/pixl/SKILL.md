---
name: pixl
description: Load the installed PIXL workflow.
---

Read `C:/Users/ryanf/AppData/Local/Temp/pixl readiness codex clean t8vl_9bd/consumer/installed pixl/skills/pixl/SKILL.md` and resolve its links from that file.
