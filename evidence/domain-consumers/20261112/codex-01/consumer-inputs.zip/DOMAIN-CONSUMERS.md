# Qualify the two controlled domain consumers

Delegate to one actual named `pixl` specialist (Codex: agent_type="pixl", fork_turns="none").
Retain its actual identity and wait for completion. It MUST read the complete installed
`skills/pixl/SKILL.md`, `resources/agent/PROFILE.md` and consumer-execution workflow reference.
Use this kit's actual paths; locate the profile if its shared path differs.

The specialist must read BRIEF.md, both src modules and the two config/context files
under work/domain-consumer-inputs. These controlled families have only measured geometry accepted.
Family visual continuity and destination requirements remain unreviewed. No real art
quality or human acceptance is assigned. For each domain `terrain` and `animation`:
1. Inspect the public tool schema or CLI help, then use `pixl_consumer_execute` (or
   frozen public CLI) on `.pixl/assets/<domain>/state.px`, candidate
   `delivery.candidate`, exact `<domain>-config.json`, out `work/domain-consumers/<domain>-01`.
   Save the actual full returned JSON to `work/domain-consumers/<domain>-result.json` using the
   advertised result_path or exact CLI stdout. Do not transcribe or invent receipts.
2. Read the returned report, checks, cleanup and NF-06 observation. View actual
   screenshot/canvas PNGs with an image tool at both 1x and 3x, covering both terrain
   neighborhoods, every animation frame and its anchored context. Timing samples
   establish observed playback; stills do not establish subjective live viewing.
3. Judge the BRIEF's material joins and planted-floor intent from actual pixels.
   A mechanical pass is not visual continuity. Give any defect a precise asset/frame,
   visible symptom, contextual evidence, likely correction and preservation scope.
   Do not edit pixels or metadata, nominate, review, accept, or submit provider work.

Write work/domain-consumers/SPECIALIST-RESULT.json with operations (terrain/animation exact result
references), viewed_images (exact path/sha256 refs), findings, mechanical_vs_visual,
production_unchanged=true, acceptance_created=false, limitations and next_action.

Caller: independently read both COMPLETE saved operation results and specialist
report. Compare actual hashes/status/checks/cleanup and unchanged production state.
View the returned images too, including every frame and both neighborhoods at both
scales. Do not rerun merely to duplicate observation. Write work/domain-consumers/CALLER-RESULT.json
with native_child, specialist_result, operations, viewed_images, independent_checks,
findings, production_unchanged=true, acceptance_created=false, scope, limitations and
next_action. Every reference is {"path":"consumer-relative/path","sha256":"actual digest"}.
Keep CF-09 actual generated-art revision and human acceptance separate and open.
