# Drone representative sample: creative brief (v1)

Kind: `creative_brief`. NOT executable provider arguments. No PixelLab tool or schema has
been discovered in this session and no provider call is authorized. Before any dispatch,
translate this brief into the arguments of a discovered tool declaration and submit that
exact payload for a new request review.

Brief: `OWNER.md` (sha256 `4df3cf3664a0f5d3e015688ec1566063e691a465b143c4ee9585db8c51104fe6`).
Criteria: `contract/v1/criteria.json`. Reference measurements: `contract/v1/reference-measurement.json`.

## B1. Deliverable

One drone sprite on a **16x16 canvas** (owner, OWNER.md line 1), matching the supplied
reference `small-separated.png`. Sample shape (specialist choices, see section B4): a single
static frame, generated at native 16x16, one output.

## B2. Reference input

| Field | Value |
| --- | --- |
| File | `small-separated.png`, sha256 `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c`, 16x16, 1 frame |
| Role | style + identity (owner: "review the supplied small-separated.png reference and prepare a matching drone") |
| Transport | Must be sent through the chosen tool's real image input (upload handle / URL / encoded payload) once discovered. A filename in prompt text transmits nothing. Record local hash, returned handle and request field. |
| Not its role | palette (no fixed palette is approved), exact layout/coordinates |

If the discovered tool cannot take an image reference at a 16x16 output, report that verified
tool limitation and the viable alternatives to the caller; do not silently change the canvas
or fall back to text-only conditioning presented as equivalent.

## B3. Prompt text: owner requirements (keep all; do not weaken)

> 16x16 pixel-art drone that matches the reference image. Teal body enclosed by a thick,
> two-pixel-wide dark frame. Two separate antenna pieces, each detached from the body.

Source of each clause: OWNER.md line 1 -- "16 by 16 canvas", "thick two-pixel dark frame around
the teal body", "two detached antenna islands", "matching drone", "Keep those choices."

## B4. Prompt additions: specialist proposals (labeled at the prompt; removable; not owner-adopted)

> [proposal P1] Front view. [proposal P2] Transparent background. [proposal P3] Boxy
> rectangular body. [proposal P4] Antennae floating above the body with transparent pixels
> between them and the body. [proposal P5] Two small light eyes on the teal face, not touching
> the frame. [proposal P6] Antennae in the same dark color as the frame. [proposal P7] Hard-edged
> pixels, no semi-transparent pixels.

Each proposal comes from a reference observation (contract/v1/reference-measurement.json) or
from specialist judgment; none is an owner requirement. Non-compliance with a proposal is
reported, not a rejection (see criteria `S-*`, `O-*`).

Non-prompt specialist choices for this sample:

- C1 single static frame, one output (cheapest question that tests the owner's choices).
- C2 generate natively at 16x16; do not generate larger and nearest-neighbor downscale.
- C3 reference role style+identity rather than init/layout image, so coordinates are not
  copied by construction. If the discovered tool only offers an init image, that is a
  method change to report with the request.

## B5. Explicitly excluded from the request

- No palette lock, hex list or color count. Owner: "I have not approved a fixed palette."
  The reference colors #25354a / #56b5bc / #f4dda2 are observations.
- No restriction from `old-assessment.md` (unapproved; a different robot, a 32 px source
  nearest-neighbor-resized to 16). No 32 px minimum, no single-component rule, no
  three-color prop lock.
- No engine/destination claim: none was given.

## B6. Optional labeled experiments (only if the caller/owner wants them; not production rules)

- X1 palette experiment: constrain to the three observed colors and compare against the
  unconstrained sample. Informs a palette decision; does not make it.
- X2 alpha experiment: compare a binary-alpha sample against an unconstrained one if the
  owner wants an alpha policy decided.
