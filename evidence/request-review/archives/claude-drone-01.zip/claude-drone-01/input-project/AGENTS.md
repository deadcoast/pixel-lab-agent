This is an isolated native agent-to-agent planning evaluation.
Work only inside this consumer project. Use the packaged PIXL skill at
.agents/skills/pixl-kit/skills/pixl/SKILL.md and its delegation/request-review operation.
Keep production scope from OWNER.md. Planning is the requested deliverable in this
evaluation; no remote generation, credentials, package installs or host setting changes.
Local PIXL MCP tools are available for source retrieval and file/image measurements.
The caller owns the independent caller-review; the specialist must not impersonate it.
Return actual files and exact byte hashes, not claims that a self-audit passed.

Selected Python: C:/Users/ryanf/github/gh/pixel-lab-agent/.venv/Scripts/python.exe
