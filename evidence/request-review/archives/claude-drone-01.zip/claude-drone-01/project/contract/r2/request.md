# Drone sample request, revision 2 (creative brief)

Kind: `creative_brief`. This file is **not** executable provider arguments. No PixelLab tool declaration was connected in this session, so the provider tool, field names, and controls are unknown. Do not dispatch this text as-is. Before any call, discover the live tool and schema, translate this brief into exact arguments, and compare those arguments with this brief and `criteria.json` (see request-review.md, "Carry the comparison through production").

Authorization: planning only. This session made no provider call and no upload, and it did not initialize PX2 state.

Authority labels used below:
- **[owner]**: an owner requirement from `OWNER.md` line 1. Only these are enforced as rejection checks.
- **[proposal]**: a specialist sample choice made for this first sample. It can be removed or changed without changing the owner's brief.
- **[observation]**: measured in `small-separated.png`. It is not a rule.

## 1. Deliverable

- One drone sprite. **[owner]** 16 x 16 px canvas.
- **[proposal]** One static frame and one candidate output. This is the smallest representative sample that can test the owner's three choices before any family, animation, or batch work.
- **[proposal]** Generate at native 16 x 16. Do not generate larger and downscale. A nearest-neighbor resize changes cluster and border structure; that is the failure mode `old-assessment.md` describes for a different robot. If no connected tool offers a native 16 x 16 output, report that as a verified tool limitation and return the decision to the caller/owner. Do not silently change the canvas.

## 2. Reference input

| Field | Value |
| --- | --- |
| File | `small-separated.png` |
| sha256 | `1c45c866f9d11ff57b055f4dacf1e47c8e71f2c99fd6b24f0cb4259ee40cbe5c` |
| Role | **Style and identity anchor**: the art language (dark 2 px frame, teal body, flat clusters, hard pixel edges) and the drone's identity (boxy body, two eyes, two floating antenna nodes). |
| Not its role | It is not a palette lock, not a coordinate template, and not a pixel-copy target. A brief-conforming drone with different colors, positions, gaps, or face details is a valid candidate. |

How it must be transmitted:
- Send the actual image bytes through the selected tool's real image input. Depending on the live schema, that is an upload URL/handle (e.g., from `get_upload_url`), an owned source ID, a URL, or an encoded image payload. **A filename or this hash written in prompt text does not transmit the image.**
- Prefer an input whose declared role is a style/reference image. If the only image input is an init image, note that it also conditions composition, which would push the result toward copying the reference layout. Record that as a consequential choice for caller review before dispatch.
- If the chosen operation has no image input, a text-only request is an **approximation**. Label it that way in the request; it does not count as reference conditioning.
- Retain in production evidence: the local sha256 above, the returned handle/ID, and the exact request field that carried it.

## 3. Prompt content

### 3.1 Requirement text (owner; must survive into any dispatched prompt)

> 16x16 pixel art drone. Teal body enclosed by a thick, two-pixel-wide dark frame on every side. Two separate antenna pieces, each detached from the body with empty pixels between them and the body.

The words "teal" and "dark" are qualitative. No numeric hue or luminance threshold has been adopted.

### 3.2 Proposal text (specialist sample choices, labeled at the prompt; removable)

> [proposal] Front-facing view. [proposal] Transparent background. [proposal] Compact boxy body. [proposal] Antenna pieces floating above the body. [proposal] Two small light eyes on the teal face, not touching the frame. [proposal] Antennae in the same dark color as the frame. [proposal] Hard-edged pixels with no semi-transparent edge pixels.

Why these choices:
- **Front view, boxy body, floating antennae, eyes**: these match the reference's identity. That is the request ("a matching drone approach"). The owner did not specify them, so they stay proposals.
- **Transparent background**: without it, "detached" cannot be checked with alpha component analysis, and the sprite cannot be placed over arbitrary scenes. Destination background is unknown, so this is a proposal.
- **Eyes not touching the frame**: avoids the contour-merging failure reported in `old-assessment.md` for a different robot. On a 6 x 4 interior this is a readability choice, not a rule.
- **Hard edges / no semi-transparent pixels**: the reference has 0 fractional-alpha pixels. Alpha policy has **not** been adopted by the owner. This choice keeps the first sample consistent with the reference so the three owner choices are tested without an extra variable. A candidate with fractional alpha is reported, not rejected.
- **Antenna color = frame color**: matches the reference's single dark value. It is reported, not enforced.

### 3.3 Excluded from the request (do not add)

- No hex colors and no palette lock. The owner has not approved a fixed palette. Colors come from the style reference input. The measured three colors `#25354A`, `#56B5BC`, `#F4DDA2` are observations only.
- No requirement on total component count, antenna size, gap rows, or exact coordinates.
- None of the `old-assessment.md` rules: a 32 px minimum for thick outlines (contradicts the owner's 16 x 16), one connected component (contradicts the two detached antenna islands), and locking props to three colors (contradicts the open palette).

## 4. Tool selection (to do when authorized)

1. Discover the connected PixelLab tools and read their live declarations. Candidate class: a freeform single-image generator that declares a 16 x 16 output and a style/reference image input. No tool name is assumed here.
2. Confirm from the declaration: native 16 x 16 support, the reference-image field and its role, transparent-background support, and output count. Do not infer any parameter from prose docs alone.
3. Write the exact provider arguments as a later contract revision with `kind: provider_arguments`. Return it for caller comparison before dispatch.

## 5. Planned outcome handling

- Evaluate the candidate against `criteria.json` (saved before generation).
- A failed rejection check fails **that attempt** only; it does not show that the provider or the 16 x 16 design is generally incapable. Fallbacks, in order: (a) masked edit/inpaint of the failing region on that candidate, (b) retry with stronger reference conditioning if the schema offers it, (c) hand-repair at native 16 x 16. The reference shows that the owner's design fits on this canvas.
- A change to any owner requirement goes back to the owner as options. It is not a silent revision.
- Destination engine: none given. Import and in-game background contrast are out of scope and remain unverified.
