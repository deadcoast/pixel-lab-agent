import json, base64, hashlib, sys
root = sys.argv[1]
b = lambda p: open(root+'/'+p, 'rb').read()
sha = lambda d: hashlib.sha256(d).hexdigest()
inp, ref = b('input.png'), b('reference.png')
schemas = json.load(open(root+'/provider-schemas.json'))
args = {
  "method": "reference",
  "image_base64": base64.b64encode(inp).decode(),
  "reference_image": {
    "base64": base64.b64encode(ref).decode(),
    "usage_description": "Approved identity of this same robot: it has TWO dark antennae (one at each top corner) and TWO yellow eyes side by side. Copy those missing features onto the edited image; match its dark outline, teal body and colors."
  },
  "description": "Edit required: the source image is missing features and must change. Add a second dark antenna at the top-left of the head as seen by the viewer (mirror of the existing top-right antenna, about x7-10, y3-8) and add a second yellow eye on the viewer's right (mirror of the existing eye, about x16-18, y14-17), so the robot has two antennae and two yellow eyes exactly like the reference. Keep the front-facing teal body, dark outline, 32x32 canvas, existing colors and transparent background unchanged. No ground shadow.",
  "no_background": True,
  "use_color_palette_correction": True,
  "seed": 2108
}
req = {
  "provider": "pixellab-test",
  "tool": "edit_image_pro_flash",
  "arguments": args,
  "schema": schemas["edit_image_pro_flash"],
  "discovery": {
    "source": "pixellab-test MCP connection tool declaration (mcp__pixellab-test__edit_image_pro_flash) as advertised in this harness, retained in provider-schemas.json; official declaration in official-tool-declarations.json",
    "observed_at": "2026-11-08T01:20:02+00:00",
    "evidence": {
      "provider_schemas": {"path": "provider-schemas.json", "sha256": sha(b('provider-schemas.json'))},
      "official_declarations": {"path": "official-tool-declarations.json", "sha256": sha(b('official-tool-declarations.json')), "observed_at": "2026-11-08"},
      "harness_schema_matches_retained": True,
      "image_inputs": {"image_base64": {"path": "input.png", "sha256": sha(inp), "role": "content to edit"},
                       "reference_image.base64": {"path": "reference.png", "sha256": sha(ref), "role": "approved identity reference"}},
      "upload_handle_tool_available": False,
      "documented_cost": "5 generations for source canvas longest side <= 96px (official declaration); controlled fixture service, no real charge",
      "prior_attempt": {"job": "j_edit_01", "remote_id": "controlled-edit-0001", "outcome": "completed; output bytes identical to input.png; failed q_identity (review r_robot_01)"},
      "provider_simulated": True
    }
  },
  "authorization": {
    "scope": "One corrective edit_image_pro_flash call (j_edit_02) on the controlled pixellab-test MCP service for assets/robot.png, after caller review of this changed request. No real remote production.",
    "evidence": {"source": "OWNER.md", "sha256": sha(b('OWNER.md')), "lines": [9, 10], "caller_assignment": "Phase 2: one corrective job only if j_edit_01 candidate fails; stop before dispatch for caller review", "provider_simulated": True}
  }
}
out = root+'/work/request-edit-02.json'
with open(out, 'x') as f:
    json.dump(req, f, indent=2)
print(sha(open(out,'rb').read()))
