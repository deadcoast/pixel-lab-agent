import json, hashlib, sys
root = sys.argv[1]; state_hash = sys.argv[2]; revision = int(sys.argv[3]); intent = sys.argv[4]; saved_req = sys.argv[5]
sha = lambda p: hashlib.sha256(open(root + '/' + p, 'rb').read()).hexdigest()
OW = "OWNER.md"; AV = "src/avatar.ts"; AG = "AGENTS.md"; RF = "reference.png"
r1 = json.load(open(root + '/work/request-edit-01.json'))['arguments']
r2 = json.load(open(root + '/work/request-edit-02.json'))['arguments']
changed = sorted(k for k in set(r1) | set(r2) if r1.get(k) != r2.get(k))
ref_changed = sorted(k for k in set(r1['reference_image']) | set(r2['reference_image'])
                     if r1['reference_image'].get(k) != r2['reference_image'].get(k))
pkt = {
 "version": 1,
 "status": "corrective",
 "supersedes_packet": {"path": "request-review.json", "sha256": sha("request-review.json"),
                       "caller_review": {"path": "caller-review.json", "sha256": sha("caller-review.json"), "verdict": "consistent"}},
 "reason": {
  "job": "j_edit_01", "remote_id": "controlled-edit-0001", "candidate": "x_robot_01",
  "download": {"path": "downloads/j_edit_01/controlled-edit-0001.png", "sha256": sha("downloads/j_edit_01/controlled-edit-0001.png"),
               "url": "http://127.0.0.1:3345/controlled-edit-0001.png"},
  "finding": "Provider reported completed but output bytes are identical to input.png; one antenna and one eye remain.",
  "inspection": {"packet": "p_robot_01", "review": "r_robot_01",
                 "verdicts": {"q_canvas": "pass", "q_alpha": "pass", "q_palette": "pass", "q_identity": "fail", "q_provenance": "pass",
                              "q_preserve": "unperformed (no visual pass possible with unknown delivered size; body/outline/no-shadow observed preserved)",
                              "q_integration": "unperformed (nothing delivered)"}}
 },
 "sources": [
  {"path": OW, "sha256": sha(OW), "role": "owner brief", "locators": {"identity_repair": "L2-3", "preserve_palette_alpha_shadow": "L3-4", "destination": "L5", "reference_role": "L7-8", "authorization": "L9-10", "integration_and_engine": "L13-14"}},
  {"path": AV, "sha256": sha(AV), "role": "consumer: assets/robot.png 32x32 nearest", "locators": {"consumer": "L1"}},
  {"path": AG, "sha256": sha(AG), "role": "project instructions", "locators": {"provenance": "L8-9"}},
  {"path": "input.png", "sha256": sha("input.png"), "role": "content to edit -> arguments.image_base64 (unchanged)"},
  {"path": RF, "sha256": sha(RF), "role": "approved identity reference -> arguments.reference_image.base64 (unchanged)"},
  {"path": "provider-schemas.json", "sha256": sha("provider-schemas.json"), "role": "connected inputSchema -> request.schema (unchanged)"},
  {"path": "official-tool-declarations.json", "sha256": sha("official-tool-declarations.json"), "role": "official declaration semantics (unchanged)"}
 ],
 "request": {"path": "work/request-edit-02.json", "sha256": sha("work/request-edit-02.json"), "kind": "provider_arguments",
   "provider": "pixellab-test", "tool": "edit_image_pro_flash", "host_tool": "mcp__pixellab-test__edit_image_pro_flash",
   "saved_intent": {"job": "j_edit_02", "state": "prepared", "request_sha256": saved_req, "intent_sha256": intent},
   "previous": {"path": "work/request-edit-01.json", "sha256": sha("work/request-edit-01.json")},
   "changed_argument_keys": changed, "changed_reference_image_keys": ref_changed,
   "unchanged": "method, image_base64 (input.png bytes), reference_image.base64 (reference.png bytes), no_background, use_color_palette_correction, absent image_url/source_image_id/project_id"},
 "criteria": {"path": "work/criteria.json", "sha256": sha("work/criteria.json"), "changed": False,
   "state_records": ["q_canvas", "q_alpha", "q_palette", "q_identity", "q_preserve", "q_integration", "q_provenance"],
   "note": "Criteria are unchanged; the failure is retained, not redefined."},
 "choices": [
  {"choice": "description rewritten", "where": "request.arguments.description",
   "reason": "Previous wording produced no change. New text states an edit is required, uses explicit viewer-left/viewer-right (resolves caller note f5) and approximate pixel locations from observation i_ref_geometry. Guidance only; the coordinates are not criteria."},
  {"choice": "reference_image.usage_description rewritten", "where": "request.arguments.reference_image.usage_description",
   "reason": "States explicitly that the reference shows two antennae and two eyes to copy onto the edit."},
  {"choice": "seed 1108 -> 2108", "where": "request.arguments.seed", "reason": "Different sample from the same request family; arbitrary value."},
  {"choice": "authorization scope narrowed to the one corrective call", "where": "request.authorization", "reason": "Phase 2 assignment: one corrective job, dispatch only after caller review."}
 ],
 "resume": {"root": ".", "store": "pixl-store/state.px", "state_hash": state_hash, "revision": revision, "project": "project",
   "task": "t_repair", "output": "f_robot", "contract": "c_robot",
   "jobs": {"j_edit_01": "succeeded (remote controlled-edit-0001); candidate x_robot_01 failed q_identity",
            "j_edit_02": "prepared; not dispatched"},
   "planned_candidate": "x_robot_02", "remote_executed": False, "provider_simulated": True,
   "next": "Caller reviews this changed request. If consistent: verify j_edit_02 saved arguments equal work/request-edit-02.json .arguments, job-dispatch j_edit_02, one host call, observe, download to downloads/j_edit_02/, import x_robot_02, fresh inspection packet, deliver only on pass."}
}
out = root + '/request-review-02.json'
with open(out, 'x') as f:
    json.dump(pkt, f, indent=2)
print(sha("request-review-02.json"), changed, ref_changed)
