import json, subprocess, sys
root = sys.argv[1]
state = json.loads(subprocess.check_output([sys.executable, root+'/.agents/skills/pixl-kit/scripts/pixl.py', 'decode', root+'/pixl-store/state.px']))
R = lambda i: {"$ref": i}
Y = lambda s: {"$symbol": s}
AT = "2026-11-08"
def S(i, ur, dg, ln): return {"id": i, "kind": "S", "fields": {"ur": ur, "dg": dg, "ln": ln, "at": AT, "au": Y("local")}}
def I(i, ky, st, vl, so, wy, wh="user"): return {"id": i, "kind": "I", "fields": {"pr": R("project"), "wh": R(wh), "ky": ky, "st": Y(st), "vl": vl, "so": [R(s) for s in so], "wy": wy}}
def Q(i, nm, dm, md, ck, so, wh="user"): return {"id": i, "kind": "Q", "fields": {"nm": nm, "dm": Y(dm), "md": Y(md), "ck": ck, "wh": R(wh), "so": [R(s) for s in so]}}
PAL = ["#25354A", "#56B5BC", "#F4DDA2"]
recs = [r for r in state["records"]]
new = [
 S("s_owner", "OWNER.md", "99da59cdd123de831b167e036fbed1a6a13ab03feb7d65259a120af6d6b4c7c3", [1, 14]),
 S("s_agents", "AGENTS.md", "5dc049bd62743909605de301eb1a4ad37d5def738b4c2ac9b4160ccc46527df4", [1, 14]),
 S("s_avatar", "src/avatar.ts", "d09253a6c8d99ebd04eb1fd645baf18babbabb6ff9f5bed35defef25ef9c90dc", [1, 1]),
 S("s_input", "input.png", "d28f90f619400f8a770741b23bb5c1da995e6b6dd017ebab30eac934892c8d8d", []),
 S("s_reference", "reference.png", "d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7", []),
 S("s_schemas", "provider-schemas.json", "7ef6659e9886bd1a839c0a511c004cde386cb8fd0abcade267ee78417ecb3a2a", []),
 S("s_decl", "official-tool-declarations.json", "663457e005bf4c74c29af51339d7f55a197e08d99ec25a0874c654854bd9ba28", []),
 I("i_px", "px", "confirmed", [32, 32], ["s_owner", "s_avatar"], "OWNER.md line 4 requires the 32x32 canvas; src/avatar.ts line 1 declares width 32, height 32."),
 I("i_pl", "pl", "confirmed", PAL, ["s_owner", "s_reference"], "OWNER.md line 4 requires the reference palette; values are the three opaque colors measured in reference.png (transparency handled by al)."),
 I("i_al", "al", "confirmed", Y("binary"), ["s_owner"], "OWNER.md line 4 requires binary transparency."),
 I("i_sa", "sa", "confirmed", Y("nearest"), ["s_avatar"], "src/avatar.ts line 1 declares sampling: nearest."),
 I("i_li", "li", "confirmed", "no ground shadow", ["s_owner"], "OWNER.md line 4: no ground shadow. No other lighting requirement is stated."),
 I("i_vw", "vw", "proposed", Y("ui"), [], "Specialist choice: C requires a projection symbol and none names 'front-facing'; the avatar is a flat UI image. Front-facing orientation itself is carried by i_orientation and q_preserve.", wh="actor"),
 I("i_orientation", "orientation", "confirmed", "front-facing", ["s_owner"], "OWNER.md line 3: preserve the front-facing body."),
 I("i_body", "body", "confirmed", "teal body with dark outline", ["s_owner"], "OWNER.md line 3: preserve the teal body and dark outline."),
 I("i_identity", "identity", "confirmed", "two antennae and two yellow eyes, matching approved reference.png", ["s_owner", "s_reference"], "OWNER.md lines 2-3 and 8: restore both antennae and both yellow eyes; reference.png is the approved identity reference."),
 I("i_destination", "destination", "confirmed", "assets/robot.png", ["s_owner", "s_avatar"], "OWNER.md line 5 and src/avatar.ts line 1 consume assets/robot.png."),
 I("i_ref_geometry", "reference_geometry", "observed", "reference.png: 4x6 antennae at x7-10 and x21-24 (y3-8); 3x4 eyes #F4DDA2 at x9-11 and x16-18 (y14-17); outline #25354A; body #56B5BC; bilaterally symmetric", ["s_reference"], "Observation of reference pixels only; not an owner requirement or rejection rule.", wh="actor"),
 I("i_input_defect", "input_defect", "observed", "input.png lacks the viewer-left antenna (x7-10,y3-8) and the viewer-right eye (x16-18,y14-17) relative to reference.png; otherwise pixel-identical", ["s_input", "s_reference"], "Measured diff between fixtures; guides the edit description only.", wh="actor"),
 {"id": "c_robot", "kind": "C", "fields": {"nm": "Robot avatar 32x32", "px": [32, 32], "pl": PAL, "vw": Y("ui"), "sa": Y("nearest"), "al": Y("binary"), "li": "no ground shadow", "ch": [R(x) for x in ["i_px", "i_pl", "i_al", "i_sa", "i_li", "i_vw"]]}},
 {"id": "x_input", "kind": "X", "fields": {"nm": "Content to edit (first image)", "ur": "input.png", "dg": "d28f90f619400f8a770741b23bb5c1da995e6b6dd017ebab30eac934892c8d8d", "kd": Y("reference")}},
 {"id": "x_reference", "kind": "X", "fields": {"nm": "Approved identity reference", "ur": "reference.png", "dg": "d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7", "kd": Y("reference")}},
 Q("q_canvas", "canvas", "mechanical", "local", "The delivered PNG is exactly 32x32 pixels.", ["s_owner", "s_avatar"]),
 Q("q_alpha", "alpha", "mechanical", "local", "Every pixel has alpha 0 or 255 (binary transparency).", ["s_owner"]),
 Q("q_palette", "palette", "mechanical", "local", "Every opaque pixel uses a color from reference.png's palette (#25354A, #56B5BC, #F4DDA2).", ["s_owner", "s_reference"]),
 Q("q_identity", "identity", "visual", "visual", "At native and integer-enlarged scale the robot visibly has two antennae and two yellow eyes and reads as the approved reference.png identity.", ["s_owner", "s_reference"]),
 Q("q_preserve", "preserve", "visual", "visual", "The front-facing teal body and dark outline are preserved and no ground shadow is present.", ["s_owner"]),
 Q("q_integration", "integration", "other", "local", "assets/robot.png exists at the path src/avatar.ts consumes and its dimensions equal the declared width 32 and height 32 (nearest sampling declared by the consumer).", ["s_owner", "s_avatar"]),
 Q("q_provenance", "provenance", "other", "local", "The delivered bytes trace to the imported pixellab-test job output (X.of chain) and were not substituted or copied from reference.png.", ["s_agents", "s_owner"]),
 {"id": "f_robot", "kind": "F", "fields": {"tk": R("t_repair"), "nm": "assets/robot.png repaired robot avatar", "kd": Y("sprite"), "rq": [R(q) for q in ["q_canvas", "q_alpha", "q_palette", "q_identity", "q_preserve", "q_integration", "q_provenance"]], "ct": R("c_robot")}},
 {"id": "t_repair", "kind": "T", "fields": {"nm": "Repair robot identity with PixelLab reference edit and deliver assets/robot.png", "ow": R("actor"), "pr": R("project"), "dp": [], "dc": [], "kn": [], "st": Y("open"), "ph": Y("sample"), "ip": [R("x_input"), R("x_reference")], "op": [R("f_robot")], "ca": [], "vr": []}},
]
recs += new
for r in recs:
    if r["id"] == "project":
        r["fields"]["in"] = [R(x["id"]) for x in new if x["kind"] == "I"]
        r["fields"]["sc"] = [R("s_owner")]
state["records"] = recs
state["revision"] = 1
json.dump(state, open(root+'/work/state_r1.json', 'w'), indent=1)
print("ok")
