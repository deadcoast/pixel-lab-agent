import json, base64, hashlib, sys
root = sys.argv[1]
b = lambda p: open(root+'/'+p, 'rb').read()
sha = lambda d: hashlib.sha256(d).hexdigest()
inp, ref = b('input.png'), b('reference.png')
schemas = json.load(open(root+'/provider-schemas.json'))
args = {
  "method": "reference",
  "image_base64": base64.b64encode(inp).decode(),
  "reference_image": {
    "base64": base64.b64encode(ref).decode(),
    "usage_description": "Approved identity of this same robot: match its two dark antennae, two yellow eyes, dark outline, teal body and colors."
  },
  "description": "Repair this front-facing teal robot so it matches the reference identity: add the missing left antenna (same dark outline color and shape as the existing right antenna) and the missing right yellow eye (same as the existing left eye), giving two antennae and two yellow eyes. Keep the teal body, dark outline, 32x32 canvas, the existing colors and the transparent background. No ground shadow.",
  "no_background": True,
  "use_color_palette_correction": True,
  "seed": 1108
}
req = {
  "provider": "pixellab-test",
  "tool": "edit_image_pro_flash",
  "arguments": args,
  "schema": schemas["edit_image_pro_flash"],
  "discovery": {
    "source": "pixellab-test MCP connection tool declaration (mcp__pixellab-test__edit_image_pro_flash) as advertised in this harness, retained in provider-schemas.json; official declaration in official-tool-declarations.json",
    "observed_at": "2026-11-08T01:20:02+00:00",
    "evidence": {
      "provider_schemas": {"path": "provider-schemas.json", "sha256": sha(b('provider-schemas.json'))},
      "official_declarations": {"path": "official-tool-declarations.json", "sha256": sha(b('official-tool-declarations.json')), "observed_at": "2026-11-08"},
      "harness_schema_matches_retained": True,
      "image_inputs": {"image_base64": {"path": "input.png", "sha256": sha(inp), "role": "content to edit"},
                       "reference_image.base64": {"path": "reference.png", "sha256": sha(ref), "role": "approved identity reference"}},
      "upload_handle_tool_available": False,
      "documented_cost": "5 generations for source canvas longest side <= 96px (official declaration); controlled fixture service, no real charge",
      "provider_simulated": True
    }
  },
  "authorization": {
    "scope": "One edit_image_pro_flash call on the controlled pixellab-test MCP service for assets/robot.png; one corrective attempt only if needed after review. No real remote production.",
    "evidence": {"source": "OWNER.md", "sha256": sha(b('OWNER.md')), "lines": [9, 10], "caller_assignment": "Phase 1 contract handoff; dispatch deferred until caller review", "provider_simulated": True}
  }
}
out = root+'/work/request-edit-01.json'
json.dump(req, open(out, 'w'), indent=2)
print(sha(open(out,'rb').read()))
