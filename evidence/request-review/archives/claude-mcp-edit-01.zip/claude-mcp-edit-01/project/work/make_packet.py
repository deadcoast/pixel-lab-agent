import json, hashlib, sys
root = sys.argv[1]; state_hash = sys.argv[2]; intent = sys.argv[3]; saved_req = sys.argv[4]
sha = lambda p: hashlib.sha256(open(root + '/' + p, 'rb').read()).hexdigest()
OW = "OWNER.md"; AV = "src/avatar.ts"; AG = "AGENTS.md"; RF = "reference.png"
crit = {
 "version": 1,
 "assignment": {"brief": OW, "brief_sha256": sha(OW), "output": "assets/robot.png", "store": "pixl-store/state.px",
                "task": "t_repair", "output_plan": "f_robot", "contract": "c_robot"},
 "criteria": [
  {"id": "q_canvas", "check": "The delivered PNG is exactly 32x32 pixels.", "domain": "mechanical", "evidence_mode": "local",
   "authority": "owner+consumer", "basis": "OWNER.md requires the 32x32 canvas; avatar.ts declares width 32, height 32.",
   "scope": "assets/robot.png for this assignment", "locators": [OW + "#L4", AV + "#L1"]},
  {"id": "q_alpha", "check": "Every pixel has alpha 0 or 255.", "domain": "mechanical", "evidence_mode": "local",
   "authority": "owner", "basis": "OWNER.md: binary transparency.", "scope": "assets/robot.png for this assignment",
   "locators": [OW + "#L4"]},
  {"id": "q_palette", "check": "Every opaque pixel uses a color from reference.png's palette: #25354A, #56B5BC, #F4DDA2.",
   "domain": "mechanical", "evidence_mode": "local",
   "authority": "owner (values measured from the owner-designated reference)",
   "basis": "OWNER.md: preserve the reference palette. Interpretation: exact membership in the three opaque colors measured in reference.png; these are also the only opaque colors of input.png.",
   "scope": "assets/robot.png for this assignment only (OWNER.md L6-7)", "locators": [OW + "#L4", OW + "#L6-7", RF]},
  {"id": "q_identity", "check": "At native and integer-enlarged scale the robot visibly has two antennae and two yellow eyes and reads as the approved reference.png identity.",
   "domain": "visual", "evidence_mode": "visual", "authority": "owner",
   "basis": "OWNER.md: repair to match approved reference.png; restore the two antennae and two yellow eyes; reference is the approved identity reference.",
   "scope": "assets/robot.png for this assignment", "locators": [OW + "#L2-3", OW + "#L7-8", RF]},
  {"id": "q_preserve", "check": "The front-facing teal body and dark outline are preserved and no ground shadow is present.",
   "domain": "visual", "evidence_mode": "visual", "authority": "owner",
   "basis": "OWNER.md: preserve front-facing teal body, dark outline; no ground shadow.",
   "scope": "assets/robot.png for this assignment", "locators": [OW + "#L3-4"]},
  {"id": "q_integration", "check": "assets/robot.png exists at the path src/avatar.ts consumes and its dimensions equal the declared width 32 and height 32 (consumer declares nearest sampling).",
   "domain": "other", "evidence_mode": "local", "authority": "owner+consumer",
   "basis": "OWNER.md: deliver at assets/robot.png; source/path integration required. avatar.ts consumer entry.",
   "scope": "source/path integration only; not live engine rendering", "locators": [OW + "#L5", OW + "#L13", AV + "#L1"]},
  {"id": "q_provenance", "check": "The delivered bytes trace to the imported pixellab-test job output (job-import X.of chain), downloaded from its returned loopback URL, and were not substituted or copied from reference.png.",
   "domain": "other", "evidence_mode": "local", "authority": "project instruction + owner",
   "basis": "AGENTS.md: download from returned loopback URL; never substitute or copy reference.png. OWNER.md: use PixelLab to repair input.png.",
   "scope": "this assignment's delivered file", "locators": [AG + "#L8-9", OW + "#L2"]}
 ],
 "not_declared": [
  {"item": "live engine rendering",
   "reason": "OWNER.md L13-14: no runnable target engine supplied; remains unverified, not a prerequisite. No engine Q is declared, so it cannot block; it will be reported as unverified.",
   "locators": [OW + "#L13-14"]}
 ],
 "observations_non_binding": [
  {"id": "i_ref_geometry", "status": "observed",
   "value": "reference.png: 4x6 antennae at x7-10 and x21-24 (y3-8); 3x4 #F4DDA2 eyes at x9-11 and x16-18 (y14-17); outline #25354A; body #56B5BC; bilaterally symmetric; flat fills",
   "use": "Context for visual comparison only; exact pixel placement/symmetry is NOT a rejection rule.", "locators": [RF]},
  {"id": "i_input_defect", "status": "observed",
   "value": "input.png lacks the viewer-left antenna and viewer-right eye relative to reference.png; otherwise pixel-identical",
   "use": "Informs the edit description wording only.", "locators": ["input.png", RF]},
  {"id": "eye_color_term", "status": "observed",
   "value": "The owner's 'yellow' eyes are #F4DDA2 (pale yellow/cream) in both fixtures.",
   "use": "Interpretation of 'yellow' via the reference palette; no extra rule.", "locators": [RF, "input.png"]}
 ],
 "diagnostics_non_binding": [
  {"id": "d_ref_diff", "check": "Report per-pixel difference counts candidate-vs-reference.png and candidate-vs-input.png.",
   "use": "Diagnostic only; a non-zero difference does not by itself fail, and an exact match does not by itself pass or fail q_provenance."}
 ],
 "specialist_choices": [
  {"id": "i_vw", "value": "ui", "status": "proposed", "where": "c_robot.vw",
   "reason": "Registry requires a projection symbol; none names front-facing. Does not alter any owner criterion."},
  {"id": "phase", "value": "sample", "where": "t_repair.ph",
   "reason": "Single-asset assignment treated as the representative sample; avoids manufacturing a design-decision/knowledge-proof record. Completion still requires every declared Q to pass on the nominated candidate."}
 ]
}
json.dump(crit, open(root + '/work/criteria.json', 'w'), indent=2)

pkt = {
 "version": 1,
 "status": "partial",
 "sources": [
  {"path": OW, "sha256": sha(OW), "role": "owner brief (direct brief; authority for requirements and authorization)",
   "locators": {"identity_repair": "L2-3", "preserve_palette_alpha_shadow": "L3-4", "destination": "L5", "fixture_scope": "L6-7",
                "reference_role": "L7-8", "authorization": "L9-10", "integration_and_engine": "L13-14"}},
  {"path": AV, "sha256": sha(AV), "role": "consumer: path assets/robot.png, width 32, height 32, sampling nearest", "locators": {"consumer": "L1"}},
  {"path": AG, "sha256": sha(AG), "role": "project instructions (loopback download, never copy reference.png, provider_simulated=true)", "locators": {"provenance": "L8-9"}},
  {"path": "input.png", "sha256": sha("input.png"), "role": "content to edit -> arguments.image_base64"},
  {"path": RF, "sha256": sha(RF), "role": "approved identity reference -> arguments.reference_image.base64"},
  {"path": "provider-schemas.json", "sha256": sha("provider-schemas.json"), "role": "connected pixellab-test inputSchema for edit_image_pro_flash -> request.schema"},
  {"path": "official-tool-declarations.json", "sha256": sha("official-tool-declarations.json"),
   "role": "official declaration semantics (method=reference requires reference_image; native canvas unchanged; one image; cost ladder)"}
 ],
 "request": {"path": "work/request-edit-01.json", "sha256": sha("work/request-edit-01.json"), "kind": "provider_arguments",
   "provider": "pixellab-test", "tool": "edit_image_pro_flash", "host_tool": "mcp__pixellab-test__edit_image_pro_flash",
   "saved_intent": {"job": "j_edit_01", "state": "prepared", "request_sha256": saved_req, "intent_sha256": intent},
   "note": "File holds provider/tool/arguments/schema/discovery/authorization; dispatch sends exactly .arguments (saved verbatim in j_edit_01)."},
 "criteria": {"path": "work/criteria.json", "sha256": sha("work/criteria.json"),
   "state_records": ["q_canvas", "q_alpha", "q_palette", "q_identity", "q_preserve", "q_integration", "q_provenance"]},
 "choices": [
  {"choice": "method=reference; input.png as image_base64; reference.png as reference_image.base64", "where": "request.arguments.method/image_base64/reference_image",
   "reason": "OWNER.md L7-8 requires the reference as an actual image input; no upload-handle tool on this connection, so inline base64 (both 32x32, fit the source canvas)."},
  {"choice": "description naming the missing left antenna and right eye", "where": "request.arguments.description",
   "reason": "Specialist wording from observed input/reference diff (i_input_defect); guidance only, not a criterion."},
  {"choice": "reference_image.usage_description", "where": "request.arguments.reference_image.usage_description", "reason": "States the identity role of the reference."},
  {"choice": "no_background=true", "where": "request.arguments.no_background",
   "reason": "Explicitly keep transparent background (default would follow source transparency); q_alpha still checks the result."},
  {"choice": "use_color_palette_correction=true", "where": "request.arguments.use_color_palette_correction",
   "reason": "Declaration: matches source colors; input colors equal the reference palette. q_palette still checks the result."},
  {"choice": "seed=1108", "where": "request.arguments.seed", "reason": "Fixed seed for reproducibility; arbitrary value."},
  {"choice": "omit image_url, source_image_id, project_id", "where": "request.arguments", "reason": "No URL/owned ID exists for local fixtures."},
  {"choice": "vw=ui (proposed)", "where": "pixl-store i_vw / c_robot.vw", "reason": "Registry requires a projection symbol; front-facing is carried by q_preserve."},
  {"choice": "task phase=sample", "where": "pixl-store t_repair.ph", "reason": "Single deliverable treated as representative sample; no D/K manufactured."},
  {"choice": "no engine criterion declared", "where": "work/criteria.json not_declared", "reason": "OWNER.md L13-14; reported as unverified."},
  {"choice": "palette read as exact membership in the three reference colors", "where": "work/criteria.json q_palette", "reason": "Reading of 'the reference palette' with binary alpha; caller may confirm."}
 ],
 "resume": {"root": ".", "store": "pixl-store/state.px", "state_hash": state_hash, "revision": 2, "project": "project",
   "task": "t_repair", "output": "f_robot", "contract": "c_robot", "job": "j_edit_01", "job_state": "prepared",
   "planned_candidate": "x_robot_01", "corrective_job_if_needed": "j_edit_02 (new ID, only after review)",
   "remote_executed": False, "provider_simulated": True,
   "next": "Caller reviews this packet; on consistent, specialist runs job-dispatch j_edit_01, makes the one host call with the returned arguments, records the observation, downloads via loopback URL, imports, inspects, copies to assets/robot.png."}
}
json.dump(pkt, open(root + '/request-review.json', 'w'), indent=2)
for p in ["request-review.json", "work/request-edit-01.json", "work/criteria.json"]:
    print(sha(p), p)
