import json, glob, sys
w = json.load(open(sys.argv[1], encoding='utf-8'))['arguments']
hits = []
for p in glob.glob(sys.argv[2] + '/*.json'):
    try:
        d = json.load(open(p, encoding='utf-8'))
    except Exception:
        continue
    s = json.dumps(d)
    if '"seed": 2108' in s:
        def find(o):
            if isinstance(o, dict):
                if 'arguments' in o and isinstance(o['arguments'], dict) and o['arguments'].get('seed') == 2108:
                    return o['arguments']
                for v in o.values():
                    r = find(v)
                    if r: return r
            return None
        a = find(d)
        hits.append((p, a == w))
print(hits)
