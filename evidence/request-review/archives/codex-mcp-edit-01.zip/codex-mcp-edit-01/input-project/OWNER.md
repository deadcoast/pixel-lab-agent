# Restore the robot identity for this consumer
Use PixelLab to repair input.png to match the approved reference.png: restore the
two antennae and two yellow eyes. Preserve the front-facing teal body, dark outline,
32x32 canvas, the reference palette and binary transparency; no ground shadow.
Deliver one reviewed PNG at assets/robot.png, which src/avatar.ts already consumes.
The input and reference are controlled evaluation fixtures. Their geometry/palette
requirements apply only to this assignment. The first image is the content to edit;
reference.png is the approved identity reference, not just a text description.
The controlled MCP service is authorized for one edit and, if needed after review,
one corrective attempt. Real remote production is outside this evaluation.
The specialist should use durable job state and candidate inspection; the caller
must review the exact contract, then open and consume the delivered result.
Source/path integration is required. No runnable target engine is supplied, so
live engine rendering remains unverified rather than a prerequisite for this scope.
