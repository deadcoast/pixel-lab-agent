This is a controlled native delegated PixelLab workflow evaluation.
Work only in this consumer project. Use .agents/skills/pixl-kit/skills/pixl/SKILL.md,
the delegation/request-review operation and the normal durable provider/inspection
operations. The pixellab-test MCP connection advertises the exact input schemas
saved in provider-schemas.json. Its operation names and argument forms are based
on the retained current official declarations; all responses and images are
controlled fixtures. No upstream provider is connected. Use this connection only.
Download from its returned loopback URL; never substitute or copy reference.png as
the delivered output. Inspect actual returned files. Keep provider_simulated=true.
The selected Python is supplied below; dependencies are already installed.
Do not read credentials, install packages, contact other services or change host settings.
The caller owns independent contract review and final consumption, not the specialist.

Selected Python: C:/Users/ryanf/github/gh/pixel-lab-agent/.venv/Scripts/python.exe
