export const avatar = { path: "assets/robot.png", width: 32, height: 32, sampling: "nearest" };
