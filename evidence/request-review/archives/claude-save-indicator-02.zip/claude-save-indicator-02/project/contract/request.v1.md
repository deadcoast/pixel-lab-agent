# Save indicator art: creative brief v1

Kind: `creative_brief`. No PixelLab tool or schema was discovered in this session, so this brief is not executable provider arguments. Before any generation, discover the actual operation and schema, translate this brief into exact arguments, and run a new request review on those arguments.

Sources: `OWNER.md` (owner brief), `src/save-indicator.ts` (consumer). `design-notes.md` is an unadopted prototype. None of its blue, 32x32, all-connected, four-color or one-still-image choices apply here.

## Outcome (owner)
- A pixel-art save indicator in a **24x16 logical frame** (OWNER.md:2; consumer `frameSize`, src/save-indicator.ts:2).
- **Amber visual emphasis** (OWNER.md:2-3). Amber should be the hue the eye reads first. No palette is fixed: supporting hues, the number of colors and the shading are open.
- An **idle state** and an **animated saving state** (OWNER.md:3-4).
- **No new error artwork.** The consumer returns `{ sharedBadge: "error" }` for the error state (src/save-indicator.ts:5; OWNER.md:5).
- Detached sparkle pixels are allowed, and the silhouette does not have to be connected (OWNER.md:6-7).
- There is no reference image (OWNER.md:7). Style, motif and construction are open within the brief.

## Consumer facts (src/save-indicator.ts)
- Idle: a fixed path `assets/save-idle.png`, `frame: 0`, size 24x16 (line 6). The consumer always shows frame 0 and never animates idle.
- Saving: `path`, `frames` and `frameMs` come in through the `SavingSheet` argument (lines 3-4). The frame index is `Math.floor(elapsedMs / frameMs) % frames` (line 7). Playback therefore loops forever at a fixed rate, from frame N-1 straight back to frame 0. There is no per-frame timing, and no start or end sequence.
- Every returned object carries width 24 and height 16 (lines 6-7).
- The consumer does **not** define how a frame index maps to pixels inside the sheet (strip, grid, separate files), and it does not define the saving sheet path. It also does not say where `frames`/`frameMs` are configured.

## Requested deliverables (specialist proposals where marked)
1. `assets/save-idle.png`: one 24x16 frame. The path comes from the consumer.
2. Saving sheet: **proposal** `assets/save-saving.png`, a horizontal strip of 8 frames at 24x16 each (192x16 total), with frame *i* at x = 24*i. Path and layout are open decisions for the caller or renderer owner (see choices).
3. **Sample timing proposal:** `frames: 8` and `frameMs: 100`, giving an 800 ms loop. These are the values the caller passes as `SavingSheet`.
4. Background: **proposal** fully transparent outside the artwork, with binary alpha so the pixel edges stay crisp. The alpha policy is not set by the owner or the consumer.

## Art direction (expert judgment, revisable)
- The motif is open. One suggestion is a compact amber "save" glyph that fits a 24x16 landscape frame, such as a small storage/document shape or an amber dot/bar group. The idle frame shows it at rest. The saving frames add motion that clearly reads as "in progress", such as a travelling amber highlight, pulsing segments or orbiting sparkle pixels. Detached sparkles are welcome.
- Idle and saving should read as the same indicator: a shared base shape, scale and position, with saving adding activity. Idle should look calm, not paused in the middle of an animation.
- The loop must be seamless across N-1 to 0, because the modulo wrap plays it continuously.
- Keep the shape readable at 1x. Use a clean, deliberate pixel cluster without stray noise; sparkles are intentional, not artifacts. Avoid relying on anti-aliasing against unknown backgrounds.
- The first pass is a representative sample: the idle frame plus the 8-frame saving strip. Judge it before any family or variant work.

## Out of scope
- Error art, generation, provider dispatch, engine or renderer acceptance, and code changes to `src/`.
