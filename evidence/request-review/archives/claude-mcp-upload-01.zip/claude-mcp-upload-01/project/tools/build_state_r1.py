"""Author PX2 revision 1 (plan before any provider job). Writes JSON host document."""
import json
import sys

def ref(i): return {"$ref": i}
def sym(s): return {"$symbol": s}
def refs(*xs): return [ref(x) for x in xs]

D = "2026-11-07"
recs = []
def add(i, k, **f): recs.append({"id": i, "kind": k, "fields": f})

add("actor", "A", nm="PIXL", rl=sym("agent"))
add("user", "A", nm="Project owner", rl=sym("user"))

add("s_owner", "S", ur="OWNER.md", dg="99da59cdd123de831b167e036fbed1a6a13ab03feb7d65259a120af6d6b4c7c3", ln=[1, 14], at=D, au=sym("local"))
add("s_agents", "S", ur="AGENTS.md", dg="5dc049bd62743909605de301eb1a4ad37d5def738b4c2ac9b4160ccc46527df4", ln=[1, 14], at=D, au=sym("local"))
add("s_avatar", "S", ur="src/avatar.ts", dg="d09253a6c8d99ebd04eb1fd645baf18babbabb6ff9f5bed35defef25ef9c90dc", ln=[1, 1], at=D, au=sym("local"))
add("s_input", "S", ur="input.png", dg="d28f90f619400f8a770741b23bb5c1da995e6b6dd017ebab30eac934892c8d8d", ln=[], at=D, au=sym("local"))
add("s_reference", "S", ur="reference.png", dg="d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7", ln=[], at=D, au=sym("local"))
add("s_measure", "S", ur="evidence/source-measurements.json", dg="f4aa424cd8e08b19e3f19599ab08f273e69107638f0b66aa5af500e5fc01a50c", ln=[1, 120], at=D, au=sym("local"))
add("s_criteria", "S", ur="requests/robot-criteria.json", dg=sys.argv[2], ln=[1, int(sys.argv[3])], at=D, au=sym("local"))

PAL = ["#25354a", "#56b5bc", "#f4dda2"]
add("i_px", "I", pr=ref("project"), wh=ref("user"), ky="px", st=sym("confirmed"), vl=[32, 32], so=refs("s_owner", "s_avatar"), wy="OWNER.md L4 '32x32 canvas'; src/avatar.ts width/height 32.")
add("i_pl", "I", pr=ref("project"), wh=ref("user"), ky="pl", st=sym("confirmed"), vl=PAL, so=refs("s_owner", "s_reference", "s_measure"), wy="OWNER.md L4 'the reference palette'; hex values are the measured visible colors of reference.png. Scoped to this assignment (L6-7).")
add("i_al", "I", pr=ref("project"), wh=ref("user"), ky="al", st=sym("confirmed"), vl=sym("binary"), so=refs("s_owner"), wy="OWNER.md L4 'binary transparency'.")
add("i_sa", "I", pr=ref("project"), wh=ref("user"), ky="sa", st=sym("confirmed"), vl=sym("nearest"), so=refs("s_avatar"), wy="Consumer src/avatar.ts sampling: 'nearest'.")
add("i_vw", "I", pr=ref("project"), wh=ref("actor"), ky="vw", st=sym("proposed"), vl=sym("side"), so=refs("s_owner"), wy="Owner requires the front-facing view preserved (L3). The C vocabulary has no 'front' value; 'side' (orthographic elevation, no perspective) is the specialist's closest mapping. Identity/view preservation is judged by q_body, not by this symbol.")
add("i_li", "I", pr=ref("project"), wh=ref("actor"), ky="li", st=sym("observed"), vl="flat fills matching the reference; no added shading", so=refs("s_reference", "s_measure"), wy="Observation: reference/input use flat fills of three colors. Not an added rejection rule beyond the palette requirement.")

add("c_robot", "C", nm="robot-avatar-32", px=[32, 32], pl=PAL, vw=sym("side"), sa=sym("nearest"), al=sym("binary"), li="flat fills matching the reference; no added shading", ch=refs("i_px", "i_pl", "i_al", "i_sa", "i_vw", "i_li"))

add("x_input", "X", nm="input.png content to edit", ur="input.png", dg="d28f90f619400f8a770741b23bb5c1da995e6b6dd017ebab30eac934892c8d8d", kd=sym("reference"))
add("x_reference", "X", nm="reference.png approved identity reference", ur="reference.png", dg="d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7", kd=sym("reference"))

crit = json.load(open(sys.argv[1], encoding="utf-8"))
SO = {"q_canvas": ("s_owner", "s_avatar", "s_criteria"), "q_alpha": ("s_owner", "s_criteria"),
      "q_palette": ("s_owner", "s_reference", "s_measure", "s_criteria"), "q_identity": ("s_owner", "s_reference", "s_criteria"),
      "q_body": ("s_owner", "s_input", "s_reference", "s_criteria"), "q_shadow": ("s_owner", "s_criteria"),
      "q_integration": ("s_owner", "s_avatar", "s_criteria"), "q_provenance": ("s_owner", "s_agents", "s_criteria")}
qids = []
for c in crit["criteria"]:
    add(c["px2_record"], "Q", nm=c["id"], dm=sym(c["domain"]), md=sym(c["mode"]), ck=c["check"], wh=ref("user"), so=refs(*SO[c["id"]]))
    qids.append(c["px2_record"])

add("f_robot", "F", tk=ref("t_robot"), nm="assets/robot.png repaired robot avatar", kd=sym("sprite"), rq=refs(*qids), ct=ref("c_robot"))
add("t_robot", "T", nm="Repair robot identity via one reference edit and deliver assets/robot.png", ow=ref("actor"), pr=ref("project"),
    dp=[], dc=[], kn=[], st=sym("open"), ph=sym("sample"), ip=refs("x_input", "x_reference"), op=refs("f_robot"), ca=[], vr=[])

add("project", "P", nm="robot-identity-restore", ow=ref("user"),
    sc=refs("s_owner", "s_agents", "s_avatar", "s_input", "s_reference", "s_measure", "s_criteria"),
    **{"in": refs("i_px", "i_pl", "i_al", "i_sa", "i_vw", "i_li")},
    ct=ref("c_robot"),
    br="OWNER.md (sha256 99da59cdd123de831b167e036fbed1a6a13ab03feb7d65259a120af6d6b4c7c3): repair input.png to match approved reference.png; restore two antennae and two yellow eyes; preserve front-facing teal body, dark outline, 32x32 canvas, reference palette, binary transparency, no ground shadow; deliver one reviewed PNG at assets/robot.png consumed by src/avatar.ts.")

json.dump({"format": 2, "revision": 1, "records": recs}, sys.stdout, indent=1)
