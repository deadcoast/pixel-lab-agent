"""Reproducible pixel measurements for the robot identity contract.

Coordinates: zero-based, boxes are [left, top, right, bottom] with exclusive
right/bottom. Usage: python -I tools/measure_identity.py IMAGE [IMAGE ...]
Prints JSON. Measurements are observations, not acceptance verdicts.
"""
import hashlib
import json
import sys

from PIL import Image

OUTLINE = (37, 53, 74, 255)
TEAL = (86, 181, 188, 255)
EYE = (244, 221, 162, 255)
NAMES = {OUTLINE: "#25354a", TEAL: "#56b5bc", EYE: "#f4dda2"}


def box(points):
    if not points:
        return None
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return [min(xs), min(ys), max(xs) + 1, max(ys) + 1]


def components(points):
    left = set(points)
    out = []
    while left:
        stack = [left.pop()]
        comp = []
        while stack:
            x, y = stack.pop()
            comp.append((x, y))
            for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if n in left:
                    left.remove(n)
                    stack.append(n)
        out.append(comp)
    return sorted(out, key=lambda c: (box(c)[0], box(c)[1]))


def measure(path):
    data = open(path, "rb").read()
    im = Image.open(path).convert("RGBA")
    w, h = im.size
    px = {(x, y): im.getpixel((x, y)) for y in range(h) for x in range(w)}
    alphas = sorted({p[3] for p in px.values()})
    colors = {}
    for p in px.values():
        if p[3]:
            key = "#%02x%02x%02x%02x" % p
            colors[key] = colors.get(key, 0) + 1
    body_top = None
    # Body top = first row whose opaque run spans the full outline width (>= 18 px).
    for y in range(h):
        if sum(1 for x in range(w) if px[(x, y)][3]) >= 18:
            body_top = y
            break
    above = [(x, y) for (x, y), p in px.items() if p[3] and body_top is not None and y < body_top]
    antennae = [{"box": box(c), "pixels": len(c)} for c in components(above)]
    eyes = [{"box": box(c), "pixels": len(c)} for c in components([k for k, p in px.items() if p == EYE])]
    below = [(x, y) for (x, y), p in px.items() if p[3] and y >= 28]
    return {
        "path": path,
        "sha256": hashlib.sha256(data).hexdigest(),
        "frame": 0,
        "size": [w, h],
        "alpha_values": alphas,
        "visible_colors": colors,
        "visible_bbox": box([k for k, p in px.items() if p[3]]),
        "body_top_row": body_top,
        "above_body_components": antennae,
        "eye_color_components": eyes,
        "opaque_pixels_rows_28_plus": len(below),
    }


if __name__ == "__main__":
    print(json.dumps({
        "coordinate_convention": "zero-based; boxes [left, top, right, bottom], right/bottom exclusive; 4-connected components",
        "body_top_rule": "first row with >= 18 opaque pixels; 'above_body_components' are opaque 4-connected components strictly above that row",
        "images": [measure(p) for p in sys.argv[1:]],
    }, indent=2))
