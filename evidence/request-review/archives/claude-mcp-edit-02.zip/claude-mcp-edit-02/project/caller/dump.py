import sys
from PIL import Image
for p in sys.argv[1:]:
    im=Image.open(p).convert("RGBA"); w,h=im.size
    cols={}
    print(p, im.size)
    for y in range(h):
        row=""
        for x in range(w):
            c=im.getpixel((x,y))
            if c[3]==0: row+="."; continue
            if c not in cols: cols[c]=chr(ord('a')+len(cols))
            row+=cols[c]
        print(f"{y:2d} {row}")
    print(cols)
