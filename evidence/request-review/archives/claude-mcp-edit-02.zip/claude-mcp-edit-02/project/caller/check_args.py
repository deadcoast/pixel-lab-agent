import json,base64,hashlib,sys
a=json.load(open(sys.argv[1]))
s=json.load(open("provider-schemas.json"))["edit_image_pro_flash"]
print("keys",sorted(a), "extra", set(a)-set(s["properties"]))
for k,v in a.items():
    if k in("image_base64",): print(k, hashlib.sha256(base64.b64decode(v)).hexdigest())
    elif k=="reference_image":
        print(k, {kk:(hashlib.sha256(base64.b64decode(vv)).hexdigest() if kk=="base64" else vv) for kk,vv in v.items()})
    else: print(k, repr(v))
r=json.load(open(sys.argv[2])); print("request.json keys", list(r))
print("args equal in request.json:", any(v==a for v in r.values()) or r.get("arguments")==a)
