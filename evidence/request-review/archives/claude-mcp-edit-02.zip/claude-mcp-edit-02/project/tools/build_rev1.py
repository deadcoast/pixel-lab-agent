"""Build PX2 revision 1 (plan + criteria) for the robot repair; writes JSON host-adapter candidate."""
import hashlib, json, subprocess, sys
ROOT = sys.argv[1]; OUT = sys.argv[2]
def sha(p): return hashlib.sha256(open(f"{ROOT}/{p}", "rb").read()).hexdigest()
ref = lambda i: {"$ref": i}; sym = lambda s: {"$symbol": s}
AT = "2026-11-08"
def S(i, path, ln, au="local"):
    return {"id": i, "kind": "S", "fields": {"ur": path, "dg": sha(path), "ln": ln, "at": AT, "au": sym(au)}}
PAL = ["#25354a", "#56b5bc", "#f4dda2"]
recs = [
 {"id": "actor", "kind": "A", "fields": {"nm": "PIXL", "rl": sym("agent")}},
 {"id": "user", "kind": "A", "fields": {"nm": "Project owner", "rl": sym("user")}},
 S("s_owner", "OWNER.md", [1, 14]),
 S("s_assignment", "AGENTS.md", [1, 9]),
 S("s_consumer", "src/avatar.ts", [1, 1]),
 S("s_input", "input.png", []),
 S("s_reference", "reference.png", []),
 S("s_schemas", "provider-schemas.json", []),
 S("s_declarations", "official-tool-declarations.json", []),
 S("s_measure", "evidence/fixture-measurements.json", []),
]
def I(i, ky, st, vl, so, wy, wh="user"):
    return {"id": i, "kind": "I", "fields": {"pr": ref("project"), "wh": ref(wh), "ky": ky, "st": sym(st), "vl": vl, "so": [ref(s) for s in so], "wy": wy}}
choices = [
 I("i_px", "px", "confirmed", [32, 32], ["s_owner", "s_consumer"], "OWNER.md line 4 preserves the 32x32 canvas; src/avatar.ts declares width 32, height 32."),
 I("i_al", "al", "confirmed", sym("binary"), ["s_owner"], "OWNER.md line 4: binary transparency."),
 I("i_pl", "pl", "confirmed", PAL, ["s_owner", "s_reference", "s_measure"], "OWNER.md line 4 requires the reference palette; its exact visible colors are measured from reference.png in evidence/fixture-measurements.json (transparent background excluded)."),
 I("i_sa", "sa", "confirmed", sym("nearest"), ["s_consumer"], "src/avatar.ts sampling: nearest."),
 I("i_li", "li", "confirmed", "flat as reference; no ground shadow", ["s_owner"], "OWNER.md line 4: no ground shadow. Flat treatment follows the supplied reference."),
 I("i_vw", "vw", "proposed", sym("ui"), [], "Specialist interpretation: the C view enum has no 'front' value; a front-facing avatar portrait consumed by UI code (src/avatar.ts) maps best to ui. Front-facing itself is an owner requirement held in i_identity.", wh="actor"),
 I("i_identity", "identity", "confirmed", "same robot as reference.png: front-facing teal body, dark outline, two antennae, two yellow eyes", ["s_owner", "s_reference"], "OWNER.md lines 2-3 and 7-8; reference.png is the approved identity reference."),
 I("i_dest", "destination", "confirmed", "assets/robot.png", ["s_owner", "s_consumer"], "OWNER.md line 5 and src/avatar.ts path."),
]
recs += choices
recs.append({"id": "project", "kind": "P", "fields": {"nm": "robot-avatar-repair", "ow": ref("user"), "sc": [ref(s) for s in ["s_owner", "s_assignment", "s_consumer", "s_input", "s_reference", "s_schemas", "s_declarations", "s_measure"]], "in": [ref(c["id"]) for c in choices], "br": open(f"{ROOT}/OWNER.md", encoding="utf-8", newline="").read()}})
recs.append({"id": "c_robot", "kind": "C", "fields": {"nm": "32x32 robot avatar, reference palette, binary alpha", "px": [32, 32], "pl": PAL, "vw": sym("ui"), "sa": sym("nearest"), "al": sym("binary"), "li": "flat as reference; no ground shadow", "ch": [ref(c["id"]) for c in choices]}})
recs.append({"id": "x_input", "kind": "X", "fields": {"nm": "input.png content to edit (first image)", "ur": "input.png", "dg": sha("input.png"), "kd": sym("reference")}})
recs.append({"id": "x_reference", "kind": "X", "fields": {"nm": "reference.png approved identity reference", "ur": "reference.png", "dg": sha("reference.png"), "kd": sym("reference")}})
def Q(i, nm, dm, md, ck, so, wh="user"):
    return {"id": i, "kind": "Q", "fields": {"nm": nm, "dm": sym(dm), "md": sym(md), "ck": ck, "wh": ref(wh), "so": [ref(s) for s in so]}}
qs = [
 Q("q_canvas", "canvas", "mechanical", "local", "The candidate PNG decodes as exactly one 32x32 frame (unchanged native canvas).", ["s_owner", "s_consumer"]),
 Q("q_alpha", "binary alpha", "mechanical", "local", "Every pixel has alpha 0 or 255; no fractional alpha.", ["s_owner"]),
 Q("q_palette", "reference palette", "mechanical", "local", "Every visible pixel is one of the reference palette colors #25354a, #56b5bc, #f4dda2. Using a subset is not itself a failure; identity criteria judge required features.", ["s_owner", "s_reference", "s_measure"]),
 Q("q_identity", "reference identity restored", "visual", "visual", "Viewed at native and nearest-enlarged scale beside reference.png and input.png, the candidate reads as the same robot as reference.png: two antennae and two yellow eyes are present, and the front-facing teal body with dark outline is preserved.", ["s_owner", "s_reference", "s_input"]),
 Q("q_no_shadow", "no ground shadow", "visual", "visual", "No ground shadow or added cast-shadow shape appears under or around the robot.", ["s_owner"]),
 Q("q_provenance", "provider-produced, not reference copy", "mechanical", "local", "The candidate bytes are the pixellab-test edit job's own downloaded result imported through job-import for this job, and its sha256 differs from reference.png (d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7).", ["s_assignment", "s_owner"]),
 Q("q_integration", "consumer path integration", "other", "local", "assets/robot.png exists, is byte-identical to the accepted candidate, and src/avatar.ts path 'assets/robot.png' with width 32, height 32, sampling 'nearest' resolves to that file.", ["s_owner", "s_consumer"]),
]
recs += qs
recs.append({"id": "f_robot", "kind": "F", "fields": {"tk": ref("t_robot"), "nm": "assets/robot.png repaired robot avatar", "kd": sym("sprite"), "rq": [ref(q["id"]) for q in qs], "ct": ref("c_robot")}})
recs.append({"id": "t_robot", "kind": "T", "fields": {"nm": "Repair input.png to the approved reference identity with one Pro Flash reference edit", "ow": ref("actor"), "pr": ref("project"), "dp": [], "dc": [], "kn": [], "st": sym("open"), "ph": sym("sample"), "ip": [ref("x_input"), ref("x_reference")], "op": [ref("f_robot")], "ca": [], "vr": []}})
json.dump({"format": 2, "revision": 1, "records": sorted(recs, key=lambda r: r["id"])}, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
