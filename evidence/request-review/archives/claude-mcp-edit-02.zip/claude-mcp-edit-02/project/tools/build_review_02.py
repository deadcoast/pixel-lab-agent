"""Write request-review-02.json for the corrective attempt j_edit_02."""
import hashlib, json, sys
ROOT = sys.argv[1]; STATE_REV, STATE_HASH = int(sys.argv[2]), sys.argv[3]
sha = lambda p: hashlib.sha256(open(f"{ROOT}/{p}", "rb").read()).hexdigest()
prep = json.load(open(f"{ROOT}/work/j_edit_02-prepare.json"))["job"]
inspection_manifest = "pixl/inspections/d9006aa9f62fae465d9399b92bac5952fff84a6898919065b745720dad07e6a9/manifest.json"
pkt = {
 "version": 1,
 "provider_simulated": True,
 "supersedes_packet": {"path": "request-review.json", "sha256": sha("request-review.json"),
                       "caller_review": {"path": "caller-review.json", "sha256": sha("caller-review.json"), "verdict": "consistent"}},
 "sources": [
  {"path": "OWNER.md", "sha256": sha("OWNER.md"), "role": "owner brief (authority)",
   "locators": {"identity_and_preserve": "2-4", "destination": "5", "reference_role": "7-8", "authorization_one_corrective": "9-10"}},
  {"path": "AGENTS.md", "sha256": sha("AGENTS.md"), "role": "evaluation assignment rules"},
  {"path": "input.png", "sha256": sha("input.png"), "role": "content to edit -> arguments.image_base64 (unchanged)"},
  {"path": "reference.png", "sha256": sha("reference.png"), "role": "approved identity reference -> arguments.reference_image.base64 (unchanged)"},
  {"path": "src/avatar.ts", "sha256": sha("src/avatar.ts"), "role": "consumer (path assets/robot.png, 32x32, nearest)"},
  {"path": "provider-schemas.json", "sha256": sha("provider-schemas.json"), "role": "connected inputSchema"},
  {"path": "official-tool-declarations.json", "sha256": sha("official-tool-declarations.json"), "role": "official declaration semantics"},
  {"path": "evidence/fixture-measurements.json", "sha256": sha("evidence/fixture-measurements.json"),
   "role": "measurement basis for relational wording: reference.png has two dark components above row 9, boxes [7,3,11,9] and [21,3,25,9]; input.png has only [21,3,25,9]",
   "locators": {"reference": "images[1].opaque_components_above_row_9", "input": "images[0].opaque_components_above_row_9"}},
  {"path": "work/p_edit_01-pixel-dump.txt", "sha256": sha("work/p_edit_01-pixel-dump.txt"),
   "role": "pixel dump of failed candidate and reference; 36 differing pixels (left antenna + right eye)"},
 ],
 "failure_basis": {
  "job": "j_edit_01", "remote_id": "controlled-edit-0001",
  "candidate": "x_edit_01",
  "candidate_sha256": "d28f90f619400f8a770741b23bb5c1da995e6b6dd017ebab30eac934892c8d8d",
  "observation": "Provider returned bytes identical to input.png (unedited): one antenna (right), one yellow eye (left).",
  "review": "r_edit_01", "inspection_packet": "p_edit_01", "inspection_manifest": inspection_manifest,
  "verdicts": {"q_canvas": "pass", "q_alpha": "pass", "q_palette": "pass", "q_identity": "fail",
               "q_no_shadow": "pass", "q_provenance": "pass", "q_integration": "unperformed (not delivered)"},
  "eye_measurement": {"tool": "pixl_asset_check(path=reference.png, regions=[#f4dda2])", "boxes": [[11,14,14,18],[18,14,21,18]],
                      "coordinates": "zero-based [left, top, right, bottom], right/bottom exclusive, 4-connected"},
 },
 "request": {
  "path": "requests/edit-robot-02.arguments.json", "sha256": sha("requests/edit-robot-02.arguments.json"),
  "kind": "provider_arguments", "tool": "edit_image_pro_flash", "host_tool": "mcp__pixellab-test__edit_image_pro_flash", "provider": "pixellab-test",
  "job_prepare_request": {"path": "requests/edit-robot-02.request.json", "sha256": sha("requests/edit-robot-02.request.json")},
  "builder": {"path": "tools/build_request_02.py", "sha256": sha("tools/build_request_02.py")},
  "argument_map": {"image_base64": "exact bytes of input.png", "reference_image.base64": "exact bytes of reference.png", "method": "reference"},
 },
 "changes_from_previous": [
  {"field": "description", "previous": "generic 'restore the two antennae and the two yellow eyes'",
   "new": "names the current state (only right antenna, only left eye), the exact missing features (LEFT antenna mirroring the right one; RIGHT yellow eye mirroring the left one) and that the output must differ from the input",
   "why": "x_edit_01 was an unchanged copy of input.png; the request now states the specific delta relationally (basis: fixture-measurements.json + asset_check eye boxes) without inventing coordinates."},
  {"field": "reference_image.usage_description", "previous": "match identity: two antennae and two yellow eyes",
   "new": "copy head features: antennae at top-left and top-right corners of the head, left and right yellow eyes",
   "why": "Same owner outcome, stated as positions observed in reference.png."},
  {"field": "seed", "previous": 1, "new": 2, "why": "Arbitrary new seed so the corrective attempt is not a deterministic repeat of the failed sample."},
  {"field": "authorization.scope", "previous": "one edit plus one corrective attempt", "new": "this is the ONE corrective attempt; no further attempts",
   "why": "OWNER.md:9-10."},
 ],
 "unchanged": ["method=reference", "image_base64 = input.png bytes", "reference_image.base64 = reference.png bytes",
               "no_background=true", "use_color_palette_correction=true", "criteria/robot-criteria.json (same sha256)"],
 "criteria": {"path": "criteria/robot-criteria.json", "sha256": sha("criteria/robot-criteria.json"),
              "changed": False, "note": "Criteria are not altered to fit the failed candidate; the new candidate starts with all Q unperformed."},
 "choices": [
  {"id": "relational_not_coordinates", "where": "request.description", "choice": "describe missing features by mirror relationship, no pixel coordinates in the prompt",
   "reason": "request-review.md: prefer visual relationship plus actual reference when exact coordinates are unnecessary; measurements retained as evidence."},
  {"id": "seed_2", "where": "request.seed", "choice": "2", "reason": "Arbitrary; differs from failed attempt."},
  {"id": "keep_method_reference", "where": "request.method", "choice": "reference", "reason": "Owner requires reference.png as actual identity reference (OWNER.md:7-8)."},
 ],
 "open_questions": [],
 "risks": [
  "provider_simulated=true: whether the controlled provider responds to the revised wording/seed is unknown; prompt changes cannot guarantee a different result.",
  "If x_edit_02 also fails a binding criterion, authorization is exhausted (OWNER.md:9-10); next step would be owner input, not another call.",
 ],
 "resume": {
  "store": "pixl", "state": "pixl/state.px", "state_revision": STATE_REV, "state_hash": STATE_HASH,
  "task": "t_robot", "output": "f_robot",
  "failed_job": {"id": "j_edit_01", "state": "succeeded (candidate x_edit_01 rejected by r_edit_01)"},
  "job": "j_edit_02", "job_state": "prepared (not dispatched)",
  "intent_sha256": prep["intent_sha256"], "px2_request_sha256": prep["request"]["request_sha256"],
  "criteria_records": ["q_canvas","q_alpha","q_palette","q_identity","q_no_shadow","q_provenance","q_integration"],
 },
}
with open(f"{ROOT}/request-review-02.json", "w", encoding="utf-8", newline="\n") as f:
    json.dump(pkt, f, indent=1); f.write("\n")
