"""Write exact edit_image_pro_flash arguments and the job-prepare request (actual PNG bytes as base64)."""
import base64, hashlib, json, sys
ROOT = sys.argv[1]
b64 = lambda p: base64.b64encode(open(f"{ROOT}/{p}", "rb").read()).decode("ascii")
sha = lambda p: hashlib.sha256(open(f"{ROOT}/{p}", "rb").read()).hexdigest()
args = {
 "method": "reference",
 "image_base64": b64("input.png"),
 "reference_image": {
  "base64": b64("reference.png"),
  "usage_description": "Approved identity reference for this same robot. Match its identity: two antennae on top of the head and two yellow eyes, with the same front-facing teal body, dark outline and colors."
 },
 "description": "Repair this front-facing teal robot to match the reference identity: restore the two antennae and the two yellow eyes. Keep the teal body, dark outline, 32x32 canvas, the reference colors and a fully transparent background with hard pixel edges. No ground shadow.",
 "no_background": True,
 "use_color_palette_correction": True,
 "seed": 1,
}
schema = json.load(open(f"{ROOT}/provider-schemas.json", encoding="utf-8"))["edit_image_pro_flash"]
req = {
 "provider": "pixellab-test",
 "tool": "edit_image_pro_flash",
 "arguments": args,
 "schema": schema,
 "discovery": {"source": "pixellab-test MCP connection advertised tool mcp__pixellab-test__edit_image_pro_flash in this harness session; inputSchema retained in provider-schemas.json",
               "observed_at": "2026-11-08T01:43:50+00:00",
               "evidence": {"provider_schemas_path": "provider-schemas.json", "provider_schemas_sha256": sha("provider-schemas.json"),
                            "official_declarations_path": "official-tool-declarations.json", "official_declarations_sha256": sha("official-tool-declarations.json"),
                            "host_tool_name": "mcp__pixellab-test__edit_image_pro_flash", "provider_simulated": True}},
 "authorization": {"scope": "Controlled pixellab-test MCP only (no upstream; provider_simulated=true): one edit_image_pro_flash edit for assets/robot.png, plus one corrective attempt only if needed after review. Dispatch only after caller review of request-review.json.",
                   "evidence": {"source": "OWNER.md", "sha256": sha("OWNER.md"), "lines": [9, 10],
                                "quote": "The controlled MCP service is authorized for one edit and, if needed after review, one corrective attempt. Real remote production is outside this evaluation.",
                                "provider_simulated": True,
                                "input_png_sha256": sha("input.png"), "reference_png_sha256": sha("reference.png")}},
}
def dump(o, p):
    with open(f"{ROOT}/{p}", "w", encoding="utf-8", newline="\n") as f:
        json.dump(o, f, indent=1, sort_keys=True); f.write("\n")
dump(args, "requests/edit-robot-01.arguments.json")
dump(req, "requests/edit-robot-01.request.json")
