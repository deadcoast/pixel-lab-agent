"""Write corrective edit_image_pro_flash arguments (j_edit_02) and job-prepare request.

Changes from edit-robot-01 (see request-review-02.json): description and usage_description
name the exact missing features relative to the ones already present (mirror of the existing
right antenna / left eye) and state that an unchanged copy of the input is not acceptable;
seed 1 -> 2. Image bytes, method, no_background and palette correction are unchanged.
"""
import base64, hashlib, json, sys
ROOT = sys.argv[1]
b64 = lambda p: base64.b64encode(open(f"{ROOT}/{p}", "rb").read()).decode("ascii")
sha = lambda p: hashlib.sha256(open(f"{ROOT}/{p}", "rb").read()).hexdigest()
args = {
 "method": "reference",
 "image_base64": b64("input.png"),
 "reference_image": {
  "base64": b64("reference.png"),
  "usage_description": "Approved identity reference for this same robot. Copy its head features: it has TWO antennae (one at the top-left corner and one at the top-right corner of the head) and TWO yellow eyes (left and right). Keep the same front-facing teal body, dark outline and colors.",
 },
 "description": "Edit this front-facing teal robot so it matches the reference. It currently has only the right antenna and only the left yellow eye. Add the missing LEFT antenna (a dark vertical bar at the top-left of the head, mirroring the existing right antenna) and the missing RIGHT yellow eye (mirroring the existing left eye). The output must differ from the input. Keep the teal body, dark outline, 32x32 canvas, reference colors and a fully transparent background with hard pixel edges. No ground shadow.",
 "no_background": True,
 "use_color_palette_correction": True,
 "seed": 2,
}
schema = json.load(open(f"{ROOT}/provider-schemas.json", encoding="utf-8"))["edit_image_pro_flash"]
req = {
 "provider": "pixellab-test",
 "tool": "edit_image_pro_flash",
 "arguments": args,
 "schema": schema,
 "discovery": {"source": "pixellab-test MCP connection advertised tool mcp__pixellab-test__edit_image_pro_flash in this harness session; inputSchema retained in provider-schemas.json",
               "observed_at": "2026-11-08T01:43:50+00:00",
               "evidence": {"provider_schemas_path": "provider-schemas.json", "provider_schemas_sha256": sha("provider-schemas.json"),
                            "official_declarations_path": "official-tool-declarations.json", "official_declarations_sha256": sha("official-tool-declarations.json"),
                            "host_tool_name": "mcp__pixellab-test__edit_image_pro_flash", "provider_simulated": True}},
 "authorization": {"scope": "Controlled pixellab-test MCP only (no upstream; provider_simulated=true): the ONE corrective edit_image_pro_flash attempt for assets/robot.png after j_edit_01 candidate x_edit_01 failed review r_edit_01 (q_identity). Dispatch only after caller review of request-review-02.json. No further attempts authorized.",
                   "evidence": {"source": "OWNER.md", "sha256": sha("OWNER.md"), "lines": [9, 10],
                                "quote": "The controlled MCP service is authorized for one edit and, if needed after review, one corrective attempt. Real remote production is outside this evaluation.",
                                "failed_review": "r_edit_01", "failed_candidate": "x_edit_01", "failed_criterion": "q_identity",
                                "provider_simulated": True,
                                "input_png_sha256": sha("input.png"), "reference_png_sha256": sha("reference.png")}},
}
def dump(o, p):
    with open(f"{ROOT}/{p}", "w", encoding="utf-8", newline="\n") as f:
        json.dump(o, f, indent=1, sort_keys=True); f.write("\n")
dump(args, "requests/edit-robot-02.arguments.json")
dump(req, "requests/edit-robot-02.request.json")
