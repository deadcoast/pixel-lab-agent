"""Reproducible measurement of the input/reference fixtures (specialist observation, not a rule).

Coordinates: zero-based, boxes [left, top, right, bottom] with exclusive right/bottom, 4-connectivity.
Usage: python -I tools/measure_fixtures.py input.png reference.png > evidence/fixture-measurements.json
"""
import hashlib, json, sys
from collections import Counter
from PIL import Image

HEAD_TOP_ROW = 9  # first row of the full-width dark head band in both fixtures (see row_runs)

def components(points):
    pts, out = set(points), []
    while pts:
        stack = [pts.pop()]; comp = list(stack)
        while stack:
            x, y = stack.pop()
            for n in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                if n in pts:
                    pts.remove(n); stack.append(n); comp.append(n)
        xs = [p[0] for p in comp]; ys = [p[1] for p in comp]
        out.append({"pixels": len(comp), "box": [min(xs), min(ys), max(xs)+1, max(ys)+1]})
    return sorted(out, key=lambda c: c["box"])

def measure(path):
    raw = open(path, "rb").read()
    im = Image.open(path).convert("RGBA"); w, h = im.size
    px = {(x, y): im.getpixel((x, y)) for y in range(h) for x in range(w)}
    hexc = lambda c: "#%02x%02x%02x%02x" % c
    opaque = [p for p, c in px.items() if c[3] != 0]
    above = [p for p in opaque if p[1] < HEAD_TOP_ROW]
    by_color = {}
    for p in opaque:
        by_color.setdefault(hexc(px[p]), []).append(p)
    return {
        "path": path, "sha256": hashlib.sha256(raw).hexdigest(), "size": [w, h],
        "alpha_values": sorted({c[3] for c in px.values()}),
        "colors": dict(sorted(Counter(hexc(c) for c in px.values()).items())),
        "color_components": {k: components(v) for k, v in sorted(by_color.items())},
        "opaque_components_above_row_%d" % HEAD_TOP_ROW: components(above),
        "row_runs": {y: [[x0, x1] for x0, x1 in runs(px, w, y)] for y in range(h) if any(px[(x, y)][3] for x in range(w))},
    }

def runs(px, w, y):
    x = 0
    while x < w:
        if px[(x, y)][3]:
            s = x
            while x < w and px[(x, y)][3]: x += 1
            yield s, x
        else:
            x += 1

print(json.dumps({"convention": "zero-based; boxes [left,top,right,bottom], right/bottom exclusive; 4-connected; runs [start,end) per row",
                  "images": [measure(p) for p in sys.argv[1:]]}, indent=1))
