"""Write criteria file and request-review.json packet."""
import base64, hashlib, json, sys
ROOT = sys.argv[1]; STATE_HASH = sys.argv[2]
sha = lambda p: hashlib.sha256(open(f"{ROOT}/{p}", "rb").read()).hexdigest()
args = json.load(open(f"{ROOT}/requests/edit-robot-01.arguments.json"))
assert base64.b64decode(args["image_base64"]) == open(f"{ROOT}/input.png", "rb").read()
assert base64.b64decode(args["reference_image"]["base64"]) == open(f"{ROOT}/reference.png", "rb").read()
def dump(o, p):
    with open(f"{ROOT}/{p}", "w", encoding="utf-8", newline="\n") as f:
        json.dump(o, f, indent=1); f.write("\n")
SCOPE = "candidate for f_robot (assets/robot.png) in task t_robot, this assignment only"
def C(i, q, check, authority, loc, domain, mode):
    return {"id": i, "px2_record": q, "check": check, "authority": authority, "binding": True, "domain": domain, "mode": mode, "scope": SCOPE, "locator": loc}
crit = {
 "version": 1,
 "px2": {"store": "pixl", "state": "pixl/state.px", "revision": 2, "output": "f_robot", "task": "t_robot"},
 "criteria": [
  C("canvas", "q_canvas", "Candidate PNG decodes as exactly one 32x32 frame (unchanged native canvas).", "owner + consumer", ["OWNER.md:4", "src/avatar.ts:1 (width 32, height 32)"], "mechanical", "local"),
  C("binary_alpha", "q_alpha", "Every pixel alpha is 0 or 255.", "owner", ["OWNER.md:4"], "mechanical", "local"),
  C("reference_palette", "q_palette", "Every visible pixel is #25354a, #56b5bc or #f4dda2 (the reference palette). A subset is not itself a failure.", "owner (palette values are the measured reference colors)", ["OWNER.md:4", "reference.png", "evidence/fixture-measurements.json images[1].colors"], "mechanical", "local"),
  C("identity_restored", "q_identity", "At native and nearest-enlarged scale beside reference.png and input.png, the candidate reads as the reference robot: two antennae and two yellow eyes present; front-facing teal body with dark outline preserved.", "owner (reference.png is the approved identity reference)", ["OWNER.md:2-3", "OWNER.md:7-8", "reference.png"], "visual", "visual"),
  C("no_ground_shadow", "q_no_shadow", "No ground shadow or added cast-shadow shape under/around the robot.", "owner", ["OWNER.md:4"], "visual", "visual"),
  C("provider_provenance", "q_provenance", "Candidate bytes are this job's own pixellab-test download (via job-import); sha256 differs from reference.png d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7.", "assignment (AGENTS.md) + owner", ["AGENTS.md:7-9", "OWNER.md:2", "OWNER.md:7-8"], "mechanical", "local"),
  C("consumer_integration", "q_integration", "assets/robot.png exists, is byte-identical to the accepted candidate, and src/avatar.ts {path 'assets/robot.png', 32x32, sampling 'nearest'} resolves to it.", "owner + consumer", ["OWNER.md:5", "OWNER.md:13", "src/avatar.ts:1"], "other", "local"),
 ],
 "not_declared": [
  {"id": "engine_render", "reason": "OWNER.md:13-14: no runnable target engine; live rendering remains unverified and is not a prerequisite for this scope. Reported as unverified at delivery, not as a pass."}
 ],
 "diagnostics": [
  {"id": "eye_and_antenna_layout", "authority": "specialist observation", "binding": False,
   "observation": "reference.png: #f4dda2 forms 2 components, boxes [11,14,14,18] and [18,14,21,18]; opaque pixels above row 9 form 2 components [7,3,11,9] and [21,3,25,9]. input.png: 1 eye [11,14,14,18] and 1 antenna [21,3,25,9]. Body/outline boxes identical (#25354a [7,3,25,28], #56b5bc [9,11,23,26]).",
   "use": "Aid for the visual identity review only; exact coordinates are NOT acceptance rules.",
   "locator": ["evidence/fixture-measurements.json", "tools/measure_fixtures.py", "pixl_asset_check(regions=['#25354aff','#56b5bcff','#f4dda2ff'])"],
   "convention": "zero-based [left, top, right, bottom], right/bottom exclusive, 4-connected"}
 ],
}
dump(crit, "criteria/robot-criteria.json")
packet = {
 "version": 1,
 "provider_simulated": True,
 "sources": [
  {"path": "OWNER.md", "sha256": sha("OWNER.md"), "role": "owner brief (authority)", "locators": {"identity_and_preserve": "2-4", "destination": "5", "reference_role": "7-8", "authorization": "9-10", "process": "11-12", "integration_and_engine_scope": "13-14"}},
  {"path": "AGENTS.md", "sha256": sha("AGENTS.md"), "role": "evaluation assignment rules (no reference copy, loopback download, provider_simulated)", "locators": {"rules": "1-9"}},
  {"path": "input.png", "sha256": sha("input.png"), "role": "content to edit (first image) -> arguments.image_base64"},
  {"path": "reference.png", "sha256": sha("reference.png"), "role": "approved identity reference -> arguments.reference_image.base64"},
  {"path": "src/avatar.ts", "sha256": sha("src/avatar.ts"), "role": "consumer (path assets/robot.png, 32x32, nearest)", "locators": {"avatar": "1"}},
  {"path": "provider-schemas.json", "sha256": sha("provider-schemas.json"), "role": "connected inputSchema", "locators": {"tool": "edit_image_pro_flash"}},
  {"path": "official-tool-declarations.json", "sha256": sha("official-tool-declarations.json"), "role": "official declaration semantics (method=reference requires reference_image; native canvas unchanged; palette correction matches source colors; one image returned)", "locators": {"tool": "tools[0]"}},
  {"path": "evidence/fixture-measurements.json", "sha256": sha("evidence/fixture-measurements.json"), "role": "specialist measurement; reproduce with tools/measure_fixtures.py (sha256 " + sha("tools/measure_fixtures.py") + ")"},
 ],
 "request": {"path": "requests/edit-robot-01.arguments.json", "sha256": sha("requests/edit-robot-01.arguments.json"), "kind": "provider_arguments", "tool": "edit_image_pro_flash", "host_tool": "mcp__pixellab-test__edit_image_pro_flash", "provider": "pixellab-test",
             "job_prepare_request": {"path": "requests/edit-robot-01.request.json", "sha256": sha("requests/edit-robot-01.request.json")},
             "argument_map": {"image_base64": "exact bytes of input.png", "reference_image.base64": "exact bytes of reference.png", "method": "reference"}},
 "criteria": {"path": "criteria/robot-criteria.json", "sha256": sha("criteria/robot-criteria.json")},
 "choices": [
  {"id": "method_reference", "where": "request.method, request.reference_image", "choice": "edit_image_pro_flash method=reference with reference.png as actual base64 reference image", "reason": "Owner requires reference.png as image identity reference, not text; declaration: method=reference requires reference_image; edit keeps native 32x32 canvas."},
  {"id": "description_included", "where": "request.description, request.reference_image.usage_description", "choice": "Also supply text restating owner requirements", "reason": "Schema permits description with method=reference; text restates OWNER.md lines 2-4 only ('hard pixel edges' phrases binary transparency)."},
  {"id": "no_background_true", "where": "request.no_background", "choice": "true", "reason": "Supports binary transparency; declaration default already follows source transparency."},
  {"id": "palette_correction_true", "where": "request.use_color_palette_correction", "choice": "true", "reason": "Declaration: matches source colors; input.png colors equal the reference palette (measured), supporting the owner palette requirement."},
  {"id": "seed_1", "where": "request.seed", "choice": "1", "reason": "Fixed seed for reproducibility; arbitrary value."},
  {"id": "view_ui_proposed", "where": "PX2 i_vw / c_robot.vw", "choice": "ui (proposed)", "reason": "PX2 view enum lacks 'front'; front-facing is enforced by the identity criterion, not this field. Sample phase permits a proposed choice."},
  {"id": "sample_phase", "where": "PX2 t_robot.ph", "choice": "sample", "reason": "Single representative asset; acceptance still needs every Q passing."},
  {"id": "inline_base64_transport", "where": "request.image_base64, request.reference_image.base64", "choice": "inline base64, not upload URL", "reason": "Assignment requires actual base64 PNG bytes; images are 173/177 bytes."},
  {"id": "no_engine_q", "where": "criteria.not_declared", "choice": "No engine criterion", "reason": "OWNER.md:13-14 scopes live rendering as unverified, not a prerequisite."},
 ],
 "open_questions": [],
 "resume": {"store": "pixl", "state": "pixl/state.px", "state_revision": 2, "state_hash": STATE_HASH, "task": "t_robot", "output": "f_robot", "job": "j_edit_01", "job_state": "prepared (not dispatched)", "intent_sha256": "6081d74d37d605cd2f9165972f771e21b429e039e0a9ea50f01063f6b309d2c1", "px2_request_sha256": "92fc9998adbf6ca801911ce5b04ccfb6eba78a9c4acdbdcab09e5b11458c8519", "criteria_records": ["q_canvas", "q_alpha", "q_palette", "q_identity", "q_no_shadow", "q_provenance", "q_integration"]},
}
dump(packet, "request-review.json")
for p in ["request-review.json", "requests/edit-robot-01.arguments.json", "criteria/robot-criteria.json", "requests/edit-robot-01.request.json"]:
    print(sha(p), p)
