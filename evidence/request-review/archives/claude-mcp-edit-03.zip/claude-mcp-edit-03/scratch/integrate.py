import json, sys
src, out, at, dg = sys.argv[1:5]
d = json.load(open(src))
d['revision'] += 1
recs = {r['id']: r for r in d['records']}
bs = [b for b in recs['rev_edit_robot_2.evidence.5']['fields']['bs']
      if not b['rf']['$ref'].startswith(('insp_', 'rev_'))]
d['records'].append({"id": "integ_x_edit_robot_2.evidence", "kind": "E", "fields": {
  "nm": "q_integration destination check: assets/robot.png bytes equal nominated x_edit_robot_2, 32x32 as declared by src/avatar.ts",
  "ur": "evidence/integration/q_integration-x_edit_robot_2.json", "dg": dg,
  "rs": {"$symbol": "pass"}, "md": {"$symbol": "local"}, "at": at, "bs": bs}})
d['records'].append({"id": "integ_x_edit_robot_2.verdict", "kind": "V", "fields": {
  "tk": {"$ref": "repair_robot"}, "rq": {"$ref": "q_integration"}, "xr": {"$ref": "x_edit_robot_2"},
  "st": {"$symbol": "pass"}, "wh": {"$ref": "actor"}, "at": at,
  "wy": "assets/robot.png exists at the path src/avatar.ts declares (path assets/robot.png, width 32, height 32); sha256 d997cade... equals nominated x_edit_robot_2 artifact; measured 32x32 single-frame RGBA PNG (Pillow and pixl asset-check). Live engine rendering unverified (not in scope per brief).",
  "ev": [{"$ref": "integ_x_edit_robot_2.evidence"}]}})
t = recs['repair_robot']['fields']
t['vr'].append({"$ref": "integ_x_edit_robot_2.verdict"})
t['st'] = {"$symbol": "done"}
json.dump(d, open(out, 'w'), indent=1)
print(d['revision'], len(bs))
