import sys, urllib.request, hashlib, datetime
url, out = sys.argv[1], sys.argv[2]
with urllib.request.urlopen(url, timeout=30) as r:
    data = r.read(); status = r.status; ct = r.headers.get('Content-Type')
open(out, 'xb').write(data)
print(status, ct, len(data), hashlib.sha256(data).hexdigest(), datetime.datetime.now(datetime.timezone.utc).isoformat())
