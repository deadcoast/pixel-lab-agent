import json, sys
src, out = sys.argv[1], sys.argv[2]
d = json.load(open(src))
d['revision'] += 1
for r in d['records']:
    if r['id'] == 'repair_robot':
        r['fields']['ca'] = [{'$ref': 'x_edit_robot_2'}]
json.dump(d, open(out, 'w'), indent=1)
print(d['revision'])
