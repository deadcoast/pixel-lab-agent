import json, sys, hashlib, shutil, os, re, datetime
from PIL import Image
root = sys.argv[1]
src = os.path.join(root, '.pixl/artifacts/d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7.png')
ts = open(os.path.join(root, 'src/avatar.ts'), encoding='utf-8').read()
m = re.search(r'path:\s*"([^"]+)",\s*width:\s*(\d+),\s*height:\s*(\d+)', ts)
dest_rel, w, h = m.group(1), int(m.group(2)), int(m.group(3))
dest = os.path.join(root, dest_rel)
assert not os.path.exists(dest)
H = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
assert H(src) == 'd997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7'
shutil.copyfile(src, dest)
im = Image.open(dest)
rec = {
 "criterion": "q_integration", "candidate": "x_edit_robot_2",
 "declared_by": {"path": "src/avatar.ts", "sha256": H(os.path.join(root, 'src/avatar.ts')), "parsed": {"path": dest_rel, "width": w, "height": h}},
 "delivered": {"path": dest_rel, "sha256": H(dest), "bytes": os.path.getsize(dest), "format": im.format, "mode": im.mode, "size": list(im.size), "n_frames": getattr(im, 'n_frames', 1)},
 "candidate_bytes": {"path": ".pixl/artifacts/d997cadefc6b94c1c14f4ec17159deaf5ceb7ea9543b2522390ea1a577470aa7.png", "sha256": H(src)},
 "download": {"path": "downloads/edit_robot_2/controlled-edit-0002.png", "sha256": H(os.path.join(root, 'downloads/edit_robot_2/controlled-edit-0002.png'))},
 "method": "shutil.copyfile from the retained imported candidate artifact (documented single-sample equivalent; no family plan exists)",
 "bytes_equal_candidate": H(dest) == H(src), "size_matches_declared": list(im.size) == [w, h],
 "note": "Delivered bytes equal reference.png (d997cade...) because the provider returned those bytes; reference.png itself was not copied.",
 "engine_rendering": "unverified; no engine supplied",
 "checked_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
}
rec["result"] = "pass" if rec["bytes_equal_candidate"] and rec["size_matches_declared"] and dest_rel == "assets/robot.png" else "fail"
os.makedirs(os.path.join(root, 'evidence/integration'), exist_ok=True)
out = os.path.join(root, 'evidence/integration/q_integration-x_edit_robot_2.json')
open(out, 'x').write(json.dumps(rec, indent=1, sort_keys=True))
print(json.dumps(rec), H(out))
