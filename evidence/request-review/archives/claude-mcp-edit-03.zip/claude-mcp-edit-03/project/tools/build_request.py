"""Build exact edit_image_pro_flash arguments and the job-prepare request (no provider call)."""
import base64
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(sys.argv[1])
OBSERVED = sys.argv[2]


def b64(p):
    return base64.b64encode((ROOT / p).read_bytes()).decode("ascii")


def sha(p):
    return hashlib.sha256((ROOT / p).read_bytes()).hexdigest()


arguments = {
    "method": "reference",
    "image_base64": b64("input.png"),
    "reference_image": {
        "base64": b64("reference.png"),
        "usage_description": (
            "Approved identity reference for this same robot. Match its identity: restore the two "
            "antennae on top of the head and the two yellow eyes exactly as in this reference, keeping "
            "its front-facing teal body, dark outline and colors."
        ),
    },
    "description": (
        "Repair this front-facing teal robot sprite to match the reference image: restore the two "
        "antennae and the two yellow eyes. Preserve the teal body, the dark outline, the 32x32 canvas, "
        "the existing colors and the fully transparent background. No ground shadow."
    ),
    "no_background": True,
    "use_color_palette_correction": True,
    "seed": 1,
}

schemas = json.loads((ROOT / "provider-schemas.json").read_text(encoding="utf-8"))
schema = schemas["edit_image_pro_flash"]

args_path = ROOT / "contract/edit_robot_1.arguments.json"
args_path.write_text(json.dumps(arguments, indent=2) + "\n", encoding="utf-8")

request = {
    "provider": "pixellab-test",
    "tool": "edit_image_pro_flash",
    "arguments": arguments,
    "schema": schema,
    "discovery": {
        "source": "Harness-exposed MCP tool mcp__pixellab-test__edit_image_pro_flash input schema, identical to provider-schemas.json; official declaration in official-tool-declarations.json",
        "observed_at": OBSERVED,
        "evidence": {
            "host_tool_name": "mcp__pixellab-test__edit_image_pro_flash",
            "provider_schemas_path": "provider-schemas.json",
            "provider_schemas_sha256": sha("provider-schemas.json"),
            "official_declarations_path": "official-tool-declarations.json",
            "official_declarations_sha256": sha("official-tool-declarations.json"),
            "provider_simulated": True,
            "note": "Controlled fixture connection; no upstream provider.",
        },
    },
    "authorization": {
        "scope": "pixellab-test (controlled, simulated) edit_image_pro_flash: one edit for assets/robot.png; one corrective attempt only if needed after review. No real remote production.",
        "evidence": {
            "source_path": "OWNER.md",
            "source_sha256": sha("OWNER.md"),
            "lines": [9, 10],
            "text": "The controlled MCP service is authorized for one edit and, if needed after review, one corrective attempt. Real remote production is outside this evaluation.",
            "provider_simulated": True,
        },
    },
}
req_path = ROOT / "contract/edit_robot_1.request.json"
req_path.write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")
print(args_path, sha("contract/edit_robot_1.arguments.json"))
print(req_path, sha("contract/edit_robot_1.request.json"))
