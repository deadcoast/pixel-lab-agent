"""Build PX2 revision 1 (intake choices, contract, plan, criteria) for robot repair."""
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(sys.argv[1])
base = json.loads(pathlib.Path(sys.argv[2]).read_text(encoding="utf-8"))
out = pathlib.Path(sys.argv[3])
AT = "2026-11-08T01:50:26+00:00"


def sha(p):
    return hashlib.sha256((ROOT / p).read_bytes()).hexdigest()


def ref(i):
    return {"$ref": i}


def sym(s):
    return {"$symbol": s}


recs = {r["id"]: r for r in base["records"]}


def add(i, k, f):
    recs[i] = {"id": i, "kind": k, "fields": f}


def S(i, path, ln):
    add(i, "S", {"ur": path, "dg": sha(path), "ln": ln, "at": AT, "au": sym("local")})


S("brief", "OWNER.md", [1, 14])
S("session", "SESSION.md", [1, 14])
S("avatar_ts", "src/avatar.ts", [1, 1])
S("input_png", "input.png", [])
S("reference_png", "reference.png", [])
S("meas_input", "evidence/measurements/input.asset-check.json", [])
S("meas_reference", "evidence/measurements/reference.asset-check.json", [])
S("provider_schemas", "provider-schemas.json", [])
S("official_decl", "official-tool-declarations.json", [])

PAL = ["#25354a", "#56b5bc", "#f4dda2"]


def I(i, key, st, vl, so, wy, wh="user"):
    add(i, "I", {"pr": ref("project"), "wh": ref(wh), "ky": key, "st": sym(st), "vl": vl,
                 "so": [ref(s) for s in so], "wy": wy})


I("ch_px", "px", "confirmed", [32, 32], ["brief", "avatar_ts"],
  "OWNER.md:4 requires the 32x32 canvas; src/avatar.ts declares width 32, height 32.")
I("ch_pl", "pl", "confirmed", PAL, ["brief", "reference_png", "meas_reference"],
  "OWNER.md:4 requires the reference palette; the three values are measured from reference.png (visible_colors=3).")
I("ch_al", "al", "confirmed", sym("binary"), ["brief"], "OWNER.md:4 requires binary transparency.")
I("ch_sa", "sa", "confirmed", sym("nearest"), ["avatar_ts"],
  "src/avatar.ts declares sampling 'nearest' (consumer data; rendering not verified).")
I("ch_vw", "vw", "proposed", sym("ui"), [],
  "Specialist choice: PX2 has no front-view symbol; the asset is a front-facing avatar consumed by UI code, so 'ui' is the closest category. Does not alter the owner's front-facing requirement.",
  wh="actor")
I("ch_identity", "identity", "confirmed",
  "Match the approved reference.png robot: two antennae and two yellow eyes restored; front-facing teal body and dark outline preserved.",
  ["brief", "reference_png"], "OWNER.md:2-3 and 7-8.")
I("ch_shadow", "ground_shadow", "confirmed", "none", ["brief"], "OWNER.md:4 'no ground shadow'.")
I("ch_refs", "reference_roles", "confirmed",
  "input.png = content to edit (image_base64); reference.png = approved identity reference supplied as an actual image (reference_image.base64).",
  ["brief", "input_png", "reference_png"], "OWNER.md:2 and 7-8.")
I("ch_route", "production_route", "confirmed",
  "pixellab-test edit_image_pro_flash; one edit plus at most one corrective attempt after review; provider_simulated=true.",
  ["brief", "session", "provider_schemas", "official_decl"], "OWNER.md:9-10; SESSION.md.")
I("ch_engine", "engine_verification", "confirmed",
  "live engine rendering unverified; not a prerequisite for this scope", ["brief"], "OWNER.md:13-14.")
I("ch_destination", "destination", "confirmed", "assets/robot.png", ["brief", "avatar_ts"],
  "OWNER.md:5 and src/avatar.ts path.")

choices = ["ch_px", "ch_pl", "ch_al", "ch_sa", "ch_vw", "ch_identity", "ch_shadow", "ch_refs",
           "ch_route", "ch_engine", "ch_destination"]
recs["project"]["fields"]["in"] = [ref(c) for c in choices]
recs["project"]["fields"]["sc"] = [ref("brief"), ref("avatar_ts"), ref("reference_png"), ref("input_png")]

add("robot_contract", "C", {
    "nm": "robot-avatar-32", "px": [32, 32], "pl": PAL, "vw": sym("ui"), "sa": sym("nearest"),
    "al": sym("binary"),
    "li": "Flat fills as observed in reference.png; no ground shadow (owner).",
    "ch": [ref(c) for c in ["ch_px", "ch_pl", "ch_al", "ch_sa", "ch_vw", "ch_identity", "ch_shadow"]]})

add("x_input", "X", {"nm": "input.png (content to edit)", "ur": "input.png", "dg": sha("input.png"),
                     "kd": sym("reference")})
add("x_reference", "X", {"nm": "reference.png (approved identity reference)", "ur": "reference.png",
                         "dg": sha("reference.png"), "kd": sym("reference")})

crit = json.loads((ROOT / "contract/criteria.json").read_text(encoding="utf-8"))
qsrc = {
    "q_canvas": ["brief", "avatar_ts"],
    "q_alpha": ["brief"],
    "q_palette": ["brief", "reference_png", "meas_reference"],
    "q_identity": ["brief", "reference_png", "input_png"],
    "q_no_shadow": ["brief"],
    "q_provenance": ["brief", "session"],
    "q_integration": ["brief", "avatar_ts"],
}
qids = []
for c in crit["criteria"]:
    add(c["id"], "Q", {"nm": c["id"], "dm": sym(c["domain"]), "md": sym(c["mode"]), "ck": c["check"],
                       "wh": ref("user"), "so": [ref(s) for s in qsrc[c["id"]]]})
    qids.append(c["id"])

add("robot_png", "F", {"tk": ref("repair_robot"), "nm": "assets/robot.png", "kd": sym("sprite"),
                       "rq": [ref(q) for q in qids], "ct": ref("robot_contract")})
add("repair_robot", "T", {
    "nm": "Repair input.png to match reference.png and deliver assets/robot.png",
    "ow": ref("actor"), "pr": ref("project"), "dp": [], "dc": [], "kn": [], "st": sym("open"),
    "ph": sym("sample"), "ip": [ref("x_input"), ref("x_reference")], "op": [ref("robot_png")],
    "ca": [], "vr": []})

doc = {"revision": base["revision"] + 1, "records": sorted(recs.values(), key=lambda r: r["id"]), "format": 2}
out.write_text(json.dumps(doc, indent=2), encoding="utf-8")
print(out)
