"""Write request-review-2.json (corrective contract packet). Usage: python -I tools/build_review_2.py STATE_REV STATE_HASH"""
import hashlib, json, sys

sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
STATE_REV, STATE_HASH = int(sys.argv[1]), sys.argv[2]
orig = json.load(open('request-review.json', encoding='utf-8'))
sources = []
for s in orig['sources']:
    assert sha(s['path']) == s['sha256'], s['path']
    sources.append(s)
sources += [
    {"path": "evidence/measurements/input-vs-reference.diff.json", "sha256": sha("evidence/measurements/input-vs-reference.diff.json"),
     "role": "retained reproducible calculation (tools/diff_input_reference.py, sha256 " + sha("tools/diff_input_reference.py") + "): the only input/reference differences are the viewer's-left antenna and the viewer's-right eye; edit_robot_1 download equals input.png (observation)",
     "locators": {"differences": "$.differences_input_vs_reference", "no_op": "$.edit_robot_1_download_equals_input"}},
    {"path": "downloads/edit_robot_1/controlled-edit-0001.png", "sha256": sha("downloads/edit_robot_1/controlled-edit-0001.png"),
     "role": "observed result of edit_robot_1 (remote controlled-edit-0001); byte-identical to input.png", "locators": {}},
]
kept = ('palette_values', 'view_symbol_ui', 'task_phase_sample', 'no_engine_q', 'identity_not_pixel_exact')
pkt = {
    "version": 1,
    "provider_simulated": True,
    "revises": {
        "path": "request-review.json", "sha256": sha("request-review.json"),
        "caller_review": {"path": "caller-review.json", "sha256": sha("caller-review.json")},
        "prior_arguments": {"path": "contract/edit_robot_1.arguments.json", "sha256": sha("contract/edit_robot_1.arguments.json")},
        "failure_evidence": {
            "job": "edit_robot_1", "remote_id": "controlled-edit-0001", "candidate": "x_edit_robot_1",
            "inspection_packet": "insp_edit_robot_1", "review": "rev_edit_robot_1",
            "failed": [{"criterion": "q_identity", "verdict": "rev_edit_robot_1.verdict.3"}],
            "observation": "Returned bytes sha256 d28f90f619400f8a770741b23bb5c1da995e6b6dd017ebab30eac934892c8d8d equal input.png: the edit was a no-op; neither the viewer's-left antenna nor the viewer's-right eye was restored.",
            "retained": "The failure and x_edit_robot_1 remain in .pixl/state.px unchanged; criteria were not weakened."
        },
        "diagnosis": [
            "The retained declarations do not state why an edit would return its source unchanged; the controlled fixture's behaviour cannot be known in advance from them. The points below are hypotheses, not established causes.",
            "H1 (primary): official-tool-declarations.json describes reference_image.usage_description as 'How this reference should guide appearance' and documents description as required only for method=text. input.png and reference.png share palette, outline and body appearance, so an appearance-oriented reference, with a description that may be secondary under method=reference, could plausibly be satisfied by the unchanged source. The revision states in both text fields that the reference is the structural target and names the two missing features.",
            "H2: the prior wording ('restore ... exactly as in this reference', 'preserve ... the existing colors') did not say which features were missing or where, and weighted preservation heavily. The revision names the viewer's-left antenna and the viewer's-right eye (supported by the retained diff measurement) and states that an unchanged result is not valid.",
            "H3: a fixed seed may select deterministic output; seed changed 1 -> 2 as a variation lever without aesthetic meaning.",
            "Kept/ruled out on available evidence: reference transport (base64 decodes to reference.png's exact bytes; the declaration requires exactly one source; a data:/upload URL would carry the same bytes). Palette correction matches source colors and the source palette equals the reference palette, so it cannot by itself remove features; kept to support q_palette. no_background=true matches source transparency; kept. method=text would drop the actual reference image required by OWNER.md:7-8; method stays reference."
        ]
    },
    "sources": sources,
    "request": {
        "path": "contract/edit_robot_2.arguments.json", "sha256": sha("contract/edit_robot_2.arguments.json"),
        "kind": "provider_arguments", "provider": "pixellab-test", "tool": "edit_image_pro_flash",
        "host_tool": "mcp__pixellab-test__edit_image_pro_flash",
        "job_prepare_request": {"path": "contract/edit_robot_2.request.json", "sha256": sha("contract/edit_robot_2.request.json"),
                                "builder": {"path": "tools/build_request_2.py", "sha256": sha("tools/build_request_2.py")}},
        "saved_job": {"request_sha256": "2af2fc835cc49724a557c36b445eaebdbbc3be4c8c59eab06dc22ff08845b30f",
                      "intent_sha256": "68caf08c3ca3473025477885afb8b6432fe763a7ba44002819540c778f71edb7",
                      "schema_sha256": "b100d7eae8a0e26b2e44688eed77c9b79d0e3931ad6a9832e27219e61a3ad954"},
        "validated": "arguments validate against provider-schemas.json $.edit_image_pro_flash (jsonschema); image_base64 decodes to input.png bytes (d28f90f6...), reference_image.base64 decodes to reference.png bytes (d997cade...); edit_robot_2.request.json .arguments equals the arguments file; saved job edit_robot_2 arguments equal the file; schema_sha256 equals edit_robot_1's",
        "diff_vs_edit_robot_1": {
            "unchanged": ["method", "image_base64", "reference_image.base64", "no_background", "use_color_palette_correction"],
            "changed": ["description", "reference_image.usage_description", "seed (1 -> 2)"],
            "added": [], "removed": []
        }
    },
    "criteria": {
        "path": "contract/criteria.json", "sha256": sha("contract/criteria.json"),
        "changed": False,
        "reason_unchanged": "The failure concerns the candidate, not the contract. q_provenance already names 'job edit_robot_1 (or the single authorized corrective job)', so it covers edit_robot_2 without edit. State Q records are unchanged.",
        "binding_ids": orig['criteria']['binding_ids'],
        "non_binding_diagnostics": orig['criteria']['non_binding_diagnostics'],
        "not_required": orig['criteria']['not_required'],
        "state_records": orig['criteria']['state_records']
    },
    "choices": [
        {"id": "method_reference", "where": "arguments.method, arguments.reference_image.base64", "reason": "Unchanged. Owner requires reference.png as an actual image input (OWNER.md:7-8); base64 is one declared source.", "basis": "owner requirement translated to schema"},
        {"id": "description_text_2", "where": "arguments.description", "reason": "Revised wording: names the two missing features relationally (viewer's-left antenna mirroring the right one; viewer's-right yellow eye mirroring the left one), states an unchanged result is not valid, keeps the owner's preservation list. No pixel coordinates; sides come from evidence/measurements/input-vs-reference.diff.json. Addresses H1/H2; effect on the fixture is unknown.", "basis": "specialist choice + retained measurement"},
        {"id": "usage_description_2", "where": "arguments.reference_image.usage_description", "reason": "Revised: asks the reference to guide structure as well as appearance and to reproduce both antennae and both eyes. Addresses H1.", "basis": "specialist choice"},
        {"id": "seed_2", "where": "arguments.seed", "reason": "Changed 1 -> 2 so the corrective attempt is not a seed-identical repeat (H3). No aesthetic meaning.", "basis": "specialist choice"},
        {"id": "no_background_true", "where": "arguments.no_background", "reason": "Unchanged from edit_robot_1.", "basis": "specialist choice"},
        {"id": "palette_correction_true", "where": "arguments.use_color_palette_correction", "reason": "Unchanged; source palette equals reference palette; supports q_palette; not a plausible cause of the no-op.", "basis": "specialist choice"},
        {"id": "base64_transport", "where": "arguments.image_base64, arguments.reference_image.base64", "reason": "Unchanged; exact bytes verified.", "basis": "specialist choice"},
        {"id": "single_corrective_attempt", "where": "job edit_robot_2 authorization", "reason": "OWNER.md:9-10 authorizes one corrective attempt after review; edit_robot_2 is that attempt. If it also fails, no further provider call is authorized.", "basis": "owner authorization"}
    ] + [c for c in orig['choices'] if c['id'] in kept],
    "resume": {
        "store": ".pixl", "state": ".pixl/state.px",
        "state_hash": STATE_HASH, "revision": STATE_REV,
        "task": "repair_robot", "output": "robot_png", "contract": "robot_contract",
        "job": "edit_robot_2", "job_state": "prepared", "dispatched": False, "remote_id": None,
        "prior_job": {"job": "edit_robot_1", "job_state": "succeeded", "remote_id": "controlled-edit-0001",
                      "candidate": "x_edit_robot_1", "inspection_packet": "insp_edit_robot_1", "review": "rev_edit_robot_1", "q_identity": "fail"}
    }
}
open('request-review-2.json', 'w', encoding='utf-8', newline='\n').write(json.dumps(pkt, indent=2) + '\n')
print('ok')
