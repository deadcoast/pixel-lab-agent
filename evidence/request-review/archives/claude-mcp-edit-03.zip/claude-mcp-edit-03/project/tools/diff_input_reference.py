"""Reproducible pixel difference between input.png and reference.png (and the edit_robot_1 download).
Coordinates: zero-based, boxes [left, top, right, bottom] with right/bottom exclusive.
Usage: python -I tools/diff_input_reference.py OUT_JSON"""
import hashlib, json, sys
from PIL import Image

def load(p):
    b = open(p, 'rb').read()
    return hashlib.sha256(b).hexdigest(), Image.open(p).convert('RGBA')

def hexa(px):
    return '#%02x%02x%02x%02x' % px

paths = {'input': 'input.png', 'reference': 'reference.png', 'edit_robot_1_download': 'downloads/edit_robot_1/controlled-edit-0001.png'}
imgs = {k: load(v) for k, v in paths.items()}
ia, ra = imgs['input'][1], imgs['reference'][1]
groups = {}
for y in range(32):
    for x in range(32):
        a, r = ia.getpixel((x, y)), ra.getpixel((x, y))
        if a != r:
            groups.setdefault((hexa(a), hexa(r)), []).append((x, y))
diff = []
for (a, r), pts in sorted(groups.items()):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    diff.append({'input_rgba': a, 'reference_rgba': r, 'pixel_count': len(pts),
                 'box': [min(xs), min(ys), max(xs) + 1, max(ys) + 1]})
out = {
    'version': 1,
    'calculation': 'tools/diff_input_reference.py: per-pixel RGBA inequality input.png vs reference.png, grouped by (input, reference) color pair',
    'coordinate_convention': 'zero-based; boxes [left, top, right, bottom], right/bottom exclusive; x increases to the viewer\'s right',
    'frame': 0,
    'sources': {k: {'path': paths[k], 'sha256': imgs[k][0]} for k in paths},
    'differences_input_vs_reference': diff,
    'total_differing_pixels': sum(d['pixel_count'] for d in diff),
    'edit_robot_1_download_equals_input': imgs['edit_robot_1_download'][0] == imgs['input'][0],
    'interpretation_observation': 'Only two regions differ: a dark-outline antenna on the viewer\'s left above the head (reference has it, input is transparent there) and a yellow eye on the viewer\'s right (reference yellow, input teal). Observation only; not an owner geometry requirement.',
}
json.dump(out, open(sys.argv[1], 'w', newline='\n'), indent=2)
print(json.dumps(out, indent=2))
