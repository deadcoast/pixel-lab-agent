"""Build the corrective edit_image_pro_flash arguments (edit_robot_2) and its job-prepare request.
No provider call. Usage: python -I tools/build_request_2.py ROOT OBSERVED_AT"""
import base64, hashlib, json, pathlib, sys

ROOT = pathlib.Path(sys.argv[1]); OBSERVED = sys.argv[2]
b64 = lambda p: base64.b64encode((ROOT / p).read_bytes()).decode("ascii")
sha = lambda p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()

arguments = {
    "method": "reference",
    "image_base64": b64("input.png"),
    "reference_image": {
        "base64": b64("reference.png"),
        "usage_description": (
            "Approved identity reference for this same robot. Use it as the target for structure as well "
            "as appearance: reproduce its two antennae (one on each side of the top of the head) and its "
            "two yellow eyes (one on each side of the face) in the edited image, with its front-facing teal "
            "body, dark outline and colors."
        ),
    },
    "description": (
        "Edit this front-facing teal robot sprite so it matches the reference image. It is missing two "
        "features the reference has: add the second antenna on the viewer's left above the head, mirroring "
        "the existing dark antenna on the right, and add the second yellow eye on the viewer's right, "
        "mirroring the existing yellow eye on the left. The edited image must visibly gain these two "
        "features; returning it unchanged is not a valid result. Keep everything else: the teal body, the "
        "dark outline, the 32x32 canvas, the existing colors and the fully transparent background. No "
        "ground shadow."
    ),
    "no_background": True,
    "use_color_palette_correction": True,
    "seed": 2,
}
schema = json.loads((ROOT / "provider-schemas.json").read_text(encoding="utf-8"))["edit_image_pro_flash"]
(ROOT / "contract/edit_robot_2.arguments.json").write_text(json.dumps(arguments, indent=2) + "\n", encoding="utf-8", newline="\n")
request = {
    "provider": "pixellab-test",
    "tool": "edit_image_pro_flash",
    "arguments": arguments,
    "schema": schema,
    "discovery": {
        "source": "Harness-exposed MCP tool mcp__pixellab-test__edit_image_pro_flash input schema (re-observed in this session's tool list; same properties as provider-schemas.json); official declaration in official-tool-declarations.json",
        "observed_at": OBSERVED,
        "evidence": {
            "host_tool_name": "mcp__pixellab-test__edit_image_pro_flash",
            "provider_schemas_path": "provider-schemas.json",
            "provider_schemas_sha256": sha("provider-schemas.json"),
            "official_declarations_path": "official-tool-declarations.json",
            "official_declarations_sha256": sha("official-tool-declarations.json"),
            "provider_simulated": True,
            "note": "Controlled fixture connection; no upstream provider. Not called in this preparation phase.",
        },
    },
    "authorization": {
        "scope": "pixellab-test (controlled, simulated) edit_image_pro_flash: the single authorized corrective attempt for assets/robot.png after review of edit_robot_1 (q_identity failed in rev_edit_robot_1). No further attempts; no real remote production.",
        "evidence": {
            "source_path": "OWNER.md",
            "source_sha256": sha("OWNER.md"),
            "lines": [9, 10],
            "text": "The controlled MCP service is authorized for one edit and, if needed after review, one corrective attempt. Real remote production is outside this evaluation.",
            "prior_attempt": {"job": "edit_robot_1", "remote_id": "controlled-edit-0001", "candidate": "x_edit_robot_1", "review": "rev_edit_robot_1", "failed_criterion": "q_identity"},
            "provider_simulated": True,
        },
    },
}
(ROOT / "contract/edit_robot_2.request.json").write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8", newline="\n")
print("ok")
