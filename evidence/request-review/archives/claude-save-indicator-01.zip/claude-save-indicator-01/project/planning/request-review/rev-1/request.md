# Save indicator art: creative brief (rev-1)

Kind: creative_brief. Not executable. No PixelLab tool or schema was discovered in
this session; no provider operation, parameter, seed, palette input or reference
handle is specified here. Translate to provider arguments only after discovering
the actual tool declaration, then return a new request for comparison.

## 1. Consumer mapping (src/save-indicator.ts)

- States: "idle" | "saving" | "error" (line 1).
- Logical frame: 24x16 for every returned art frame (line 2; owner OWNER.md:2).
- error: returns { sharedBadge: "error" } (line 5). No new artwork (owner OWNER.md:5).
- idle: path "assets/save-idle.png", frame 0, 24x16 (line 6).
- saving: path = saving.path, frame = Math.floor(elapsedMs / saving.frameMs) % saving.frames,
  24x16 (lines 3, 7). The caller supplies path, frames and frameMs; the consumer
  plays a continuous loop, so frame frames-1 is followed by frame 0.
- The consumer returns a frame index only. Sheet slicing (strip direction,
  padding) is not defined in this file.

## 2. Outputs requested

A. assets/save-idle.png: idle state, one 24x16 frame (frame 0).
B. Saving sheet: the animated saving state, sample of 6 frames at frameMs 100
   (600 ms loop). Proposed path assets/save-saving.png, laid out as a horizontal
   strip of 6 frames, 144x16, frame i at x = 24*i. Path, layout, frame count and
   timing are specialist sample choices (see section 4), not owner requirements.
   The integration must pass { path, frames: 6, frameMs: 100 } as SavingSheet
   if this sample is adopted.

## 3. Owner requirements (must hold in every output)

- 24x16 logical frame (OWNER.md:2).
- Amber visual emphasis: amber is the visually leading accent of the indicator
  (OWNER.md:2-3). No exact amber value or fixed palette is imposed (OWNER.md:6-7).
- An idle state and an animated saving state; saving frames change over time
  (OWNER.md:3-4).
- No new error artwork; error uses the existing shared badge (OWNER.md:5).
- Permitted, not required: detached sparkle pixels (OWNER.md:6). The silhouette
  need not be all-connected (OWNER.md:6-7).

## 4. Specialist sample proposal (revisable choices)

- Motif: a compact save glyph that reads at 24x16 native scale (for example a
  small disk or a downward arrow into a tray). The motif is not specified by the
  owner; the generator may propose an alternative that fits the frame.
- Idle: the glyph at rest with amber emphasis, calm, no motion implied.
- Saving: the same glyph identity as idle, with an amber progress cue that
  travels or pulses across the 6 frames (for example a sweeping highlight or
  orbiting sparkle pixels), designed to loop from frame index 5 back to index 0
  without a visible jump.
- Timing: 6 frames x 100 ms = 600 ms loop: enough phases for a readable sweep at
  this size while staying a short, unobtrusive activity cue.
- Background: transparent outside the glyph is proposed for UI compositing; the
  owner has not stated an alpha policy, so this is open.
- Same glyph scale and position in idle and every saving frame, so switching
  idle -> saving does not jump.

## 5. Not adopted

design-notes.md (blue disk, 32x32, all pixels connected, four exact colors,
same still for idle and saving) is an unadopted prototype suggestion
(OWNER.md:7-8; design-notes.md:1-4). None of its restrictions apply. Its 32x32
size and identical idle/saving still contradict OWNER.md:2-4.

## 6. No reference image

No approved reference image exists (OWNER.md:7). No image input is supplied.
