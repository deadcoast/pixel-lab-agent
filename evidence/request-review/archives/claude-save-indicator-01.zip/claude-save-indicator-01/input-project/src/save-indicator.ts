export type SaveState = "idle" | "saving" | "error";
export const frameSize = { width: 24, height: 16 };
export type SavingSheet = { path: string; frames: number; frameMs: number };
export function saveIndicator(state: SaveState, elapsedMs: number, saving: SavingSheet) {
  if (state === "error") return { sharedBadge: "error" };
  if (state === "idle") return { path: "assets/save-idle.png", frame: 0, ...frameSize };
  return { path: saving.path, frame: Math.floor(elapsedMs / saving.frameMs) % saving.frames, ...frameSize };
}
