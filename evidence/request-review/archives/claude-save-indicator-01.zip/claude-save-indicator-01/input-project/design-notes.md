# Earlier prototype suggestion, unadopted
Try one static blue disk icon on a 32x32 square, all pixels connected, four exact
colors. Reuse the same still image for idle and saving. These were sketch choices;
no renderer check or owner acceptance was recorded.
