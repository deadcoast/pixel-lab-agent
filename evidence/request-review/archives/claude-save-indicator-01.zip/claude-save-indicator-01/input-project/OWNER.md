# Save indicator assignment
Plan the pixel-art assets consumed by src/save-indicator.ts. Use a 24x16 logical
frame with an amber visual emphasis. We need an idle state and an animated saving
state. Choose a useful sample frame count and timing; I have not specified them.
The error state already uses the existing shared badge and needs no new artwork.
Detached sparkle pixels are allowed. I have not imposed a fixed palette or an
all-connected silhouette. There is no approved reference image yet. The older
design-notes.md is a prototype suggestion, not an adopted style contract.
Return an actionable request and review criteria for the calling agent, grounded
in the actual consumer. Generation and engine acceptance are later work.
