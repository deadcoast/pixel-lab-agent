"""Build PX2 revision-1 plan JSON (host adapter) for the robot repair task.

Usage: python -I build_plan.py ROOT CURRENT_DECODED_JSON OUT_JSON
"""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
doc = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))


def sha(p):
    return hashlib.sha256((root / p).read_bytes()).hexdigest()


def ref(i):
    return {"$ref": i}


def sym(s):
    return {"$symbol": s}


DATE = "2026-11-08"
PALETTE = ["#25354a", "#56b5bc", "#f4dda2"]
recs = {r["id"]: r for r in doc["records"]}


def S(i, path, ln):
    recs[i] = {"id": i, "kind": "S", "fields": {"ur": path, "dg": sha(path), "ln": ln, "at": DATE, "au": sym("local")}}


S("owner_brief", "OWNER.md", [1, 14])
S("eval_rules", "AGENTS.md", [1, 14])
S("consumer", "src/avatar.ts", [1, 1])
S("ref_measure", "work/evidence/reference-measurements.json", [])
S("ref_check", "work/evidence/reference-asset-check.json", [])
S("provider_schema", "provider-schemas.json", [])
S("official_decl", "official-tool-declarations.json", [])

recs["x_input"] = {"id": "x_input", "kind": "X", "fields": {"nm": "Content to edit (input.png)", "ur": "input.png", "dg": sha("input.png"), "kd": sym("reference")}}
recs["x_reference"] = {"id": "x_reference", "kind": "X", "fields": {"nm": "Approved identity reference (reference.png)", "ur": "reference.png", "dg": sha("reference.png"), "kd": sym("reference")}}


def I(i, key, st, vl, so, wy, who="user"):
    recs[i] = {"id": i, "kind": "I", "fields": {"pr": ref("project"), "wh": ref(who), "ky": key, "st": sym(st), "vl": vl, "so": [ref(s) for s in so], "wy": wy}}


I("c_px", "px", "confirmed", [32, 32], ["owner_brief", "consumer"], "Owner: preserve the 32x32 canvas (OWNER.md:4); consumer declares width 32, height 32.")
I("c_al", "al", "confirmed", sym("binary"), ["owner_brief"], "Owner: preserve binary transparency (OWNER.md:4).")
I("c_pl", "pl", "confirmed", PALETTE, ["owner_brief", "ref_measure", "ref_check"], "Owner: preserve the reference palette (OWNER.md:4). Values are the exact opaque colors measured in reference.png (and input.png).")
I("c_sa", "sa", "confirmed", sym("nearest"), ["consumer"], "Consumer src/avatar.ts:1 declares sampling nearest.")
I("c_view", "view", "confirmed", "front-facing", ["owner_brief"], "Owner: preserve the front-facing teal body (OWNER.md:3).")
I("c_identity", "identity", "confirmed", "reference.png identity: two antennae, two yellow eyes, teal body, dark outline", ["owner_brief"], "Owner: repair input.png to match approved reference.png; restore two antennae and two yellow eyes (OWNER.md:2-3,7-8).")
I("c_shadow", "ground_shadow", "confirmed", "none", ["owner_brief"], "Owner: no ground shadow (OWNER.md:4).")
I("c_dest", "destination", "confirmed", "assets/robot.png", ["owner_brief", "consumer"], "Owner: deliver one PNG at assets/robot.png consumed by src/avatar.ts (OWNER.md:5).")
I("c_vw", "vw", "proposed", sym("ui"), [], "Specialist mapping: the closed C.vw enum has no front-facing value; the asset is a UI avatar. Descriptive only; the owner's front-facing requirement is carried by choice view.", who="actor")
I("c_method", "operation", "proposed", "edit_image_pro_flash method=reference; image=input.png upload; reference_image=reference.png upload; no_background=true; use_color_palette_correction=true; seed omitted", ["owner_brief", "provider_schema", "official_decl"], "Specialist choice: Pro Flash edit keeps the native 32x32 canvas; reference method conditions on the actual approved image as the owner requires; palette correction and no_background support the palette and binary-transparency requirements.", who="actor")
I("c_phase", "task_phase", "proposed", "sample", [], "Specialist choice: single-asset representative task using the PX2 sample phase so it can activate without a separate D/K adoption record; the deliverable and its owner criteria are unchanged.", who="actor")

recs["project"]["fields"]["in"] = [ref(i) for i in ["c_px", "c_al", "c_pl", "c_sa", "c_view", "c_identity", "c_shadow", "c_dest", "c_vw", "c_method", "c_phase"]]
recs["project"]["fields"]["sc"] = [ref("owner_brief"), ref("eval_rules"), ref("consumer")]

recs["robot_contract"] = {"id": "robot_contract", "kind": "C", "fields": {
    "nm": "robot avatar 32x32", "px": [32, 32], "pl": PALETTE, "vw": sym("ui"), "sa": sym("nearest"), "al": sym("binary"),
    "li": "Flat colors as in reference.png; no ground shadow.",
    "ch": [ref(i) for i in ["c_px", "c_pl", "c_al", "c_sa", "c_vw", "c_view", "c_identity", "c_shadow"]]}}


def Q(i, nm, dm, md, ck, so, who="user"):
    recs[i] = {"id": i, "kind": "Q", "fields": {"nm": nm, "dm": sym(dm), "md": sym(md), "ck": ck, "wh": ref(who), "so": [ref(s) for s in so]}}


Q("q_canvas", "canvas", "mechanical", "local", "Delivered file is a PNG of exactly 32x32 pixels, one frame.", ["owner_brief", "consumer"])
Q("q_alpha", "binary_alpha", "mechanical", "local", "Every pixel has alpha 0 or 255 (no fractional alpha).", ["owner_brief"])
Q("q_palette", "reference_palette", "mechanical", "local", "Every opaque pixel uses one of the reference palette colors #25354a, #56b5bc, #f4dda2.", ["owner_brief", "ref_measure"])
Q("q_identity", "reference_identity", "visual", "visual", "At native and enlarged scale the robot visibly has two antennae and two yellow eyes and reads as the same identity as reference.png.", ["owner_brief"])
Q("q_preserve", "preserved_body", "visual", "visual", "The front-facing teal body with its dark outline from input.png is preserved (repair of the input, not a different design).", ["owner_brief"])
Q("q_shadow", "no_ground_shadow", "visual", "visual", "No ground shadow or cast shadow appears beneath or around the robot.", ["owner_brief"])
Q("q_provenance", "provider_provenance", "other", "local", "Delivered bytes equal the imported pixellab-test job output downloaded from its loopback URL (hash chain via job import), with provider_simulated=true retained; the output is not a copy of reference.png.", ["eval_rules", "owner_brief"])
Q("q_integration", "consumer_integration", "other", "local", "assets/robot.png contains the accepted candidate bytes and src/avatar.ts path/width/height (assets/robot.png, 32, 32) match the file.", ["owner_brief", "consumer"])

recs["robot_out"] = {"id": "robot_out", "kind": "F", "fields": {
    "tk": ref("repair"), "nm": "assets/robot.png repaired robot avatar", "kd": sym("sprite"), "ct": ref("robot_contract"),
    "rq": [ref(q) for q in ["q_canvas", "q_alpha", "q_palette", "q_identity", "q_preserve", "q_shadow", "q_provenance", "q_integration"]]}}
recs["repair"] = {"id": "repair", "kind": "T", "fields": {
    "nm": "Repair input.png to the approved reference identity via one PixelLab edit", "ow": ref("actor"), "pr": ref("project"),
    "dp": [], "dc": [], "kn": [], "st": sym("open"), "ph": sym("sample"),
    "ip": [ref("x_input"), ref("x_reference")], "op": [ref("robot_out")], "ca": [], "vr": []}}

doc["revision"] = doc["revision"] + 1
doc["records"] = [recs[k] for k in sorted(recs)]
Path(sys.argv[3]).write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
