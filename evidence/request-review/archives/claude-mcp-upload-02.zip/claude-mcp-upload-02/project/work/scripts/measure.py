"""Reproducible measurement of input.png and reference.png (read-only).

Coordinates: zero-based, boxes [left, top, right, bottom] with exclusive
right/bottom; rows y=0 at top. Usage: python -I measure.py ROOT OUT_JSON
"""
import hashlib
import json
import sys
from pathlib import Path

from PIL import Image

root = Path(sys.argv[1])
out = {"coordinates": "zero-based [left, top, right, bottom]; right/bottom exclusive", "images": {}}
for name in ("input.png", "reference.png"):
    raw = (root / name).read_bytes()
    im = Image.open(root / name).convert("RGBA")
    w, h = im.size
    px = im.load()
    colors = {}
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            key = f"#{r:02x}{g:02x}{b:02x}{a:02x}"
            colors[key] = colors.get(key, 0) + 1
    # Opaque pixels above the body top row (y < 9 in both images) grouped by column runs.
    above = sorted({x for y in range(0, 9) for x in range(w) if px[x, y][3]})
    runs, start = [], None
    for i, x in enumerate(above):
        if start is None:
            start = x
        if i == len(above) - 1 or above[i + 1] != x + 1:
            ys = [y for y in range(0, 9) for xx in range(start, x + 1) if px[xx, y][3]]
            runs.append([start, min(ys), x + 1, max(ys) + 1])
            start = None
    # Bottom-most opaque row and rows below body (ground-shadow check basis).
    rows = [y for y in range(h) for x in range(w) if px[x, y][3]]
    out["images"][name] = {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "size": [w, h],
        "mode": Image.open(root / name).mode,
        "color_counts": colors,
        "opaque_runs_above_row_9": runs,
        "opaque_row_range": [min(rows), max(rows) + 1],
    }
Path(sys.argv[2]).write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))
