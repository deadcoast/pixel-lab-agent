You are the calling agent in an explicit PIXL evaluation, continuing the
retained queue consumer. FOCUSED-SUCCESSOR.md is the current assignment; prior
assignments/results are history. Use the current copied kit and pixl-local MCP.
Delegate the art/criteria work to PIXL as a foreground specialist; independently
compare its actual proposal. Preserve old evidence, source and assets. Write new
work under work/focused-successor and versioned successor source/renderer paths.
Only actual lifecycle/PLAR updates authorized below may change existing state.
No global configuration or persistent-memory writes. Parse generated JSON as UTF-8.

Selected Python: C:/github/pixel-lab-agent/.venv/Scripts/python.exe
