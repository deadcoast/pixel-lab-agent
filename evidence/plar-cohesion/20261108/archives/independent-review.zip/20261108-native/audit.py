from pathlib import Path
import sys, json, shutil, hashlib
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from pixl import plar,store,codec,jobs,graph
host=sys.argv[1];case=ROOT/'evidence/plar-cohesion/20261108/native'/f'{host}-cold-01';record=json.loads((case/'record.json').read_bytes())
review=BASE/host;review.mkdir(exist_ok=True)
root=review/'project'
if not root.exists():shutil.copytree(case/'project',root,ignore=shutil.ignore_patterns('.agents','__pycache__'))
original=case/'input-project'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
result={}
result['record_artifact_mismatches']=[p for p,h in record['artifacts'].items() if not (case/'project'/p).is_file() or sha(case/'project'/p)!=h]
result['changed_original_files']=[p.relative_to(original).as_posix() for p in original.rglob('*') if p.is_file() and (not (root/p.relative_to(original)).is_file() or sha(p)!=sha(root/p.relative_to(original)))]
oldplar=load(original/'plar.txt');newplar=load(root/'plar.txt');result['changed_asset_rows']=[r['id'] for r in oldplar['assets'] if r!=next((a for a in newplar['assets'] if a['id']==r['id']),None)]
result['ids_preserved']=sorted(r['id'] for r in oldplar['assets'])==sorted(r['id'] for r in newplar['assets'])
focused=plar.read(root,asset_id='queue.ready');result['current_selection']=focused;folder=root/focused['production']['store']
old=store.load(original/'.pixl/assets/queue.ready');new=store.load(folder);graph.validate(new,root)
result['old_record_changes']=[k for k,v in old.records.items() if k not in new.records or codec.record_hash(new.records[k])!=codec.record_hash(v)]
result['old_job_intent_retained']=new.records['first_request'].fields['ah']==old.records['first_request'].fields['ah']
result['all_jobs']=jobs.report(new,root,folder)
result['old_journal_events_prefix']=[]
oldj=load(original/old.records[old.records['first_request'].fields['jr'].id].fields['ur']);newj=load(root/new.records[new.records['first_request'].fields['jr'].id].fields['ur'])
result['old_journal_events_prefix']=newj['events'][:len(oldj['events'])]==oldj['events']
result['provider_calls']=[loadline for line in (case/'provider-calls.jsonl').read_text('utf-8').splitlines() if (loadline:=json.loads(line))]
result['actual_generation_calls']=[x for x in result['provider_calls'] if x.get('tool','').startswith('create_')]
result['cold_result']=load(root/'COLD-RESULT.json')
selected_task=new.records[focused['production']['task']]
selection=next(new.records[r.id] for r in selected_task.fields['ip'] if new.records[r.id].fields.get('mt',{}).get('binding')=='pixl.plar.selection/1')
marker=load(root/selection.fields['ur'])
packetpaths=[root/marker['input']['packet']['path']]
packet=load(packetpaths[0]);args=load(root/packet['request']['path']);plan=load(root/packet['criteria']['path'])
result['packet_path']=packetpaths[0].relative_to(root).as_posix();result['packet']=packet;result['plan']=plan
result['packet_identity_checks']={k:sha(root/packet[k]['path'])==packet[k]['sha256'] for k in ('request','criteria')}
result['packet_sources_checks']={r['path']:sha(root/r['path'])==r['sha256'] for r in packet['sources']}
result['actual_call_equals_reviewed_arguments']=len(result['actual_generation_calls'])==1 and result['actual_generation_calls'][0]['arguments']==args
currentjob=next(j for j in result['all_jobs']['jobs'] if j['id']==focused['production']['pending_jobs'][0])
result['durable_equals_actual']=currentjob['request']['arguments']==args
result['current_contract_checks_match_Qs']=all(next(r for r in new.records.values() if r.kind=='Q' and r.id.endswith('.'+c['id'])).fields['ck']==c['check'] for c in plan['outputs'][0]['criteria'])
result['no_acceptance']=not any(r.kind=='V' for r in new.records.values()) and not new.records[focused['production']['task']].fields['ca']
result['source_line_counts']={p:len((original/p).read_text('utf-8').splitlines()) for p in ('BRIEF.md','OWNER.md','src/queue.ts','src/queue-view.ts')}
items=[]
for line in (case/'stdout.jsonl').read_text('utf-8').splitlines():
 try:event=json.loads(line)
 except ValueError:continue
 if host=='claude':
  for block in event.get('message',{}).get('content',[]):
   if block.get('type')=='tool_use':items.append({'type':'tool_use','name':block['name'],'arguments':block['input'],'timestamp':event.get('timestamp'),'parent':event.get('parent_tool_use_id')})
 if event.get('type')=='item.completed':
  item=event['item']
  if item.get('type')!='agent_message':items.append(item)
result['transcript_items_count']=len(items)
(review/'tool-items.json').write_text(json.dumps(items,indent=2)+'\n','utf-8')
(review/'audit.json').write_text(json.dumps(result,indent=2,default=str)+'\n','utf-8')
summary={k:v for k,v in result.items() if k not in {'current_selection','all_jobs','provider_calls','cold_result','packet','plan','actual_generation_calls'}}
summary['jobs']=[{k:j[k] for k in ('id','state','remote_id','next_action')} for j in result['all_jobs']['jobs']]
summary['production_next']=focused['production']['next_action'];summary['current_task']=focused['production']['task'];summary['tool_item_types']={k:sum(i.get('type')==k for i in items) for k in {i.get('type') for i in items}}
(review/'summary.json').write_text(json.dumps(summary,indent=2)+'\n','utf-8')
print(json.dumps(summary,indent=2))


