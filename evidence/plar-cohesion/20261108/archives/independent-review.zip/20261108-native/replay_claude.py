from pathlib import Path
import sys,json,shutil,hashlib,argparse
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from pixl import plar,store,codec,jobs
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
base=Path(__file__).resolve().parent/'claude';root=args.output.resolve()
assert root.is_relative_to(ROOT/'build/plar-cohesion-review') and not root.exists()
shutil.copytree(base/'project',root)
selected=plar.read(root,asset_id='queue.ready');folder=root/selected['production']['store'];doc=store.load(folder)
job=next(j for j in jobs.report(doc,root,folder)['jobs'] if j['id']==selected['production']['pending_jobs'][0])
req={k:job['request'][k] for k in ('provider','tool','arguments','schema','discovery','authorization')}
req['provider']='separate-future-live-connection-probe';req['authorization']={'scope':'Local isolated replay only; no provider or paid call authorized','evidence':{'fixture':True}}
def inventory():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
before=inventory()
try:
 jobs.prepare(folder,codec.digest(doc),'future_live_request',selected['production']['task'],[selected['asset']['production']['output']],root=root,**req);error=None
except Exception as e:error=str(e)
result={'instruction_source':'COLD-RESULT.json remaining_work[0] and PLAR queue.ready.next','pending_job':job['id'],'result':error,'no_files_changed':inventory()==before}
(root.parent/(root.name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps(result))
