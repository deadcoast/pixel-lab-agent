from pathlib import Path
import sys, json, hashlib
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
frozen=ROOT/'evidence/plar-cohesion/20261108/native/codex-cold-01/project/.agents/skills/pixl-kit/runtime'
sys.path.insert(0,str(frozen))
from pixl import plar, service, jobs
from tests.test_plar_prepare import seed, write
root=BASE/'consumer'
args,packet,plan,arguments=seed(root)
first=service.call('pixl_plar_prepare',args,root)
terminal=jobs.observe(root/first['store'],first['hash'],first['job']['id'],'failed',{'fixture':'independent local prepared-request withdrawal'},root=root)
arguments['description']+=' Asymmetric motion cue.'
packet['request'].update(write(root,'work/arguments-r2.json',arguments))
args['packet']='work/packet-r2.json';write(root,args['packet'],packet)
second=service.call('pixl_plar_prepare',{**args,'revise':True,'expect':terminal['hash']},root)
focused=plar.read(root,asset_id=args['asset_id'])
result={'runtime':str(frozen),'runtime_sha256':hashlib.sha256((frozen/'pixl/plar_prepare.py').read_bytes()).hexdigest(),'response':second,'fresh_read':focused,'observed_defect':{'response_next':second['job']['next_action'],'fresh_next':focused['production']['next_action'],'response_blockers':second['job']['blockers'],'allocation_status':second['allocation']['status']}}
(BASE/'result.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
print(json.dumps(result['observed_defect']))
assert second['job']['next_action']=='resolve_context'
assert focused['production']['next_action']=='dispatch'
