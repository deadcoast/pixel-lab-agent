from pathlib import Path
import sys,json,shutil,hashlib
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from pixl import plar,service,store,codec
root=BASE/'consumer';shutil.copytree(ROOT/'build/plar-cohesion-review/20261108-tagged-report/current',root)
selected=plar.read(root,asset_id='queue.working');folder=root/selected['production']['store'];before=store.load(folder)
args={'asset_id':'queue.working','requirements_hash':selected['requirements_hash'],'packet':'work/packet-revised.json','connection':json.loads((root/'work/connection.json').read_bytes()),'revise':True,'expect':codec.digest(before)}
file_hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
result=service.call('pixl_plar_prepare',args,root);after=store.load(folder)
changed_old_files=[p for p,h in file_hashes.items() if not (root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
proof={'source':'Isolated copy of actual pre-correction text-report failure','same_store':result['store']==selected['production']['store'],'prior_records_retained':all(codec.record_hash(after.records[k])==codec.record_hash(v) for k,v in before.records.items() if k!='project'),'changed_existing_files':changed_old_files,'job_state':result['job']['state'],'next_action':result['job']['next_action'],'no_inherited_acceptance':not after.records[result['task']].fields['ca'] and not after.records[result['task']].fields['vr'],'runtime_sha256':hashlib.sha256((ROOT/'pixl/plar_prepare.py').read_bytes()).hexdigest()}
(BASE/'result.json').write_text(json.dumps(proof,indent=2)+'\n','utf-8');print(json.dumps(proof,indent=2));assert proof['same_store'] and proof['prior_records_retained'] and proof['no_inherited_acceptance'] and proof['next_action']=='dispatch'
