from pathlib import Path
import sys,json,shutil,hashlib
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from pixl import plar,service,store,codec
root=BASE/'consumer';shutil.copytree(ROOT/'build/plar-cohesion-review/20261108-source-order/consumer',root)
selected=plar.read(root,asset_id='queue.working')
args={'asset_id':'queue.working','requirements_hash':selected['requirements_hash'],'packet':'work/request-review.json','connection':json.loads((root/'work/connection.json').read_bytes())}
def files():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
before=files();state_hash=selected['production']['hash'];job_id=selected['production']['pending_jobs'][0];task_id=selected['production']['task']
result=service.call('pixl_plar_prepare',args,root)
proof={'source':'Isolated copy of actual consumer retained by pre-correction failing probe','same_state_hash':result['hash']==state_hash,'same_task':result['task']==task_id,'same_job':result['job']['id']==job_id,'already_prepared':result['already_prepared'],'all_files_byte_identical':files()==before,'next_action':result['job']['next_action'],'runtime_sha256':hashlib.sha256((ROOT/'pixl/plar_prepare.py').read_bytes()).hexdigest()}
(BASE/'result.json').write_text(json.dumps(proof,indent=2)+'\n','utf-8')
print(json.dumps(proof,indent=2));assert all(proof[k] for k in ('same_state_hash','same_task','same_job','already_prepared','all_files_byte_identical'))
