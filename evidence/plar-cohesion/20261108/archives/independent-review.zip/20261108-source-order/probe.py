from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from pixl import plar,service
from tests.test_plar_prepare import seed
root=BASE/'consumer';args,*_=seed(root)
first=service.call('pixl_plar_prepare',args,root)
before=plar.read(root,asset_id=args['asset_id'])
doc=json.loads((root/'plar.txt').read_bytes());doc['sources'].reverse()
plar.save(root,doc,plar.read(root)['hash'])
after=plar.read(root,asset_id=args['asset_id'])
try:
 retry=service.call('pixl_plar_prepare',args,root);outcome={'reused':retry['already_prepared'],'error':None}
except Exception as error:outcome={'reused':False,'error':str(error)}
result={'same_requirements_hash':before['requirements_hash']==after['requirements_hash'],'same_packet_and_connection':True,'edit':'Reverse top-level PLAR sources array only; stable IDs, paths and hashes unchanged','retry':outcome,'production':after['production']}
(BASE/'result.json').write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in result.items() if k!='production'}))
