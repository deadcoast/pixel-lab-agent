from pathlib import Path
import sys,json,hashlib,subprocess,copy
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
if len(sys.argv)==1:
 out=[]
 for mode in ('frozen','current'):
  p=subprocess.run([sys.executable,str(Path(__file__).resolve()),mode],capture_output=True,text=True)
  out.append({'mode':mode,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 (BASE/'results.json').write_text(json.dumps(out,indent=2)+'\n','utf-8');print(json.dumps(out));raise SystemExit()
mode=sys.argv[1];sys.path.insert(0,str(ROOT))
if mode=='frozen':sys.path.insert(0,str(ROOT/'evidence/plar-cohesion/20261108/native/codex-cold-01/project/.agents/skills/pixl-kit/runtime'))
from pixl import plar,service,store,codec,jobs,graph
from tests.test_plar_prepare import seed,write
root=BASE/mode;args,packet,plan,arguments=seed(root)
first=service.call('pixl_plar_prepare',args,root);folder=root/first['store']
terminal=jobs.observe(folder,first['hash'],first['job']['id'],'failed',{'fixture':'local prepared withdrawal, no provider call'},root=root)
current=store.load(folder);amended=copy.deepcopy(current)
report=root/'work/selection-report.txt';report.write_text('Selected queue.working requirements; source identities are recorded in the opt-in X metadata.\n','utf-8')
amended.records['selection'].fields['ur']='work/selection-report.txt';amended.records['selection'].fields['dg']=hashlib.sha256(report.read_bytes()).hexdigest();amended.revision+=1
committed=store.commit(folder,amended,terminal['hash'],root);graph.validate(store.load(folder),root)
arguments['description']+=' Explicit revised candidate treatment.';packet['request'].update(write(root,'work/arguments-revised.json',arguments));args['packet']='work/packet-revised.json';write(root,args['packet'],packet)
try:
 revised=service.call('pixl_plar_prepare',{**args,'revise':True,'expect':committed['hash']},root);result={'succeeded':True,'job':revised['job']['id'],'error':None}
except Exception as error:result={'succeeded':False,'error':str(error)}
result['mode']=mode;result['scope']='Explicit supported PLAR binding on a hash-bound human-readable report, with prior attempt terminal; no provider calls'
(BASE/(mode+'.json')).write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps(result))
