from pathlib import Path
import copy, hashlib, json, shutil, subprocess, sys
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from pixl import codec, jobs, plar, service, store
from tests.test_plar_prepare import seed, write
BASE=Path(__file__).resolve().parent
assert not (BASE/'consumer').exists(), 'Use a new review directory'
root=BASE/'consumer'
args,packet,plan,arguments=seed(root)
results=[]
def save(name,value):
 (BASE/(name+'.json')).write_text(json.dumps(value,indent=2,default=str)+'\n',encoding='utf-8')
def files(folder):
 return {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
def record(name,ok,detail):
 results.append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok: raise AssertionError(name)
before=plar.read(root,asset_id=args['asset_id'])
first=service.call('pixl_plar_prepare',args,root); save('first',first)
record('First preparation links exact retained job',first['allocation']['status']=='linked' and plar.read(root,asset_id=args['asset_id'])['production']['next_action']=='dispatch',first['allocation'])
old_files=files(root)
again=service.call('pixl_plar_prepare',args,root)
record('Exact retry is byte-identical',old_files==files(root) and again['job']['id']==first['job']['id'],again['hash'])
folder=root/first['store']
sent=jobs.dispatch(folder,first['hash'],first['job']['id'],root)
submitted=jobs.observe(folder,sent['hash'],first['job']['id'],'submitted',{'source':'independent local probe; no provider call'},remote_id='review-controlled-old',root=root)
old_doc=store.load(folder)
brief=root/'BRIEF.md'; brief.write_text(brief.read_text('utf-8')+'\nCurrent owner update: visible asymmetrical motion cue.\n','utf-8')
changed=plar.read(root)
record('Source change reaches dependent allocations',set(changed['changes']['affected_assets'])>= {'queue.working','queue.ready','queue.retry'},changed['changes'])
document=json.loads((root/'plar.txt').read_bytes())
for row in document['sources']:
 if row['path']=='BRIEF.md': row.pop('sha256',None)
for row in document['assets']:
 if row['id']==args['asset_id']: row['purpose']+=' Preserve an asymmetrical motion cue.'
plar.save(root,document,plar.read(root)['hash'])
selected=plar.read(root,asset_id=args['asset_id'])
args['requirements_hash']=packet['requirements_hash']=selected['requirements_hash']
packet['sources']=[{'path':r['path'],'sha256':r['sha256'],'role':'independently inspected consumer source'} for r in selected['sources']]
arguments['description']+=' Preserve visible asymmetrical motion.'
packet['request'].update(write(root,'work/arguments-revised.json',arguments))
plan['outputs'][0]['criteria'][1]['check']+=' Preserve the asymmetrical motion cue.'
packet['criteria']=write(root,'work/criteria-revised.json',plan)
args['packet']='work/request-review-revised.json'; write(root,args['packet'],packet)
old_files=files(root)
try:
 service.call('pixl_plar_prepare',{**args,'revise':True,'expect':submitted['hash']},root)
 pending='unexpected success'
except Exception as error: pending=str(error)
record('Pending original blocks replacement without writes','job_pending' in pending and files(root)==old_files,pending)
terminal=jobs.observe(folder,submitted['hash'],first['job']['id'],'failed',{'source':'independent probe supplies an explicit terminal fixture observation; no real provider claim'},root=root)
terminal_doc=store.load(folder)
second=service.call('pixl_plar_prepare',{**args,'revise':True,'expect':terminal['hash']},root);save('second',second)
current=store.load(folder)
record('Returned revision action matches synchronized selection',second['job']['next_action']=='dispatch' and not second['job']['blockers'],second['job'])
record('Revision retains old plan and terminal job',all(current.records[k]==v for k,v in terminal_doc.records.items() if k!='project') and second['task']!=first['task'],{'old_task':first['task'],'new_task':second['task']})
record('Revision creates no inherited acceptance',not current.records[second['task']].fields['ca'] and not current.records[second['task']].fields['vr'],second['task'])
record('Old task cannot dispatch after revised selection',jobs.report(current,root)['jobs'][0]['state']=='failed',plar.read(root,asset_id=args['asset_id'])['production'])
newsent=jobs.dispatch(folder,second['hash'],second['job']['id'],root)
record('Dispatch uses reviewed revised arguments',newsent['dispatch_request']['arguments']==arguments,newsent['dispatch_request'])
newsubmitted=jobs.observe(folder,newsent['hash'],second['job']['id'],'submitted',{'source':'independent controlled observation'},remote_id='review-controlled-revised',root=root)
cold=BASE/'relocated';shutil.copytree(root,cold)
runner=ROOT/'plugins/pixl/scripts/pixl.py'
completed=subprocess.run([sys.executable,str(runner),'plar','read','--root',str(cold),'--asset',args['asset_id']],capture_output=True,text=True)
save('cold-process',{'args':completed.args,'returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr})
view=json.loads(completed.stdout)
record('Fresh process in relocated consumer resumes submitted identity',completed.returncode==0 and view['production']['next_action']=='observe' and len(view['production']['jobs'])==2 and view['production']['pending_jobs']==[second['job']['id']],view['production'])
corrupt=BASE/'corrupt';shutil.copytree(root,corrupt)
corrupt_doc=store.load(corrupt/first['store']); journal=corrupt_doc.records[corrupt_doc.records[second['job']['id']].fields['jr'].id]
(corrupt/journal.fields['ur']).write_text('{}\n','utf-8')
broken=plar.read(corrupt,asset_id=args['asset_id'])
record('Broken production preserves readable requirements and blocks requests',broken['production']['status']=='unavailable' and broken['asset']['requirements'] and not broken['production']['new_request_allowed'],broken['production'])
save('results',{'scope':'Independent deterministic interface probes; fixtures only, no external provider, artwork, or renderer claims','runtime_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'pixl').glob('plar*.py')},'results':results})
print(json.dumps({'checks':len(results),'passed':all(x['passed'] for x in results),'path':str(BASE/'results.json')}))

