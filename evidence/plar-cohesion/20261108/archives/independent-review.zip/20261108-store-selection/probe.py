from pathlib import Path
import sys,json,hashlib,subprocess
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
if len(sys.argv)==1:
 results=[]
 for mode in ('frozen','current'):
  run=subprocess.run([sys.executable,str(Path(__file__).resolve()),mode],capture_output=True,text=True)
  results.append({'mode':mode,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr})
 (BASE/'results.json').write_text(json.dumps(results,indent=2)+'\n','utf-8')
 print(json.dumps(results));raise SystemExit(0)
mode=sys.argv[1]
sys.path.insert(0,str(ROOT))
if mode=='frozen':sys.path.insert(0,str(ROOT/'evidence/plar-cohesion/20261108/native/codex-cold-01/project/.agents/skills/pixl-kit/runtime'))
from pixl import service,plar,jobs
from tests.test_plar_prepare import seed
root=BASE/mode
args,*_=seed(root)
first=service.call('pixl_plar_prepare',args,root)
document=json.loads((root/'plar.txt').read_bytes())
for row in document['assets']:
 if row['id']==args['asset_id']:row['production']['store']='.pixl/assets/explicitly-selected-different-store'
plar.save(root,document,plar.read(root)['hash'])
try:
 dispatch=jobs.dispatch(root/first['store'],first['hash'],first['job']['id'],root)
 result={'allowed':True,'state':dispatch['job']['state'] if 'job' in dispatch else dispatch,'reason':None}
except Exception as error:result={'allowed':False,'reason':str(error)}
result['mode']=mode;result['scope']='Old retained store after explicit allocation relink; task ID remains task; no provider I/O'
(BASE/(mode+'.json')).write_text(json.dumps(result,indent=2)+'\n','utf-8')
print(json.dumps(result))
