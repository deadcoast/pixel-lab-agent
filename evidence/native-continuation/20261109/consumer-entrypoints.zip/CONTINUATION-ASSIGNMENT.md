# Finish the retained interrupted caller comparison

The earlier focused-authoring Claude run stopped at a usage limit after its PIXL
child wrote work/focused-successor/specialist-proposal.json and specialist-report.json.
It was launched with session persistence disabled. This phase is an explicit
artifact-based restart of its unfinished comparison, not the old child resumed.
Preserve that attempt's grade and all its saved files.

The specific unfinished work here is the independent comparison of the original
20 criteria against that retained 29-criterion reduced-motion proposal. Do not
substitute the later 23-criterion package used by a different successor trial.
The broader original assignment also included production/rendering; those remain
separate and are not completed by this comparison. Do not adopt/rewrite production,
run a renderer, or create new art acceptance in this comparison assignment.

Read current shared profile and skill in .agents/skills/continuation-kit, then use
one native registered pixl child to review the retained proposal and its exact
sources. Use focused public context/request-review exports where useful. Read
large JSON programmatically and preserve literal checks, IDs and record hashes.
New files must be under work/continuation; the original proposal stays unchanged.

First ask the specialist for a concise assessment of the proposal and any concrete
source/authority defects, with exact locators and suggested corrections, in a new
SPECIALIST-ROUND1.json. Distinguish owner requirements, measured facts and scoped
expert choices. Preserve selective AA/full alpha, margins versus sheet padding,
perceptible color roles, expert pacing versus the owner's 100ms, shared-consumer
state distinction, and visual/temporal evidence obligations. Do not turn retained
unavailable viewing into a new pass. Retain the actual child ID for continuation.

Then independently compare all 20 original rows with the 29 proposed literal
criteria, using actual sources and the prior r2 corrections. Write CALLER-REVIEW-01.json:
- exact original proposal SHA-256 and original state/requirements identities;
- all 20 original IDs, record hashes, literal checks and mapped proposed IDs;
- each of the 29 proposed IDs and literal checks, supported disposition and any
  concrete authority/source concern; give corrections without rewriting originals;
- source locators and separation of mechanical, visual, temporal and destination
  evidence; limitations and remaining decisions.

Write PHASE1-CALLER.json with the native child ID, exact output paths/hashes, an
independent assessment of the specialist, and the precise follow-up for that same
child. End this phase after retaining the review. A separate invocation will
resume this same parent session and send that child the caller review to reconcile.
Do not replace this with another fresh child or claim already-tested same-child
continuation. M1 and broader host reliability remain open.
